from __future__ import annotations
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from platform_core.registry.registry import list_sops_with_classes
from platform_core.observability.status import collect_status


router = APIRouter()


@router.get("/sops")
async def get_registered_sops():
    items = list_sops_with_classes()
    return {"count": len(items), "sops": [{"sop_id": sid, "class": cls} for sid, cls in items]}


def _render_card(sid: str, cls: str, hints: dict[str, list[str]]) -> str:
    ttypes = ", ".join(hints.get(sid, [])) or "-"
    example_payload = "{\"key\": \"demo\"}" if sid == "test-sop" else "{\"headful\": true, \"slow\": 2000}"
    example_task = hints.get(sid, ["<task_type>"])[0]
    curl = (
        "curl -s -X POST http://localhost:8000/runs "
        "-H 'Content-Type: application/json' "
        f"-d '{{\"task_type\": \"{example_task}\", \"payload\": {example_payload}}}'"
    )
    return f"""
    <div class=card>
      <div class=card_header>
        <div class=badge>Agent</div>
        <div class=card_title>{sid}</div>
      </div>
      <div class=card_body>
        <div><span class=label>Class</span><span class=value>{cls}</span></div>
        <div><span class=label>Status</span><span class=value_ok>Ready</span></div>
        <div><span class=label>Task Types</span><span class=value>{ttypes}</span></div>
      </div>
      <div class=card_footer>
        <div class=tip>Try:</div>
        <code class=curl>{curl}</code>
      </div>
    </div>
    """


def _render_metrics_html(status: dict) -> str:
    proc = status.get("process", {})
    sysm = status.get("system", {})
    pw = status.get("playwright", {})
    audits = status.get("audits", [])
    rows = []
    for a in audits:
        last = a.get("last_event", {})
        node = last.get("node", "-")
        st = last.get("status", "-")
        rows.append(f"<tr><td>{a.get('run_id')}</td><td>{a.get('started_at')}</td><td>{a.get('ended_at')}</td><td>{node}</td><td>{st}</td></tr>")
    audits_rows = "\n".join(rows) or "<tr><td colspan=5>No audits found</td></tr>"
    return f"""
      <div class=grid>
        <div class=card>
          <div class=card_header><div class=badge>Process</div><div class=card_title>Uvicorn</div></div>
          <div class=card_body>
            <div><span class=label>PID</span><span class=value>{proc.get('pid')}</span></div>
            <div><span class=label>CPU</span><span class=value>{proc.get('cpu_percent','-')}%</span></div>
            <div><span class=label>RSS</span><span class=value>{proc.get('rss_bytes','-')}</span></div>
            <div><span class=label>Threads</span><span class=value>{proc.get('num_threads','-')}</span></div>
            <div><span class=label>Uptime</span><span class=value>{proc.get('uptime_sec','-')}s</span></div>
          </div>
        </div>
        <div class=card>
          <div class=card_header><div class=badge>System</div><div class=card_title>Host</div></div>
          <div class=card_body>
            <div><span class=label>Total Mem</span><span class=value>{sysm.get('total_mem_bytes','-')}</span></div>
            <div><span class=label>Used Mem</span><span class=value>{sysm.get('used_mem_bytes','-')} ({sysm.get('mem_percent','-')}%)</span></div>
            <div><span class=label>CPU%</span><span class=value>{sysm.get('cpu_percent','-')}</span></div>
          </div>
        </div>
        <div class=card>
          <div class=card_header><div class=badge>Playwright</div><div class=card_title>Manager</div></div>
          <div class=card_body>
            <div><span class=label>Enabled</span><span class=value>{pw.get('enabled')}</span></div>
            <div><span class=label>Engine</span><span class=value>{pw.get('engine','-')}</span></div>
            <div><span class=label>Headful Default</span><span class=value>{pw.get('headful_default','-')}</span></div>
            <div><span class=label>Slow Mo</span><span class=value>{pw.get('slow_mo','-')}</span></div>
          </div>
        </div>
      </div>
      <h3 style="margin-top:18px">Recent Audits</h3>
      <table>
        <thead><tr><th>Run ID</th><th>Started</th><th>Ended</th><th>Last Node</th><th>Status</th></tr></thead>
        <tbody>
          {audits_rows}
        </tbody>
      </table>
    """


def render_registry_html(items: list[tuple[str, str]], metrics_html: str) -> str:
    hints = {
        "test-sop": ["test"],
        "psub-workflow": ["psub_flow"],
        "user-onboarding": ["user_onboarding"],
    }
    cards = "\n".join(_render_card(sid, cls, hints) for sid, cls in items)
    rows = "\n".join(f"<tr><td>{sid}</td><td>{cls}</td></tr>" for sid, cls in items)
    return f"""
    <!doctype html>
    <html>
    <head>
      <meta charset='utf-8'>
      <title>LangGraph Platform — Dashboard</title>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <style>
        :root {{
          --bg: #0f172a;
          --bg2: #111827;
          --fg: #e5e7eb;
          --muted: #9ca3af;
          --accent: #22d3ee;
          --ok: #34d399;
          --border: #1f2937;
          --card: #0b1220;
        }}
        * {{ box-sizing: border-box; }}
        body {{ margin: 0; background: linear-gradient(180deg, var(--bg) 0%, var(--bg2) 100%); color: var(--fg); font: 14px/1.5 system-ui, -apple-system, Segoe UI, Roboto, sans-serif; }}
        .hero {{ padding: 28px 20px 16px; border-bottom: 1px solid var(--border); background: radial-gradient(1200px 400px at 10% -10%, rgba(34,211,238,0.08), transparent), radial-gradient(900px 500px at 90% -20%, rgba(52,211,153,0.08), transparent); }}
        .container {{ max-width: 1100px; margin: 0 auto; padding: 0 16px; }}
        h1 {{ margin: 0 0 6px; font-size: 22px; letter-spacing: 0.2px; }}
        .sub {{ color: var(--muted); font-size: 13px; }}
        .tabs {{ display: flex; gap: 12px; margin-top: 12px; }}
        .tab {{ padding: 8px 12px; border: 1px solid var(--border); border-radius: 8px; cursor: pointer; background: #0b1220; }}
        .tab.active {{ background: #0e1525; border-color: #223046; }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 14px; padding: 18px 0 8px; }}
        .card {{ background: var(--card); border: 1px solid var(--border); border-radius: 10px; overflow: hidden; box-shadow: 0 6px 16px rgba(0,0,0,0.25); }}
        .card_header {{ padding: 12px 14px 8px; display: flex; align-items: center; gap: 10px; border-bottom: 1px dashed var(--border); }}
        .badge {{ font-size: 11px; color: #0c4a6e; background: #67e8f9; font-weight: 700; padding: 2px 8px; border-radius: 999px; }}
        .card_title {{ font-size: 16px; font-weight: 700; letter-spacing: .3px; }}
        .card_body {{ padding: 10px 14px; display: grid; gap: 6px; }}
        .label {{ color: var(--muted); min-width: 100px; display: inline-block; }}
        .value {{ color: var(--fg); font-weight: 600; }}
        .value_ok {{ color: var(--ok); font-weight: 700; }}
        .card_footer {{ padding: 10px 14px 14px; border-top: 1px dashed var(--border); }}
        .tip {{ color: var(--muted); margin-bottom: 6px; }}
        .curl {{ display: block; white-space: nowrap; overflow-x: auto; background: #0a0f1a; border: 1px solid var(--border); padding: 8px; border-radius: 6px; color: #a7f3d0; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px; }}
        table {{ border-collapse: collapse; width: 100%; margin-top: 20px; border: 1px solid var(--border); }}
        th, td {{ border: 1px solid var(--border); padding: 8px 10px; text-align: left; }}
        th {{ background: #0b1220; }}
        .foot {{ color: var(--muted); font-size: 12px; }}
        .view {{ display: none; }}
        .view.active {{ display: block; }}
      </style>
    </head>
    <body>
      <div class=hero>
        <div class=container>
          <h1>LangGraph Platform Dashboard</h1>
          <div class=sub>{len(items)} agent(s) registered · /runs routes by task_type</div>
          <div class=tabs>
            <div class="tab active" onclick="showTab('agents')">SOP Agents</div>
            <div class="tab" onclick="showTab('metrics')">Metrics & Health</div>
          </div>
        </div>
      </div>
      <div class=container>
        <div id=agents class="view active">
          <div class=grid>
            {cards}
          </div>
          <table>
            <thead><tr><th>SOP ID</th><th>Class</th></tr></thead>
            <tbody>
              {rows}
            </tbody>
          </table>
        </div>
        <div id=metrics class="view">
          {metrics_html}
        </div>
        <div class=foot style="margin-top:12px">JSON API: <code>/sops</code> · UI: <code>/sops/ui</code> · Generated at runtime</div>
      </div>
      <script>
        function showTab(name) {{
          document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
          document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
          const tab = Array.from(document.querySelectorAll('.tab')).find(t=>t.textContent.includes(name==='agents'?'SOP Agents':'Metrics'));
          if (tab) tab.classList.add('active');
          document.getElementById(name).classList.add('active');
        }}
      </script>
    </body>
    </html>
    """


@router.get("/sops/ui", response_class=HTMLResponse)
async def get_registered_sops_ui(request: Request):
    items = list_sops_with_classes()
    status = collect_status(getattr(request.app, 'state', None))
    metrics_html = _render_metrics_html(status)
    return HTMLResponse(content=render_registry_html(items, metrics_html))
