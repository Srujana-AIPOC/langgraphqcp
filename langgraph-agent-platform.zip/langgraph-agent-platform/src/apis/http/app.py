import os, uuid, asyncio, sys

from dotenv import load_dotenv
load_dotenv()

# Ensure Windows uses ProactorEventLoop which supports subprocess (required by Playwright sync API)
if sys.platform.startswith("win"):
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    except Exception:
        pass

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from platform_core.config.loader import load_config
from platform_core.logging.setup import setup_logging
from platform_core.supervisor.router import choose_sop
from platform_core.registry.registry import register_sop, get_sop
from sops.test_sop.graph import TestSOP
from sops.psub.psubsop import PsubWorkflowSOP
from sops.user_onboarding.sop import UserOnboardingSOP
from apis.http.routes.sops import router as sops_router

# Bootstrap
cfg = load_config(os.getenv("APP_ENV", "dev"))
setup_logging(cfg.get("logging", {}).get("level", "INFO"))

# Register SOPs
register_sop("test-sop", lambda: TestSOP(cfg.get("connections", {})))
register_sop(
    "psub-workflow",
    lambda: PsubWorkflowSOP(cfg.get("connections", {}), cfg.get("features", {})),
)
register_sop("user-onboarding", lambda: UserOnboardingSOP(cfg.get("connections", {})))

app = FastAPI(title="LangGraph Platform (Rule-First, LLM-Ready)")
app.include_router(sops_router)

class RunRequest(BaseModel):
    task_type: str
    tenant: str | None = None
    payload: dict = {}

@app.post("/runs")
async def start_run(req: RunRequest):
    run_id = str(uuid.uuid4())
    sop_id = choose_sop({"task_type": req.task_type, "tenant": req.tenant})
    sop = get_sop(sop_id)
    try:
        payload = dict(req.payload)
        payload.setdefault("_run_id", run_id)
        result = await sop.run(payload)
        return {"run_id": run_id, "sop_id": sop_id, "result": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# Optional: initialize async Playwright manager on startup (Phase 1 skeleton)
@app.on_event("startup")
async def _startup_pw_manager():
    features = cfg.get("features", {})
    pw_cfg = features.get("playwright", {}) if isinstance(features, dict) else {}
    enabled = bool(pw_cfg.get("enabled", False))
    if not enabled:
        app.state.pw_manager = None
        return
    # Lazy import to avoid hard dependency if disabled
    try:
        from platform_core.playwright.manager import PlaywrightManager
        engine = str(pw_cfg.get("engine", "chromium"))
        headful_default = bool(pw_cfg.get("headful_default", False))
        slow_mo = int(pw_cfg.get("slow_mo", 0))
        max_contexts = int(pw_cfg.get("max_contexts", 4))
        trace = str(pw_cfg.get("trace", "off"))
        app.state.pw_manager = await PlaywrightManager.create(
            engine=engine,
            headful_default=headful_default,
            slow_mo=slow_mo,
            max_contexts=max_contexts,
            trace=trace,
        )
    except Exception:
        # Keep service up even if manager fails; SOPs that depend on it should handle None
        app.state.pw_manager = None


@app.on_event("shutdown")
async def _shutdown_pw_manager():
    mgr = getattr(app.state, "pw_manager", None)
    if mgr is not None:
        try:
            await mgr.shutdown()
        except Exception:
            pass
