import asyncio, os, json, uuid, sys

from dotenv import load_dotenv
load_dotenv()  # reads .env from project root

# Ensure Windows uses ProactorEventLoop which supports subprocess (required by Playwright sync API)
if sys.platform.startswith("win"):
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    except Exception:
        pass

from platform_core.config.loader import load_config
from platform_core.registry.registry import register_sop, get_sop
from platform_core.supervisor.router import choose_sop
from sops.test_sop.graph import TestSOP
from sops.psub.psubsop import PsubWorkflowSOP
from sops.user_onboarding.sop import UserOnboardingSOP

async def main():
    cfg = load_config(os.getenv("APP_ENV", "dev"))
    register_sop("test-sop", lambda: TestSOP(cfg.get("connections", {})))
    register_sop("psub-workflow", lambda: PsubWorkflowSOP(cfg.get("connections", {})))
    register_sop("user-onboarding", lambda: UserOnboardingSOP(cfg.get("connections", {})))

    task = {"task_type": "psub_flow", "payload": {"headful": False, "slow": 0}}
    sop_id = choose_sop(task)
    sop = get_sop(sop_id)
    out = await sop.run(task["payload"])
    print(json.dumps({"run_id": str(uuid.uuid4()), "sop_id": sop_id, "result": out}, indent=2))

if __name__ == "__main__":
    asyncio.run(main())
