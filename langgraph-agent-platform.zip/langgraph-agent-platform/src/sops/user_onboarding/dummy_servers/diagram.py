import asyncio
from playwright.async_api import async_playwright

async def get_mermaid_image(mermaid_code, output_path="mermaid_diagram.png"):
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        
        await page.set_content(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
            <style>
                body {{ background-color: white; }}
            </style>
        </head>
        <body>
            <pre class="mermaid">
{mermaid_code}
            </pre>
        </body>
        </html>
        """)

        # Wait for the diagram to be fully rendered
        await page.locator("svg").wait_for()

        # Take a screenshot of the rendered SVG element
        await page.locator("svg").screenshot(path=output_path)
        
        await browser.close()
        print(f"Diagram saved to {output_path}")

mermaid_string = """
graph TD;
        __start__([<p>__start__</p>]):::first
        extract_user_request_node(extract_user_request_node)
        check_role_type_node(check_role_type_node)
        update_user_role_node(update_user_role_node)
        __end__([<p>__end__</p>]):::last
        __start__ --> extract_user_request_node;
        check_role_type_node -.-> __end__;
        check_role_type_node -.-> update_user_role_node;
        extract_user_request_node --> check_role_type_node;
        update_user_role_node --> __end__;
        classDef default fill:#f2f0ff,line-height:1.2
        classDef first fill-opacity:0
        classDef last fill:#bfb6fc
"""

if __name__ == "__main__":
    asyncio.run(get_mermaid_image(mermaid_string))
