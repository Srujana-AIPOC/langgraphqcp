from flask import Flask, render_template, request, redirect, url_for
from pathlib import Path
import threading

# ------------------- First App (Login + Pages) -------------------
BASE_DIR = Path(__file__).resolve().parents[1]
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

app1 = Flask(
    "App1",
    template_folder=str(TEMPLATES_DIR),
    static_folder=str(STATIC_DIR),
    static_url_path="/static",
)

@app1.route("/")
def home():
    return render_template("outlook_page.html")



# second app

app2 = Flask(
    "App2",
    template_folder=str(TEMPLATES_DIR),
    static_folder=str(STATIC_DIR),
    static_url_path="/static",
)

@app2.route("/")
def index():
    return render_template("access_it_page1.html")

@app2.route("/applications")
def applications():
    return render_template("access_it_page2.html")

@app2.route("/entitlements")
def entitlements():
    return render_template("access_it_page3.html")

@app2.route("/justification")
def justification():
    entitlement = request.args.get("entitlement", "")
    return render_template("access_it_page4.html", entitlement=entitlement)

@app2.route("/thankyou")
def thankyou():
    return render_template("thankyou.html")



#Third app

app3 = Flask(
    "App3",
    template_folder=str(TEMPLATES_DIR),
    static_folder=str(STATIC_DIR),
    static_url_path="/static",
)

@app3.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        if username == "admin" and password == "1234":
            return redirect(url_for("dashboard"))
        else:
            return render_template("login.html", error="Invalid username or password")

    return render_template("POC_app_page1.html")

@app3.route("/dashboard")
def dashboard():
    return render_template("POC_app_page2.html")

@app3.route('/jobviewer')
def jobviewer():
    return render_template('POC_app_page3.html')

@app3.route('/view')
def view():
    return render_template('POC_app_page4.html')

@app3.route('/user')
def user():
    return render_template('POC_app_page5.html')

@app3.route("/thankyou")
def thankyou():
    return render_template("thankyou.html")



# Fourth app

app4 = Flask(
    "App4",
    template_folder=str(TEMPLATES_DIR),
    static_folder=str(STATIC_DIR),
    static_url_path="/static",
)


@app4.route("/")
def home():
    return render_template("modelpedia_page.html")


if __name__ == "__main__":
    app4.run(debug=True, port=5004)





# ------------------- Run Both Apps -------------------
def run_app1():
    app1.run(debug=True, port=5001, use_reloader=False)

def run_app2():
    app2.run(debug=True, port=5002, use_reloader=False)

def run_app3():
    app3.run(debug=True, port=5003, use_reloader=False)

def run_app4():
    app4.run(debug=True, port=5004, use_reloader=False)

if __name__ == "__main__":
    t1 = threading.Thread(target=run_app1)
    t2 = threading.Thread(target=run_app2)
    t3 = threading.Thread(target=run_app3)
    t4 = threading.Thread(target=run_app4)

    t1.start()
    t2.start()
    t3.start()
    t4.start()

    t1.join()
    t2.join()
    t3.join()
    t4.join()
