from flask import Flask, render_template, request, redirect, url_for
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

app = Flask(
    __name__,
    template_folder=str(TEMPLATES_DIR),
    static_folder=str(STATIC_DIR),
    static_url_path="/static",
)

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        
        if username == "admin" and password == "1234":
            return redirect(url_for("dashboard"))
        else:
            return render_template("login.html", error="Invalid username or password")

    return render_template("POC_app_page1.html")

@app.route("/dashboard")
def dashboard():
    return render_template("POC_app_page2.html")

@app.route('/jobviewer')
def jobviewer():
    return render_template('POC_app_page3.html')
@app.route('/view')
def view():
    return render_template('POC_app_page4.html')

@app.route('/user')
def user():
    return render_template('POC_app_page5.html')

@app.route("/thankyou")
def thankyou():
    return render_template("thankyou.html")


if __name__ == "__main__":
    app.run(debug=True,port=5003)
