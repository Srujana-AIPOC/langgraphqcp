from flask import Flask, render_template, request
from pathlib import Path

# Point Flask to the SOP-level templates/static folders
# After moving under sops/user_onboarding/dummy_servers, user_onboarding is parents[1]
BASE_DIR = Path(__file__).resolve().parents[1]
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

app = Flask(
    __name__,
    template_folder=str(TEMPLATES_DIR),
    static_folder=str(STATIC_DIR),
    static_url_path="/static",
)


@app.route("/")
def home():
    return render_template("outlook_page.html")


if __name__ == "__main__":
    app.run(debug=True, port=5001)
