from flask import Flask, render_template, request
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
TEMPLATES_DIR = BASE_DIR / "templates"
STATIC_DIR = BASE_DIR / "static"

app = Flask(
    __name__,
    template_folder=str(TEMPLATES_DIR),
    static_folder=str(STATIC_DIR),
    static_url_path="/static",
)

@app.route("/")
def index():
    return render_template("access_it_page1.html")

@app.route("/applications")
def applications():
    return render_template("access_it_page2.html")

@app.route("/entitlements")
def entitlements():
    return render_template("access_it_page3.html")

@app.route("/justification")
def justification():
    entitlement = request.args.get("entitlement", "")
    return render_template("access_it_page4.html", entitlement=entitlement)

@app.route("/thankyou")
def thankyou():
    return render_template("thankyou.html")

if __name__ == "__main__":
    app.run(debug=True, port=5002)
