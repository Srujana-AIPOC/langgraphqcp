import re
import json
import time
from playwright.sync_api import sync_playwright


def run_first_server(playwright):
    browser = playwright.chromium.launch(headless=False, slow_mo=2000)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5001/")
    page.click('#btn-new-requests')
    time.sleep(2) 


    page.wait_for_selector(".mail-item")   
    time.sleep(2)

    page.locator(".mail-item").first.click()
    time.sleep(2)

    page.wait_for_selector(".mail-body")
    time.sleep(2)

    mail_text = page.inner_text(".mail-body")
    time.sleep(2)

    patterns = {
        "From": r"From:\s*(.*)",
        "Staff Number": r"Staff Number:\s*(\d+)",
        "Name": r"Name:\s*(.*)",
        "Email": r"Email:\s*([\w\.-]+@[\w\.-]+)",
        "Company/ AMO / Role": r"Company/ AMO / Role:\s*(.*)",
        "Mainteniy Trained": r"Mainteniy Trained:\s*(.*)",
        "Phone Number": r"Phone Number:\s*(.*)",
        "Role/ Contract End Date": r"Role/ Contract End Date:\s*(.*)",
        "Request Reason": r"Request Reason:\s*(.*)",
        "Requested Role": r"Requested Role:\s*(.*)",
        "Requested Timesheet Role(s)": r"Requested Timesheet Role\(s\):\s*(.*)",
        "Department(s)": r"Department\(s\):\s*(.*)",
        "Aircraft Type Authorities": r"Aircraft Type Authorities:\s*(.*)",
        "Authorisations/ Licences": r"Authorisations/ Licences:\s*(.*)",
        "Licence/Authorisation No": r"Licence/Authorisation No:\s*(.*)",
        "Additional Notes": r"Additional Notes:\s*(.*)"
    }

    data = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, mail_text, re.MULTILINE)
        data[key] = match.group(1).strip() if match else ""

    with open("data_json/New_User_Requests_mail_data.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    print("Mail data extracted:")
    print(json.dumps(data, indent=4, ensure_ascii=False))

    browser.close()


def run_second_server(playwright, parsed_data):

    staff_number = parsed_data.get("Staff Number")


    browser = playwright.chromium.launch(headless=False, slow_mo=500)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5002/")
    page.wait_for_timeout(2000)

    page.locator('button.dropdown-btn', has_text="Home").click()
    page.wait_for_timeout(2000)

    page.locator('button.nested-btn', has_text="Manage Access for Others").click()
    page.wait_for_timeout(2000)

    page.locator('a#requestAccessOthers').click()
    page.wait_for_timeout(2000)

    page.fill('#userSearch', staff_number)
    page.keyboard.press("Enter")
    page.wait_for_timeout(2000)

    page.locator("table#userTable tr", has_text=staff_number).locator("button.redirect-btn").click()
    page.wait_for_timeout(2000)

    page.locator('.app-item', has_text="Active Directory").locator("button").click()
    page.wait_for_timeout(3000)

    page.fill('#availableSearch', 'AU-MyApps-POCapp-Prod')
    page.keyboard.press("Enter")
    page.wait_for_timeout(2000)
    page.locator('#availablePanel .entitlement-item', has_text="AU-MyApps-POCapp-Prod").locator("button").click()
    page.wait_for_timeout(3000)

    page.locator('#nextBtn').click()
    page.wait_for_timeout(2000)

    page.fill('textarea', 'To perform activities related to Business Analysis')
    page.wait_for_timeout(2000)

    page.locator('#submitBtn').click()
    page.wait_for_timeout(5000)

    print("Second server automation completed!")

    browser.close()


def run_third_server(playwright,parsed_data):

    Department = parsed_data.get("Department(s)")
    role_code = parsed_data.get("Requested Role")
    Name = parsed_data.get("Name")
    staff_number = parsed_data.get("Staff Number")

    xml_text = f"""&lt;?xml version="1.0" encoding="UTF-8"?&gt;
    &lt;ns2:create_user xmlns:ns2="http://xml.com/asd/core/hr/create_user/1.0"&gt;
    &lt;ns2:username&gt;{staff_number}&lt;/ns2:username&gt;
    &lt;ns2:password&gt;password&lt;/ns2:password&gt;
    &lt;ns2:fullname&gt;{Name}&lt;/ns2:fullname&gt;
    &lt;ns2:staff_code&gt;{staff_number}&lt;/ns2:staff_code&gt;
    &lt;ns2:email_address&gt;rama.charan@poc.com&lt;/ns2:email_address&gt;
    &lt;/ns2:create_user&gt;"""

    browser = playwright.chromium.launch(headless=False)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5003")
    time.sleep(2)

    page.fill('input[name="username"]', 'admin')
    page.fill('input[name="password"]', '1234')
    time.sleep(2)
    page.click('button[type="submit"]')
    time.sleep(2)

    page.wait_for_selector(".header .title", timeout=5000)
    time.sleep(2)

    page.click('#dropdownToggle')
    page.wait_for_selector('#dropdownList', state='visible')
    time.sleep(2)

    page.click('#level2SupportMenu')
    page.wait_for_selector('#level2SupportSubMenu', state='visible')
    time.sleep(2)

    page.click('button.submenu-item:text("Job Viewer")')
    time.sleep(2)

    page.wait_for_selector('.send-message-title', timeout=4000)
    time.sleep(2)

    checkbox = page.locator('input[type="checkbox"][name="asynchronous"]')
    if not checkbox.is_checked():
        checkbox.check()
    time.sleep(2)

    page.select_option('select[name="transport"]', 'DMS')
    time.sleep(2)

    page.fill('textarea[name="body"]', xml_text)
    time.sleep(2)

    page.locator('button:has-text("OK")').click()
    time.sleep(2)
    page.click("button:has-text('Cancel')")
    time.sleep(2)

    page.locator('.action-btn:has-text("User Search")').click()
    time.sleep(2)

    page.fill('input[name="userName"]', staff_number)
    time.sleep(2)

    page.click('#searchBtn')
    time.sleep(2)

 
    page.locator("td", has_text=Name).click()
    time.sleep(2)


    page.click('#plusRoleBtn')
    time.sleep(2)

    role_dropdown = page.locator("#roleDropdown")

    role_dropdown.get_by_role("button", name= role_code, exact=True).click()
    # page.locator("#roleDropdown button", has_text=role_code).click()


    time.sleep(2)

    page.get_by_role("button", name="Departments").click()
    time.sleep(2)

    page.click('#assignDeptBtn')
    time.sleep(2)

    page.locator("#departmentDropdown button",has_text=Department).click()  
    time.sleep(2)

    page.click('.user-detail-ok-btn')
    time.sleep(2)

    print("Third server workflow completed!")

    browser.close()




if __name__ == "__main__":
    with sync_playwright() as playwright: 
        run_first_server(playwright)

        with open("data_json/New_User_Requests_mail_data.json", "r") as file:
            parsed_data = json.load(file)

        run_second_server(playwright, parsed_data)
        run_third_server(playwright,parsed_data)
