import re
import json
import time
from playwright.sync_api import sync_playwright


def run_first_server(playwright):
    browser = playwright.chromium.launch(headless=False, slow_mo=2000)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5001/")
    page.click('#btn-review-requests')
    time.sleep(2) 


    page.wait_for_selector(".mail-item")   
    time.sleep(2)

    page.locator(".mail-item").first.click()
    time.sleep(2)

    page.wait_for_selector(".mail-body")
    time.sleep(2)

    mail_text = page.inner_text(".mail-body")
    time.sleep(2)

    patterns = {
        "From": r"From:\s*(.*)",
        "Staff Number": r"Staff Number:\s*(\d+)",
        "Name": r"Name:\s*(.*)",
        "Email": r"Email:\s*([\w\.-]+@[\w\.-]+)",
        "Company/ AMO / Role": r"Company/ AMO / Role:\s*(.*)",
        "Mainteniy Trained": r"Mainteniy Trained:\s*(.*)",
        "Phone Number": r"Phone Number:\s*(.*)",
        "Role/ Contract End Date": r"Role/ Contract End Date:\s*(.*)",
        "Request Reason": r"Request Reason:\s*(.*)",
        "Requested Role": r"Requested Role:\s*(.*)",
        "Requested Timesheet Role(s)": r"Requested Timesheet Role\(s\):\s*(.*)",
        "Department(s)": r"Department\(s\):\s*(.*)",
        "Aircraft Type Authorities": r"Aircraft Type Authorities:\s*(.*)",
        "Authorisations/ Licences": r"Authorisations/ Licences:\s*(.*)",
        "Licence/Authorisation No": r"Licence/Authorisation No:\s*(.*)",
        "Additional Notes": r"Additional Notes:\s*(.*)"
    }

    data = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, mail_text, re.MULTILINE)
        data[key] = match.group(1).strip() if match else ""

    with open("data_json/User_Requests_mail_data.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    print("Mail data extracted:")
    print(json.dumps(data, indent=4, ensure_ascii=False))

    browser.close()

def check_role_type(playwright, parsed_data):
    role_code = parsed_data.get("Requested Role")

    browser = playwright.chromium.launch(headless=False, slow_mo=1000)
    page = browser.new_page()
    page.goto("http://127.0.0.1:5004/")

    role_code = role_code.strip()

    primary_table = page.locator("text=Primary Role").locator("xpath=following-sibling::div[1]//table")
    primary_role = primary_table.locator(f"td:text('{role_code}')")

    if primary_role.count() > 0:
        print("check role type workflow completed it is a primary role")
        browser.close()
        return "Primary Role"

    secondary_table = page.locator("text=Secondary Roles").locator("xpath=following-sibling::div[1]//table")
    secondary_role = secondary_table.locator(f"td:text('{role_code}')")

    if secondary_role.count() > 0:
        print("check role type workflow completed it is a secondary role")
        browser.close()
        return "Secondary Roles"

    print(f"{role_code} not found ")
    browser.close()
    return "Not Found"



def run_third_server(playwright,parsed_data,role_check):

    role_code = parsed_data.get("Requested Role")
    
    Name = parsed_data.get("Name")
    staff_number = parsed_data.get("Staff Number")

    browser = playwright.chromium.launch(headless=False)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5003")
    time.sleep(2)

    page.fill('input[name="username"]', 'admin')
    page.fill('input[name="password"]', '1234')
    time.sleep(2)
    page.click('button[type="submit"]')
    time.sleep(2)

    page.locator('.action-btn:has-text("User Search")').click()
    time.sleep(2)

    page.fill('input[name="userName"]', staff_number)
    time.sleep(2)

    page.click('#searchBtn')
    time.sleep(2)

    page.locator("td", has_text=Name).click()
    time.sleep(2)

    if role_check == "Secondary Roles":
        page.click('#plusRoleBtn')
        time.sleep(2)
        page.locator("#roleDropdown button", has_text=role_code).click()

        time.sleep(2)

        page.click('.user-detail-ok-btn')
        time.sleep(2)

        print("Third server workflow completed!")

        browser.close()

    if role_check == "Primary Role":

        roles = page.locator(".role-entry")
        roles.nth(0).locator("button.remove-role").click()

        page.click('#plusRoleBtn')
        time.sleep(2)
        page.locator("#roleDropdown button", has_text=role_code).click()
        time.sleep(2)

        page.click('.user-detail-ok-btn')
        time.sleep(2)

        print("Third server workflow completed!")

        browser.close()



if __name__ == "__main__":
    with sync_playwright() as playwright: 
        run_first_server(playwright)

        with open("data_json/User_Requests_mail_data.json", "r") as file:
            parsed_data = json.load(file)

        role_check = check_role_type(playwright, parsed_data)
        
        run_third_server(playwright,parsed_data,role_check)
