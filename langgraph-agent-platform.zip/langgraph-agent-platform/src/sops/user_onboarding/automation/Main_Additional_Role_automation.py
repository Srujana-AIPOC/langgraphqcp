import re
import json
import time
from playwright.sync_api import sync_playwright


def run_first_server(playwright):
    browser = playwright.chromium.launch(headless=False, slow_mo=2000)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5001/")
    page.click('#btn-raised-requests')
    time.sleep(1) 


    page.wait_for_selector(".mail-item")   
    time.sleep(1)

    page.locator(".mail-item").first.click()
    time.sleep(1)

    page.wait_for_selector(".mail-body")
    time.sleep(1)

    mail_text = page.inner_text(".mail-body")
    time.sleep(1)

    patterns = {
        "From": r"From:\s*(.*)",
        "Staff Number": r"Staff Number:\s*(\d+)",
        "Name": r"Name:\s*(.*)",
        "Email": r"Email:\s*([\w\.-]+@[\w\.-]+)",
        "Company/ AMO / Role": r"Company/ AMO / Role:\s*(.*)",
        "Mainteniy Trained": r"Mainteniy Trained:\s*(.*)",
        "Phone Number": r"Phone Number:\s*(.*)",
        "Role/ Contract End Date": r"Role/ Contract End Date:\s*(.*)",
        "Request Reason": r"Request Reason:\s*(.*)",
        "Requested Role": r"Requested Role:\s*(.*)",
        "Requested Timesheet Role(s)": r"Requested Timesheet Role\(s\):\s*(.*)",
        "Department(s)": r"Department\(s\):\s*(.*)",
        "Aircraft Type Authorities": r"Aircraft Type Authorities:\s*(.*)",
        "Authorisations/ Licences": r"Authorisations/ Licences:\s*(.*)",
        "Licence/Authorisation No": r"Licence/Authorisation No:\s*(.*)",
        "Additional Notes": r"Additional Notes:\s*(.*)"
    }

    data = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, mail_text, re.MULTILINE)
        data[key] = match.group(1).strip() if match else ""

    with open("data_json/Additional_role_requests_mail.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    print("Mail data extracted:")
    print(json.dumps(data, indent=4, ensure_ascii=False))

    browser.close()


def role_approval(playwright):
    browser = playwright.chromium.launch(headless=False, slow_mo=2000)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5001/")
    page.click('#btn-role-owner')
    time.sleep(2) 


    page.wait_for_selector(".mail-item")   
    time.sleep(1)

    page.locator(".mail-item").first.click()
    time.sleep(1)

    page.wait_for_selector(".mail-body")
    time.sleep(1)

    mail_text = page.inner_text(".mail-body")
    time.sleep(1)

    pattern = re.compile(
    r"From:\s*(?P<from_name>.+?)\s*<(?P<from_email>[^>]+)>\s*�?�\s*"
    r"To:\s*(?P<to_name>.+?)\s*<(?P<to_email>[^>]+)>\s*�?�\s*"
    r"(?P<date>[A-Za-z]{3}\s+\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}\s*[APM]{2})")

    match = pattern.search(mail_text)
    if match:
        from_name = match.group("from_name")
        from_email = match.group("from_email")
        to_name = match.group("to_name")
        to_email = match.group("to_email")
        date = match.group("date")

        staff_no_match = re.search(r"staff no\s+(\d+)", mail_text, re.IGNORECASE)
        staff_no = staff_no_match.group(1) if staff_no_match else None

        result = {
            "From Name": from_name,
            "From Email": from_email,
            "To Name": to_name,
            "To Email": to_email,
            "Date": date,
            "Staff No": staff_no
        }
        print(result)

        with open("data_json/Role_owner_aproved_mail.json", "w") as f:
            json.dump(result, f, indent=4)

        print("Role owner aproved mail data saved ")

    browser.close()

def check_approved_role(parsed_data,role_owner_data):
    staff_number = parsed_data.get("Staff Number")
    role_owner_approved = role_owner_data.get("Staff No")
    print(staff_number,role_owner_approved)
    if staff_number == role_owner_approved:
        return True
    return False

def run_third_server(playwright,parsed_data):

    role_code = parsed_data.get("Requested Role")
    
    Name = parsed_data.get("Name")
    staff_number = parsed_data.get("Staff Number")

    browser = playwright.chromium.launch(headless=False)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5003")
    time.sleep(2)

    page.fill('input[name="username"]', 'admin')
    page.fill('input[name="password"]', '1234')
    time.sleep(2)
    page.click('button[type="submit"]')
    time.sleep(2)

    page.locator('.action-btn:has-text("User Search")').click()
    time.sleep(2)

    page.fill('input[name="userName"]', staff_number)
    time.sleep(2)

    page.click('#searchBtn')
    time.sleep(2)

    page.locator("td", has_text=Name).click()
    time.sleep(2)

    page.click('#plusRoleBtn')
    time.sleep(2)
    page.locator("#roleDropdown button", has_text=role_code).click()

    time.sleep(2)

    page.click('.user-detail-ok-btn')
    time.sleep(2)

    print("Third server workflow completed!")

    browser.close()




if __name__ == "__main__":
    with sync_playwright() as playwright: 
        run_first_server(playwright)

        with open("data_json/Additional_role_requests_mail.json", "r") as file:
            parsed_data = json.load(file)

        role_approval(playwright)

        with open("data_json/Role_owner_aproved_mail.json", "r") as file:
            role_owner_data = json.load(file)

        approved_or_not = check_approved_role(parsed_data,role_owner_data)
        if approved_or_not == True:
            print("Role owner has approved the request.")
            run_third_server(playwright,parsed_data)
        else:
            print("Role owner has not approved the request.")

        
