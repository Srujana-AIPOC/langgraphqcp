import re
import json
import time
import os
from pathlib import Path
from playwright.sync_api import sync_playwright
from langgraph.graph import StateGraph, START, END
from typing import TypedDict, Literal, Dict, Any

class AutomationState(TypedDict, total=False):
    parsed_data: Dict[str, Any]
    first_server_execution: bool
    staff_number_get: bool
    row_locator: Any
    page: Any
    browser: Any
    playwright: Any

def _data_dir() -> str:
    base = Path(__file__).resolve().parents[1] / "data_json"
    run_id = os.getenv("RUN_ID")
    if run_id:
        base = base / run_id
    base.mkdir(parents=True, exist_ok=True)
    return str(base)

def first_server_node(state: AutomationState) -> dict:
    data_dir = _data_dir()

    playwright = sync_playwright().start()


    browser = playwright.chromium.launch(headless=False, slow_mo=2000)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5001/")
    # Click the New Requests folder by stable id (defined in outlook_page.html)
    page.click('#btn-new-requests')
    time.sleep(1) 
    page.wait_for_selector(".mail-item")   
    time.sleep(1)
    page.locator(".mail-item").first.click()
    time.sleep(1)

    page.wait_for_selector(".mail-body")
    time.sleep(1)

    mail_text = page.inner_text(".mail-body")
    time.sleep(1)

    patterns = {
        "From": r"From:\s*(.*)",
        "Staff Number": r"Staff Number:\s*(\d+)",
        "Name": r"Name:\s*(.*)",
        "Email": r"Email:\s*([\\w\\.-]+@[\\w\\.-]+)",
        "Company/ AMO / Role": r"Company/ AMO / Role:\s*(.*)",
        "Mainteniy Trained": r"Mainteniy Trained:\s*(.*)",
        "Phone Number": r"Phone Number:\s*(.*)",
        "Role/ Contract End Date": r"Role/ Contract End Date:\s*(.*)",
        "Request Reason": r"Request Reason:\s*(.*)",
        "Requested Role": r"Requested Role:\s*(.*)",
        "Requested Timesheet Role(s)": r"Requested Timesheet Role\\(s\\):\\s*(.*)",
        "Department(s)": r"Department\\(s\\):\\s*(.*)",
        "Aircraft Type Authorities": r"Aircraft Type Authorities:\s*(.*)",
        "Authorisations/ Licences": r"Authorisations/ Licences:\s*(.*)",
        "Licence/Authorisation No": r"Licence/Authorisation No:\s*(.*)",
        "Additional Notes": r"Additional Notes:\s*(.*)"
    }

    data = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, mail_text, re.MULTILINE)
        data[key] = match.group(1).strip() if match else ""

    with open(str(Path(data_dir) / "New_Requests_mail_data.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    print("Mail data extracted:")
    print(json.dumps(data, indent=4, ensure_ascii=False))

    browser.close()
    playwright.stop()

    return {"parsed_data": data, "first_server_execution": True}

def second_server_node(state: AutomationState) -> dict:
    parsed_data = state.get("parsed_data", {})
    staff_number = parsed_data.get("Staff Number", "")

    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(headless=False, slow_mo=500)
    page = browser.new_page()
    page.goto("http://127.0.0.1:5002/")
    page.wait_for_timeout(2000)
    page.locator('button.dropdown-btn', has_text="Home").click()
    page.wait_for_timeout(2000)
    page.locator('button.nested-btn', has_text="Manage Access for Others").click()
    page.wait_for_timeout(2000)
    page.locator('a#requestAccessOthers').click()
    page.wait_for_timeout(2000)
    page.fill('#userSearch', staff_number)
    page.keyboard.press("Enter")
    page.wait_for_timeout(2000)
    row_locator = page.locator("table#userTable tr", has_text=staff_number)
    result = {
        "staff_number_get": row_locator.count()> 0,
        "row_locator": row_locator,
        "page": page,
        "browser": browser,
        "playwright": playwright
    }
    return result

def second_server_node_true(state: AutomationState) -> dict:
    row_locator = state.get("row_locator")
    page = state.get("page")
    browser = state.get("browser")
    playwright = state.get("playwright")

    row_locator.locator("button.redirect-btn").click()
    page.locator('.app-item', has_text="Active Directory").locator("button").click()
    page.wait_for_timeout(3000)
    page.fill('#availableSearch', 'AU-MyApps-POCapp-Prod')
    page.keyboard.press("Enter")
    page.wait_for_timeout(2000)
    page.locator('#availablePanel .entitlement-item', has_text="AU-MyApps-POCapp-Prod").locator("button").click()
    page.wait_for_timeout(3000)
    page.locator('#nextBtn').click()
    page.wait_for_timeout(2000)
    page.fill('textarea', 'To perform activities related to Business Analysis')
    page.wait_for_timeout(2000)
    page.locator('#submitBtn').click()
    page.wait_for_timeout(5000)
    print("Second server automation completed!")
    browser.close()
    playwright.stop()
    return {}

def second_server_node_false(state: AutomationState) -> dict:
    row_locator = state.get("row_locator")
    browser = state.get("browser")
    playwright = state.get("playwright")
    print(row_locator)
    browser.close()
    playwright.stop()
    return {}


def check_condition(state: AutomationState) -> Literal["second_server_node_true", "second_server_node_false"]:
    if state.get("staff_number_get") is True:
        return "second_server_node_true"
    else:
        return "second_server_node_false"

def third_server_node(state: AutomationState) -> AutomationState:
    parsed_data = state.get("parsed_data", {})
    Department = parsed_data.get("Department(s)")
    role_code = parsed_data.get("Requested Role")
    Name = parsed_data.get("Name")
    staff_number = parsed_data.get("Staff Number")

    xml_text = f"""&lt;?xml version="1.0" encoding="UTF-8"?&gt;
    &lt;ns2:create_user xmlns:ns2="http://xml.com/asd/core/hr/create_user/1.0"&gt;
    &lt;ns2:username&gt;{staff_number}&lt;/ns2:username&gt;
    &lt;ns2:password&gt;password&lt;/ns2:password&gt;
    &lt;ns2:fullname&gt;{Name}&lt;/ns2:fullname&gt;
    &lt;ns2:staff_code&gt;{staff_number}&lt;/ns2:staff_code&gt;
    &lt;ns2:email_address&gt;rama.charan@poc.com&lt;/ns2:email_address&gt;
    &lt;/ns2:create_user&gt;"""

    playwright = sync_playwright().start()

    browser = playwright.chromium.launch(headless=False)
    page = browser.new_page()

    page.goto("http://127.0.0.1:5003")
    time.sleep(2)

    page.fill('input[name="username"]', 'admin')
    page.fill('input[name="password"]', '1234')
    time.sleep(2)
    page.click('button[type="submit"]')
    time.sleep(2)

    page.wait_for_selector(".header .title", timeout=5000)
    time.sleep(2)

    page.click('#dropdownToggle')
    page.wait_for_selector('#dropdownList', state='visible')
    time.sleep(2)

    page.click('#level2SupportMenu')
    page.wait_for_selector('#level2SupportSubMenu', state='visible')
    time.sleep(2)

    page.click('button.submenu-item:text("Job Viewer")')
    time.sleep(2)

    page.wait_for_selector('.send-message-title', timeout=4000)
    time.sleep(2)

    checkbox = page.locator('input[type="checkbox"][name="asynchronous"]')
    if not checkbox.is_checked():
        checkbox.check()
    time.sleep(2)

    page.select_option('select[name="transport"]', 'DMS')
    time.sleep(2)

    page.fill('textarea[name="body"]', xml_text)
    time.sleep(2)

    page.locator('button:has-text("OK")').click()
    time.sleep(2)
    page.click("button:has-text('Cancel')")
    time.sleep(2)

    page.locator('.action-btn:has-text("User Search")').click()
    time.sleep(2)

    page.fill('input[name="userName"]', staff_number)
    time.sleep(2)

    page.click('#searchBtn')
    time.sleep(2)

 
    page.locator("td", has_text=Name).click()
    time.sleep(2)


    page.click('#plusRoleBtn')
    time.sleep(2)

    role_dropdown = page.locator("#roleDropdown")

    role_dropdown.get_by_role("button", name= role_code, exact=True).click()
    # page.locator("#roleDropdown button", has_text=role_code).click()


    time.sleep(2)

    page.get_by_role("button", name="Departments").click()
    time.sleep(2)

    page.click('#assignDeptBtn')
    time.sleep(2)

    page.locator("#departmentDropdown button",has_text=Department).click()  
    time.sleep(2)

    page.click('.user-detail-ok-btn')
    time.sleep(2)

    print("Third server workflow completed!")

    browser.close()
    return state




graph = StateGraph(AutomationState)
graph.add_node("first_server", first_server_node)

graph.add_node("second_server", second_server_node)
graph.add_node("second_server_node_true", second_server_node_true)
graph.add_node("second_server_node_false", second_server_node_false)

graph.add_node("third_server", third_server_node)


graph.add_edge(START, "first_server")
graph.add_edge("first_server", "second_server")
graph.add_conditional_edges("second_server", check_condition, {
    "second_server_node_true": "second_server_node_true",
    "second_server_node_false": "second_server_node_false",
})
graph.add_edge("second_server_node_true", "third_server"),
graph.add_edge("third_server",END)

graph.add_edge("second_server_node_false", END)

app = graph.compile()

def run_workflow() -> dict:
    """Run the compiled graph and return final state."""
    return app.invoke({})

# For direct execution
if __name__ == "__main__":
    run_workflow()
