import re
import json
import time
import os
from pathlib import Path
from playwright.sync_api import sync_playwright, Browser, Playwright
from langgraph.graph import StateGraph, END
from typing import TypedDict, Dict, Any, Literal




class AutomationState(TypedDict):
    """
    Represents the state of our automation graph.
    It holds all the data that needs to be passed from one step to the next.
    """
    playwright: Playwright
    browser: Browser
    parsed_data: Dict[str, Any]
    role_type: Literal["Primary Role", "Secondary Roles", "Not Found"]



def _data_dir() -> str:
    base = Path(__file__).resolve().parents[1] / "data_json"
    run_id = os.getenv("RUN_ID")
    if run_id:
        base = base / run_id
    base.mkdir(parents=True, exist_ok=True)
    return str(base)

def extract_user_request_node(state: AutomationState) -> dict:

    print("EXTRACTING USER REQUEST ---")
    browser = state["browser"]
    page = browser.new_page()

    data_dir = _data_dir()
    
    page.goto("http://127.0.0.1:5001/")
    # Click folder by stable id from templates/outlook_page.html
    page.click('#btn-review-requests')
    page.wait_for_selector(".mail-item")
    page.locator(".mail-item").first.click()
    page.wait_for_selector(".mail-body")

    mail_text = page.inner_text(".mail-body")
    page.close()

    patterns = {
        "From": r"From:\s*(.*)",
        "Staff Number": r"Staff Number:\s*(\d+)",
        "Name": r"Name:\s*(.*)",
        "Email": r"Email:\s*([\w\.-]+@[\w\.-]+)",
        "Company/ AMO / Role": r"Company/ AMO / Role:\s*(.*)",
        "Mainteniy Trained": r"Mainteniy Trained:\s*(.*)",
        "Phone Number": r"Phone Number:\s*(.*)",
        "Role/ Contract End Date": r"Role/ Contract End Date:\s*(.*)",
        "Request Reason": r"Request Reason:\s*(.*)",
        "Requested Role": r"Requested Role:\s*(.*)",
        "Requested Timesheet Role(s)": r"Requested Timesheet Role\(s\):\s*(.*)",
        "Department(s)": r"Department\(s\):\s*(.*)",
        "Aircraft Type Authorities": r"Aircraft Type Authorities:\s*(.*)",
        "Authorisations/ Licences": r"Authorisations/ Licences:\s*(.*)",
        "Licence/Authorisation No": r"Licence/Authorisation No:\s*(.*)",
        "Additional Notes": r"Additional Notes:\s*(.*)"
    }

    data = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, mail_text, re.MULTILINE)
        data[key] = match.group(1).strip() if match else ""

    with open(str(Path(data_dir) / "User_Requests_mail_data.json"), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    print("Mail data extracted successfully:")
    print(json.dumps(data, indent=2))
    
    return {"parsed_data": data}

def check_role_type_node(state: AutomationState) -> dict:

    print("CHECKING ROLE TYPE")
    browser = state["browser"]
    parsed_data = state["parsed_data"]
    role_code = parsed_data.get("Requested Role", "").strip()

    page = browser.new_page()
    page.goto("http://127.0.0.1:5004/")

    primary_table = page.locator("text=Primary Role").locator("xpath=following-sibling::div[1]//table")
    if primary_table.locator(f"td:text-is('{role_code}')").count() > 0:
        print(f"Role '{role_code}' found. Type: Primary Role")
        page.close()
        return {"role_type": "Primary Role"}
    
    secondary_table = page.locator("text=Secondary Roles").locator("xpath=following-sibling::div[1]//table")
    if secondary_table.locator(f"td:text-is('{role_code}')").count() > 0:
        print(f"Role '{role_code}' found. Type: Secondary Roles")
        page.close()
        return {"role_type": "Secondary Roles"}

    print(f"Role '{role_code}' not found in any table.")
    page.close()
    return {"role_type": "Not Found"}

def update_user_role_node(state: AutomationState) -> None:

    print("UPDATING USER ROLE")
    browser = state["browser"]
    parsed_data = state["parsed_data"]
    role_type = state["role_type"]
    

    role_code = parsed_data.get("Requested Role")
    name = parsed_data.get("Name")
    staff_number = parsed_data.get("Staff Number")

    page = browser.new_page()
    page.goto("http://127.0.0.1:5003")


    page.fill('input[name="username"]', 'admin')
    page.fill('input[name="password"]', '1234')
    page.click('button[type="submit"]')
    page.wait_for_load_state("networkidle")


    page.locator('.action-btn:has-text("User Search")').click()
    page.fill('input[name="userName"]', staff_number)
    page.click('#searchBtn')
    page.locator("td", has_text=name).click()
    page.wait_for_selector("#plusRoleBtn") 

    if role_type == "Secondary Roles":
        print(f"Adding secondary role: '{role_code}'...")
        page.click('#plusRoleBtn')
        page.locator("#roleDropdown button", has_text=role_code).click()

    elif role_type == "Primary Role":
        print(f"Replacing primary role with: '{role_code}'...")
        
        page.locator(".role-entry").first.locator("button.remove-role").click()
        page.click('#plusRoleBtn')
        page.locator("#roleDropdown button", has_text=role_code).click()

    page.click('.user-detail-ok-btn')
    page.wait_for_load_state("networkidle")
    print("User role updated successfully!")
    page.close()
    
def decide_next_step(state: AutomationState) -> str:

    print("DECISION POINT")
    role_type = state.get("role_type")
    if role_type in ["Primary Role", "Secondary Roles"]:
        print(f"Role type is '{role_type}'. Proceeding to update.")
        return "update_user_role_node"
    else:
        print("Role not found. Halting workflow.")
        return END


workflow = StateGraph(AutomationState)

workflow.add_node("extract_user_request_node", extract_user_request_node)
workflow.add_node("check_role_type_node", check_role_type_node)
workflow.add_node("update_user_role_node", update_user_role_node)

workflow.set_entry_point("extract_user_request_node")
workflow.add_edge("extract_user_request_node", "check_role_type_node")
workflow.add_conditional_edges(
    "check_role_type_node",
    decide_next_step,
    {
        "update_user_role_node": "update_user_role_node",
        END: END
    }
)
workflow.add_edge("update_user_role_node", END)

app = workflow.compile()

def run_workflow(headful: bool = True, slow: int = 500) -> dict:
    """Run the compiled graph with an explicit Playwright context."""
    playwright = None
    browser = None
    try:
        playwright = sync_playwright().start()
        browser = playwright.chromium.launch(headless=not headful, slow_mo=slow)
        initial_state = {"playwright": playwright, "browser": browser}
        return app.invoke(initial_state)
    finally:
        if browser:
            browser.close()
        if playwright:
            playwright.stop()


if __name__ == "__main__":
    run_workflow()
