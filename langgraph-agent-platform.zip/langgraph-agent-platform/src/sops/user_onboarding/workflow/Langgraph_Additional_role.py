import re
import json
import time
from playwright.sync_api import sync_playwright
from typing import TypedDict, Optional

from langgraph.graph import StateGraph, END

# ----------------------------------------------------------------------------
# 1. Define the State
# This dictionary-like object will hold our data as it passes through the graph.
# It replaces the need to write and read intermediate JSON files.
# ----------------------------------------------------------------------------
class AgentState(TypedDict):
    """
    Represents the state of our automation graph.
    
    Attributes:
        request_data: Data extracted from the initial user request email.
        approval_data: Data extracted from the role owner's approval email.
        is_approved: A boolean flag indicating if the staff numbers match.
        final_message: A concluding message about the workflow's outcome.
    """
    request_data: Optional[dict]
    approval_data: Optional[dict]
    is_approved: Optional[bool]
    final_message: str

# ----------------------------------------------------------------------------
# 2. Define Graph Nodes
# Each function below is a "node" in our graph. It performs a specific task,
# takes the current state as input, and returns a dictionary to update the state.
# ----------------------------------------------------------------------------

def extract_request_node(state: AgentState) -> dict:
    """
    Node 1: Launches a browser to extract the initial role request data from an email.
    This corresponds to the original `run_first_server` function.
    """
    print("--- Executing Node: Extract Request ---")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, slow_mo=1000)
        page = browser.new_page()
        page.goto("http://127.0.0.1:5001/")
        page.click('#btn-raised-requests')
        page.wait_for_selector(".mail-item")
        page.locator(".mail-item").first.click()
        page.wait_for_selector(".mail-body")
        mail_text = page.inner_text(".mail-body")
        browser.close()

    patterns = {
        "From": r"From:\s*(.*)",
        "Staff Number": r"Staff Number:\s*(\d+)",
        "Name": r"Name:\s*(.*)",
        "Email": r"Email:\s*([\w\.-]+@[\w\.-]+)",
        "Company/ AMO / Role": r"Company/ AMO / Role:\s*(.*)",
        "Mainteniy Trained": r"Mainteniy Trained:\s*(.*)",
        "Phone Number": r"Phone Number:\s*(.*)",
        "Role/ Contract End Date": r"Role/ Contract End Date:\s*(.*)",
        "Request Reason": r"Request Reason:\s*(.*)",
        "Requested Role": r"Requested Role:\s*(.*)",
        "Requested Timesheet Role(s)": r"Requested Timesheet Role\(s\):\s*(.*)",
        "Department(s)": r"Department\(s\):\s*(.*)",
        "Aircraft Type Authorities": r"Aircraft Type Authorities:\s*(.*)",
        "Authorisations/ Licences": r"Authorisations/ Licences:\s*(.*)",
        "Licence/Authorisation No": r"Licence/Authorisation No:\s*(.*)",
        "Additional Notes": r"Additional Notes:\s*(.*)"
    }

    data = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, mail_text, re.MULTILINE)
        data[key] = match.group(1).strip() if match else ""
    
    print("Request data extracted:")
    print(json.dumps(data, indent=2))
    
    # Return a dictionary to update the state
    return {"request_data": data}


def extract_approval_node(state: AgentState) -> dict:
    """
    Node 2: Extracts the role owner's approval data from a separate email.
    This corresponds to the original `role_approval` function.
    """
    print("\n--- Executing Node: Extract Approval ---")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, slow_mo=1000)
        page = browser.new_page()
        page.goto("http://127.0.0.1:5001/")
        page.click('#btn-role-owner')
        page.wait_for_selector(".mail-item")
        page.locator(".mail-item").first.click()
        page.wait_for_selector(".mail-body")
        mail_text = page.inner_text(".mail-body")
        browser.close()

    pattern = re.compile(
        r"From:\s*(?P<from_name>.+?)\s*<(?P<from_email>[^>]+)>\s*�?�\s*"
        r"To:\s*(?P<to_name>.+?)\s*<(?P<to_email>[^>]+)>\s*�?�\s*"
        r"(?P<date>[A-Za-z]{3}\s+\d{1,2}/\d{1,2}/\d{4}\s+\d{1,2}:\d{2}\s*[APM]{2})"
    )
    
    match = pattern.search(mail_text)
    result = {}
    if match:
        staff_no_match = re.search(r"staff no\s+(\d+)", mail_text, re.IGNORECASE)
        staff_no = staff_no_match.group(1) if staff_no_match else None
        
        result = {
            "From Name": match.group("from_name"),
            "From Email": match.group("from_email"),
            "To Name": match.group("to_name"),
            "To Email": match.group("to_email"),
            "Date": match.group("date"),
            "Staff No": staff_no,
        }
    
    print("Approval data extracted:")
    print(json.dumps(result, indent=2))
    
    return {"approval_data": result}


def check_approval_node(state: AgentState) -> dict:
    """
    Node 3: Compares the staff numbers from the request and approval data.
    This corresponds to the original `check_approved_role` function.
    """
    print("\n--- Executing Node: Check Approval Status ---")
    request_data = state["request_data"]
    approval_data = state["approval_data"]
    
    staff_number_request = request_data.get("Staff Number")
    staff_number_approval = approval_data.get("Staff No")
    
    print(f"Request Staff No: {staff_number_request}, Approval Staff No: {staff_number_approval}")

    if staff_number_request and staff_number_approval and staff_number_request == staff_number_approval:
        print("�o. Status: APPROVED")
        return {"is_approved": True}
    
    print("�?O Status: REJECTED")
    return {"is_approved": False}


def provision_role_node(state: AgentState) -> dict:
    """
    Node 4: If approved, logs into the admin system and provisions the role.
    This corresponds to the original `run_third_server` function.
    """
    print("\n--- Executing Node: Provision Role ---")
    request_data = state["request_data"]
    role_code = request_data.get("Requested Role")
    name = request_data.get("Name")
    staff_number = request_data.get("Staff Number")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False, slow_mo=1000)
        page = browser.new_page()
        page.goto("http://127.0.0.1:5003")
        page.fill('input[name="username"]', 'admin')
        page.fill('input[name="password"]', '1234')
        page.click('button[type="submit"]')
        page.locator('.action-btn:has-text("User Search")').click()
        page.fill('input[name="userName"]', staff_number)
        page.click('#searchBtn')
        page.locator("td", has_text=name).click()
        page.click('#plusRoleBtn')
        page.locator(f"#roleDropdown button:has-text('{role_code}')").click()
        page.click('.user-detail-ok-btn')
        time.sleep(2) # Allow time to see the final action
        browser.close()

    final_message = f"�o. Role '{role_code}' successfully provisioned for {name} ({staff_number})."
    print(final_message)
    return {"final_message": final_message}


def rejection_node(state: AgentState) -> dict:
    """
    Node 5: A simple node to handle the rejection case.
    """
    print("\n--- Executing Node: Rejection ---")
    final_message = "�?O Role owner has not approved the request. Halting process."
    print(final_message)
    return {"final_message": final_message}

# ----------------------------------------------------------------------------
# 3. Define Conditional Logic
# This function directs the graph's flow after the approval check.
# ----------------------------------------------------------------------------
def decide_next_step(state: AgentState) -> str:
    """
    Determines the next node to execute based on the `is_approved` state field.
    """
    print("\n--- Making Decision ---")
    if state["is_approved"]:
        return "provision_role"  # Name of the node to go to next
    else:
        return "rejection"       # Name of the other node


# ----------------------------------------------------------------------------
# 4. Build and Run the Graph
# ----------------------------------------------------------------------------
if __name__ == "__main__":
    # Initialize the graph
    workflow = StateGraph(AgentState)

    # Add nodes to the graph
    workflow.add_node("extract_request", extract_request_node)
    workflow.add_node("extract_approval", extract_approval_node)
    workflow.add_node("check_approval", check_approval_node)
    workflow.add_node("provision_role", provision_role_node)
    workflow.add_node("rejection", rejection_node)

    # Set the entry point of the graph
    workflow.set_entry_point("extract_request")

    # Add edges to define the standard flow
    workflow.add_edge("extract_request", "extract_approval")
    workflow.add_edge("extract_approval", "check_approval")

    # Add a conditional edge for branching logic
    workflow.add_conditional_edges(
        "check_approval",      # The node where the decision is made
        decide_next_step,      # The function that makes the decision
        {
            "provision_role": "provision_role", # If decision is "provision_role", go to this node
            "rejection": "rejection"            # If decision is "rejection", go to this node
        }
    )

    # Define the end points of the graph
    workflow.add_edge("provision_role", END)
    workflow.add_edge("rejection", END)

    # Compile the graph into a runnable application
    app = workflow.compile()
    mermaid_code = app.get_graph().draw_mermaid()

    print(mermaid_code)


    # Define the initial state (can be empty)
    initial_state = {
        "request_data": None,
        "approval_data": None,
        "is_approved": None,
        "final_message": ""
    }

    print("dYs? Starting LangGraph Workflow...")
    
    # Run the graph and get the final state
    final_state = app.invoke(initial_state)

    print("\ndY?? Workflow Finished!")
    print("--- Final Outcome ---")
    print(final_state['final_message'])
