from __future__ import annotations
import asyncio
import concurrent.futures
import functools
from typing import Any, Dict

# Workflows
from .workflow import Langgraph_New_user as new_user_flow
from .workflow import Langgraph_User_role_addition as add_role_flow


def _run_user_onboarding_subprocess(subsop: str, headful: bool, slow: int, run_id: str | None = None) -> Dict[str, Any]:
    import os
    if run_id:
        os.environ["RUN_ID"] = run_id
    subsop = subsop.lower()
    if subsop == "new_user":
        state = new_user_flow.run_workflow()
        return {"subsop": subsop, "state": state}
    elif subsop in ("additional_role", "user_role_addition"):
        state = add_role_flow.run_workflow(headful=headful, slow=slow)
        return {"subsop": subsop, "state": state}
    else:
        raise ValueError(f"Unknown subsop: {subsop}")


class UserOnboardingSOP:
    sop_id = "user-onboarding"

    def __init__(self, connections_cfg: Dict[str, Any]) -> None:
        # Placeholder for parity with other SOPs; no DB needed here
        self.connections = connections_cfg

    async def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        headful = bool(payload.get("headful", True))
        slow = int(payload.get("slow", 500))
        subsop = (payload.get("subsop") or "new_user").lower()

        # Run in a dedicated subprocess for strong isolation (separate browser instance)
        loop = asyncio.get_running_loop()
        fn = functools.partial(_run_user_onboarding_subprocess, subsop, headful, slow, payload.get("_run_id"))
        with concurrent.futures.ProcessPoolExecutor(max_workers=1) as pool:
            result = await loop.run_in_executor(pool, fn)
        return result
