from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import json
import ollama
import subprocess
import os

# Get the root directory of the Chatbot project
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  


# Initialize Flask app and enable CORS for all routes
app = Flask(__name__)
CORS(app)  # Allow cross-origin requests


# Load records from records.json file at startup
records_path = os.path.join(os.path.dirname(__file__), "records.json")
with open(records_path) as f:
    records = json.load(f)

# parser to extract fields if Ollama fails (fallback)
def simple_parser(prompt: str):
    parts = [p.strip() for p in prompt.split(",")]
    if len(parts) >= 3:
        return {
            "Configuration Item": parts[0],
            "Short Description": parts[1],
            "Change Owner Group": parts[2]
        }
    return None

# Normalize dropdown values to match frontend dropdown options
def normalize_dropdown_value(field, value):
    value = value.strip()
    
    mappings = {
        # Define mappings for dropdown fields to ensure consistency with frontend
        "type": {
            "normal": "normal",
            "emergency": "emergency",
            "standard": "standard"
        },
        "category": {
            "Deploy/Commission": "Deploy/Commission",
            "Reload/Reboot/Restart": "Reload/Reboot/Restart"
        },
        "natureOfChange": {
            "business as usual (BAU)": "business as usual (BAU)",
            "major project": "major project"
        },
        "affectedAirline": {
            "tantasabc": "tantasabc",
            "jetstar": "jetstar"
        },
        "environment": {
            "Production": "Production",
            "production": "Production",
            "production/staging": "Staging",
            "Staging": "Staging"
        },
        "hasPeerReviewed": {
            "Yes": "Yes",
            "No": "No",
            "yes/not applicable": "Not Applicable"
        },
        "didPreviousAttemptCauseIncident": {
            "Yes": "Yes",
            "No": "No"
        },
        "isThereImpactRollback": {
            "No Outage, No Impact": "No Outage, No Impact",
            "Outage Required, Associated Impact": "Outage Required, Associated Impact"
        },
        "isThereImpactImplementation": {
            "No Outage, No Impact": "No Outage, No Impact",
            "Outage Required, Associated Impact": "Outage Required, Associated Impact"
        },
        "rollbackDuration": {
            "0/1800": "0/1800",
            "0/3600": "0/3600",
            "0": "0"
        }
    }

    if field in mappings:
        return mappings[field].get(value, value)

    return value

# Normalize record keys to camelCase for frontend compatibility
def normalize_keys(record):
    
    mapping = {
        "Short Description": "shortDescription",
        "Configuration Item": "configItem",
        "Change Owner Group": "changeOwnerGroup",
        "Change Owner group": "changeOwnerGroup",  
        "Change Owner": "changeOwner",
        "Coordinator Group": "coordinatorGroup",
        "Change Coordinator": "changeCoordinator",
        "Type": "type",
        "Category": "category",
        "Nature of Change": "natureOfChange",
        "Affected Airline": "affectedAirline",
        "Technical Review Approval": "technicalReviewApproval",
        "Change Initiated From": "changeInitiatedFrom",
        "Reason for Change/Additional Commentary": "reasonForChangeAdditionalCommentary",
        "Reason for Change/ Additional Commentary": "reasonForChangeAdditionalCommentary",  
        
    }
    result = {}
    for k, v in record.items():
        key = mapping.get(k, k)
        # Normalize dropdown values for specific fields
        if key in ["category", "natureOfChange", "affectedAirline"]:
            result[key] = normalize_dropdown_value(key, v)
        else:
            result[key] = v
    return result

# case/space-insensitive matching of strings
def case_mismatchmatch(a, b):
    return a.replace(" ", "").lower() == b.replace(" ", "").lower()


@app.route("/create_change", methods=["POST"])
def create_change():
    user_prompt = request.json.get("prompt")
    if not user_prompt:
        return jsonify({"error": "No prompt provided"}), 400

   
    data = None
    try:
        response = ollama.chat(
            model="phi3",
            messages=[{
                "role": "user",
                "content": (
                    f"From this request: {user_prompt}\n"
                    f"Extract the EXACT values for these fields as present in the following list of options:\n"
                    f"Short Description options: {[r['Short Description'] for r in records]}\n"
                    f"Configuration Item options: {[r['Configuration Item'] for r in records]}\n"
                    f"Change Owner Group options: {[r['Change Owner Group'] for r in records]}\n"
                    f"Respond ONLY in JSON with this format: "
                    f'{{"Short Description": "...", "Configuration Item": "...", "Change Owner Group": "..."}}'
                )
            }]
        )
        raw_content = response["message"]["content"].strip() if "message" in response else ""
        print("DEBUG Ollama raw:", raw_content)
        data = json.loads(raw_content)
    except Exception as e:
        print(" Ollama failed, falling back:", str(e))
        data = simple_parser(user_prompt)

    if not data:
        return jsonify({"error": "Failed to parse prompt"}), 500

    # Find a matching record using case_mismatchmatch for the key fields
    match = next(
        (r for r in records
         if case_mismatchmatch(r.get("Short Description", ""), data.get("Short Description", ""))
         and case_mismatchmatch(r.get("Configuration Item", ""), data.get("Configuration Item", ""))
         and case_mismatchmatch(r.get("Change Owner Group", ""), data.get("Change Owner Group", ""))
        ),
        None
    )

    if not match:
        return jsonify({"error": "No matching record found."}), 404

    # Save the matched record to a temp file for automation
    temp_file = os.path.join(os.path.dirname(__file__), "temp_record.json")
    with open(temp_file, "w") as f:
        json.dump(match, f)

    # Launch Playwright automation script as a separate process
    automation_path = os.path.join(BASE_DIR, "automation", "playwright_bot.py")
    subprocess.Popen(["python", automation_path, temp_file])

    # Return the normalized record for frontend use
    return jsonify({"status": "success", "filledRecord": normalize_keys(match)})


@app.route("/")
def serve_chatbot():
    return send_from_directory(os.path.join(BASE_DIR, "chatbot_frontend"), "chatbot.html")

@app.route("/servicenow/<path:filename>")
def serve_servicenow_files(filename):
    return send_from_directory(os.path.join(BASE_DIR, "servicenow"), filename)

if __name__ == "__main__":
    app.run(port=5000, debug=True)
