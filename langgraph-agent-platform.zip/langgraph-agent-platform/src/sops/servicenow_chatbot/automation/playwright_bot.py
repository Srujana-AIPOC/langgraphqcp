import sys
import os
import json
import re
from playwright.sync_api import sync_playwright

# base directory and error log path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  
ERROR_LOG = os.path.join(BASE_DIR, "playwright_errors.json")

# Define dropdown value mappings for normalization
DROPDOWN_ALIASES = {
    "Type": {
        "normal": "Normal",
        "emergency": "Emergency",
    },
    "Category": {
        "Software": "Software",
        "Hardware": "Hardware",
        "Reload/Reboot/Restart": "Reload/Reboot/Restart",
    },
    "Nature of Change": {
        "Enhancement": "Enhancement",
        "Fix": "Fix",
        "business as usual (BAU)": "business as usual (BAU)",
    },
    "Affected Airline": {
        "tantasabc": "tantasabc",
        "Airline A": "Airline A",
        "Airline B": "Airline B",
    },
    "Technical Review Approval": {
        "Anand Singh": "Anand Singh",
        "High": "High",
        "Medium": "Medium",
    },
    "Change Initiated From": {
        "Other/Problem": "Other/Problem",
        "Incident": "Incident",
        "Request": "Request",
    },
    "Has the change has been peer reviewed?": {
        "Yes": "Yes",
        "No": "No",
    },
    "Did the previous attempt cause an incident?": {
        "Yes": "Yes",
        "No": "No",
    },
}

# Normalize dropdown value to match the actual UI option
def normalize_dropdown(field, value):
    """Map record values to actual dropdown option values."""
    aliases = DROPDOWN_ALIASES.get(field, {})
    return aliases.get(value.strip(), value.strip())

# Convert a string to camelCase 
def to_camel_case(s: str) -> str:
    """Convert JSON field to camelCase ID suggestion."""
    s = re.sub(r'[^a-zA-Z0-9 ]+', '', s)  
    parts = s.strip().split()
    if not parts:
        return ""
    return parts[0].lower() + "".join(word.capitalize() for word in parts[1:])

# Map record fields to dashboard element IDs
field_mapping = {
    "Configuration Item": "changeConfigItem",
    "Short Description": "shortDesc",
    "Change Owner Group": "changeCoordinator",  
    "Requester": "changeRequester",
    "Site Code": "changeSiteCoder",   
    "Contact Number": "contactNumber",
    "Type": "changeType",
    "Service": "changeService",  
    "Category": "changeCategory",
    "Nature of Change": "natureOfChange",  
    "Affected Airline": "affectedAirline",

    "Coordinator Group": "changeCoordGroup",
    "Change Coordinator": "changeAssignedTo",
    "Change Owner": "changeSupportGroup",

    "Technical Review Approval": "techReviewApproval",
    "Manage Approvals": "manageApprovals",  

    "Change Description": "changeDescription",
    "Change Initiated From": "changeInitiatedFrom",
    "Reason for Change/ Additional Commentary": "reasonForChange",
    "Environment": "environment",

    "Has the change has been peer reviewed?": "peerReviewed",
    "Please provide name and contact details of who is responsible for technically signing off the peer-review. All relevant testing documentation should be attached to this change record": "peerReviewerContact",

    "Is there an impact associated with the planned Rollback/Backout": "rollbackImpact",
    "Please provide justified reason ": "rollbackReason",
    "Is there an impact associated with the planned implementation": "implementationImpact",
    "Please provide justified reason": "implementationReason",

    "Did the previous attempt cause an incident?": "previousIncident",
    "The potential impact if the change is unsuccessful": "potentialImpact",
    "Risk": "riskField",     
    "State": "stateField",   

    "Implementation Plan": "implementationPlan",
    "Verification Plan": "verificationPlan",
    "Rollback Plan": "rollbackPlan",
    "Rollback Duration": "rollbackDuration",
}


def main(record_file):
    # Load the record to be filled from the JSON file
    with open(record_file, "r") as f:
        record = json.load(f)

    dashboard_url = "http://localhost:5000/servicenow/dashboard.html"
    errors = []

    # Start Playwright and open the dashboard page
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()

        print(f" Opening {dashboard_url}")
        page.goto(dashboard_url)

        # Iterate over each field in the record and try to fill/select it in the UI
        for field, value in record.items():
            target_id = field_mapping.get(field)

            if not target_id:
                # If no mapping, suggest a camelCase ID and log the error
                suggested_id = to_camel_case(field)
                msg = f"No mapping for {field}, suggested id={suggested_id}"
                print(f" {msg}")
                errors.append({"field": field, "value": value, "error": msg})
                continue

            normalized_value = normalize_dropdown(field, str(value))
            selector = f"#{target_id}"

            try:
                element = page.query_selector(selector)
                if not element:
                    msg = f"No element found for {field} (id={target_id})"
                    print(f" {msg}")
                    errors.append({"field": field, "value": value, "error": msg})
                    continue

                tag = element.evaluate("el => el.tagName.toLowerCase()")
                if tag in ["input", "textarea"]:
                    # Fill input or textarea fields
                    page.fill(selector, str(value))
                    print(f"Filled {field} -> {value}")

                elif tag == "select":
                    # Try to select dropdown options by value or label
                    success = False
                    try:
                        page.select_option(selector, value=normalized_value)
                        print(f"Selected {field} -> {value} (by value)")
                        success = True
                    except Exception:
                        try:
                            page.select_option(selector, label=normalized_value)
                            print(f"Selected {field} -> {value} (by label)")
                            success = True
                        except Exception:
                            # Try case-insensitive match if direct match fails
                            options = element.evaluate("el => Array.from(el.options).map(o => o.text)")
                            match = next((opt for opt in options if opt.lower() == normalized_value.lower()), None)
                            if match:
                                page.select_option(selector, label=match)
                                print(f"Selected {field} -> {value} (case-insensitive match)")
                                success = True
                            else:
                                msg = f"No matching option for {field}: {value} (tried {normalized_value})"
                                print(f"{msg}")
                                errors.append({"field": field, "value": value, "error": msg})

                else:
                    # Unsupported element type
                    msg = f"Unsupported element type for {field} ({tag})"
                    print(f"{msg}")
                    errors.append({"field": field, "value": value, "error": msg})

            except Exception as e:
                # Catch and log any errors during filling/selecting
                msg = f"Failed to fill {field}: {e}"
                print(f"{msg}")
                errors.append({"field": field, "value": value, "error": msg})

        # Write errors to a log file if any occurred
        if errors:
            with open(ERROR_LOG, "w") as ef:
                json.dump(errors, ef, indent=2)
            print(f"\n Some fields failed. See log: {ERROR_LOG}")
        else:
            print("\n All fields filled successfully!")

        print(" Autofill complete. Browser will stay open for review.")
        page.wait_for_timeout(10000)
        browser.close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python playwright_bot.py <record_file>")
    else:
        main(sys.argv[1])
