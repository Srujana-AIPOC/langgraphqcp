from pydantic import BaseModel

class PsubState(BaseModel):
    key: str | None = None
    rows: list[dict] = []

