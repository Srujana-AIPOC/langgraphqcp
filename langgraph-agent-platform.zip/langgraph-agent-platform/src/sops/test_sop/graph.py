import os
from typing import Any, Dict
from platform_core.agents.dbops.service import DBOpsService

TEMPLATE = "src/platform_core/agents/dbops/templates/postgres/psub_pg/get_psub_rows_by_key.sql"

class TestSOP:
    sop_id = "test-sop"

    def __init__(self, connections_cfg: Dict[str, Any]) -> None:
        self.db = DBOpsService(connections_cfg)

    async def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        key = payload.get("key", "demo")
        result = await self.db.select_template(
            target_db="psub_pg",
            sop_id=self.sop_id,
            template_path=TEMPLATE,
            params={"key": key},
        )
        return {"rows": result["rows"]}
