from typing import TypedDict, List, Dict

class PsubInput(TypedDict, total=False):
    key: str

class PsubOutput(TypedDict, total=False):
    rows: List[Dict]

