from __future__ import annotations
from pathlib import Path
from datetime import datetime
import json
from typing import Any

def _now_iso() -> str:
    return datetime.now().isoformat(timespec="milliseconds")

def start_audit() -> Path:
    """
    Create a new run-audit JSON with a unique filename and empty events array.
    Returns the path so callers can stash it in state['audit_file'].
    """
    out = Path("output/data")
    out.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = out / f"run_audit_{run_id}.json"
    data = {"run_id": run_id, "started_at": _now_iso(), "ended_at": None, "events": []}
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path

def log_event(audit_file: str | Path, node: str, status: str, details: dict[str, Any] | None = None) -> None:
    """
    Append an event to the audit JSON. status: "ok" | "fail" | "skip"
    """
    if not audit_file:
        return
    path = Path(audit_file)
    if not path.exists():
        return
    data = json.loads(path.read_text(encoding="utf-8") or "{}")
    data.setdefault("events", [])
    data["events"].append({
        "ts": _now_iso(),
        "node": node,
        "status": status,
        "details": details or {},
    })
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

def finalize(audit_file: str | Path) -> None:
    """
    Stamp ended_at and persist.
    """
    if not audit_file:
        return
    path = Path(audit_file)
    if not path.exists():
        return
    data = json.loads(path.read_text(encoding="utf-8") or "{}")
    data["ended_at"] = _now_iso()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
