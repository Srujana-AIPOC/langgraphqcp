import csv
from pathlib import Path

def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p

def write_csv(rows: list[dict], out_path: str | Path) -> Path:
    out = Path(out_path)
    ensure_dir(out.parent)
    if not rows:
        out.write_text("")
        return out
    headers = list(rows[0].keys())
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        w.writerows(rows)
    return out
