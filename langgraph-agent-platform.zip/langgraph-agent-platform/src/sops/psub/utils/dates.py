from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

def now_in_tz(tz_name: str) -> datetime:
    return datetime.now(ZoneInfo(tz_name))

def yesterday(tz_name: str) -> datetime:
    return now_in_tz(tz_name) - timedelta(days=1)

def parse_iso_or_rel(text_or_iso: str) -> datetime | None:
    """
    Helper if needed in the future; not used directly now.
    """
    try:
        # GitHub uses <relative-time datetime="2025-08-21T18:45:02Z">
        return datetime.fromisoformat(text_or_iso.replace("Z", "+00:00"))
    except Exception:
        return None
