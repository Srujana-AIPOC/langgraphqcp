from __future__ import annotations
from typing import List, Tuple, Dict, Any
from pathlib import Path
import math

import pdfplumber

# Optional imports only used if screenshots enabled
try:
    import fitz  # PyMuPDF
except Exception:
    fitz = None  # type: ignore

def open_pdf(path: str | Path) -> pdfplumber.PDF:
    return pdfplumber.open(str(path))

def page_size_pts(page) -> Tuple[float, float]:
    # pdfplumber page.width/height are in points
    return float(page.width), float(page.height)

def rel_to_bbox(page, rel: Tuple[float, float, float, float]) -> Tuple[float, float, float, float]:
    """Convert relative (l, t, r, b) in 0..1 to absolute (x0, y0, x1, y1) in pts."""
    w, h = page_size_pts(page)
    l, t, r, b = rel
    return (l * w, t * h, r * w, b * h)

def words_in_bbox(page, bbox) -> List[Dict[str, Any]]:
    """Return words with positions inside bbox (x0,y0,x1,y1)."""
    x0, y0, x1, y1 = bbox
    words = page.extract_words(use_text_flow=True, keep_blank_chars=False)
    out = []
    for w in words:
        if w["x0"] >= x0 and w["x1"] <= x1 and w["top"] >= y0 and w["bottom"] <= y1:
            out.append(w)
    return out

def lines_from_words(words: List[Dict[str, Any]], y_tol: float = 2.0) -> List[Dict[str, Any]]:
    """
    Group words into text lines by Y proximity; return [{text, x0, x1, top, bottom}].
    """
    if not words:
        return []
    # sort by top,y then x
    words = sorted(words, key=lambda w: (w["top"], w["x0"]))
    lines: List[List[Dict[str, Any]]] = []
    cur: List[Dict[str, Any]] = [words[0]]
    for w in words[1:]:
        if abs(w["top"] - cur[-1]["top"]) <= y_tol:
            cur.append(w)
        else:
            lines.append(cur)
            cur = [w]
    lines.append(cur)

    out = []
    for ln in lines:
        text = " ".join(w["text"] for w in ln).strip()
        x0 = min(w["x0"] for w in ln)
        x1 = max(w["x1"] for w in ln)
        top = min(w["top"] for w in ln)
        bottom = max(w["bottom"] for w in ln)
        out.append({"text": text, "x0": x0, "x1": x1, "top": top, "bottom": bottom})
    return out

def extract_tables_in_region(page, bbox) -> list[list]:
    """
    Crop to region and try extracting tables. Return list-of-lists rows (strings).
    """
    cropped = page.crop(bbox)  # <-- no "with" context; just get the CroppedPage
    tables = cropped.extract_tables() or []
    rows: list[list] = []
    for t in tables:
        for r in (t or []):
            rows.append([(c or "").strip() for c in r])
    return rows


def count_lines_in_region(page, bbox) -> int:
    """Approximate gridlines by counting page line segments that fall inside bbox."""
    x0, y0, x1, y1 = bbox
    # pdfplumber has page.lines; filter by bbox
    lines = [ln for ln in getattr(page, "lines", []) if (ln["x0"] >= x0 and ln["x1"] <= x1 and ln["y0"] >= y0 and ln["y1"] <= y1)]
    return len(lines)

def render_pages_to_png(pdf_path: str | Path, out_dir: Path, dpi: int = 150, max_pages: int | None = None) -> list[str]:
    """Optional evidence rendering with PyMuPDF."""
    if fitz is None:
        return []
    out_dir.mkdir(parents=True, exist_ok=True)
    paths: list[str] = []
    doc = fitz.open(str(pdf_path))
    try:
        for i, page in enumerate(doc):
            if max_pages is not None and i >= max_pages:
                break
            mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)
            pix = page.get_pixmap(matrix=mat, alpha=False)
            p = out_dir / f"pdf_page_{i+1}.png"
            pix.save(str(p))
            paths.append(str(p))
    finally:
        doc.close()
    return paths
