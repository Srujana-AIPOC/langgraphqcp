from __future__ import annotations
import asyncio
import concurrent.futures
import functools
from typing import Any, Dict

from platform_core.agents.dbops.service import DBOpsService
from platform_core.config.loader import load_config

# Inject DBOps into the workflow's Oracle client
from .workflow.oracle_client import set_dbops_context, clear_dbops_context
from .workflow.runner import run_pipeline


def _run_pipeline_subprocess(connections_cfg: Dict[str, Any], headful: bool, slow: int) -> Dict[str, Any]:
    """Subprocess-safe entry: recreate DBOps and run pipeline with injected context."""
    db = DBOpsService(connections_cfg)
    set_dbops_context(db, "psub-workflow", "psub_oracle")
    try:
        return run_pipeline(headful=headful, slow=slow)
    finally:
        clear_dbops_context()


class PsubWorkflowSOP:
    sop_id = "psub-workflow"

    def __init__(self, connections_cfg: Dict[str, Any], features_cfg: Dict[str, Any] | None = None) -> None:
        self._connections_cfg = connections_cfg
        self._features = features_cfg or {}
        self.db = DBOpsService(connections_cfg)

    async def run(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        headful = bool(payload.get("headful", False))
        slow = int(payload.get("slow", 0))

        # Always run in a separate process to avoid event-loop conflicts and ensure isolation
        loop = asyncio.get_running_loop()
        fn = functools.partial(_run_pipeline_subprocess, self._connections_cfg, headful, slow)
        with concurrent.futures.ProcessPoolExecutor(max_workers=1) as pool:
            state = await loop.run_in_executor(pool, fn)
        return {"state": state}
