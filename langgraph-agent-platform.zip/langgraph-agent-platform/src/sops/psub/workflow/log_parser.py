import re

# strip ANSI escape sequences
ANSI = re.compile(r"\x1B\[[0-9;]*[A-Za-z]")

# host pattern: either IPv4, "localhost", or domain-like with dashes/dots
HOST_PATTERN = r"(?P<host>(?:localhost)|(?:\d{1,3}(?:\.\d{1,3}){3})|(?:[A-Za-z0-9-]+\.[A-Za-z0-9.-]+))"

PATTERNS = [
    re.compile(rf"domain name created[:=\-\s]+\s*{HOST_PATTERN}", re.IGNORECASE),
    re.compile(rf"domain\s+created[:=\-\s]+\s*{HOST_PATTERN}", re.IGNORECASE),
]

def extract_domain_from_text(raw_text: str) -> str | None:
    if not raw_text:
        return None

    cleaned = ANSI.sub("", raw_text)

    for pat in PATTERNS:
        m = pat.search(cleaned)
        if m:
            return m.group("host").strip()

    return None
