# src/workflow/nslookup_check.py
from __future__ import annotations
from ..utils.audit import log_event
from typing import Any
from pathlib import Path
from datetime import datetime
import subprocess

from .config import Settings

def node_nslookup_check(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Run `nslookup <domain>` (domain is configurable) and save the raw output.
    Then set a boolean based on a TEMPORARY, HARD-CODED check:

      - We currently pretend the nslookup response contains alias "127.0.0.1"
        (this is a placeholder until we parse real alias lines).
      - We compare that hardcoded alias with the domain we extracted earlier
        from GitHub raw logs (state["domain"]).
      - If both equal "127.0.0.1" -> true, else false.

    Artifacts:
      - output/data/nslookup_<domain>_<ts>.txt  (raw nslookup output)
      - output/data/nslookup_match_<ts>.txt     ("true" | "false")

    State updates:
      - nslookup_domain        : str
      - nslookup_output_file   : str
      - nslookup_match_file    : str
      - nslookup_match         : bool
    """
    domain = s.nslookup_domain
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("output/data"); out_dir.mkdir(parents=True, exist_ok=True)

    raw_out_path = out_dir / f"nslookup_{domain.replace('.', '_')}_{ts}.txt"
    match_out_path = out_dir / f"nslookup_match_{ts}.txt"

    # Run nslookup and capture output (cross-platform; works on Windows where nslookup is built-in)
    try:
        proc = subprocess.run(
            ["nslookup", domain],
            capture_output=True,
            text=True,
            shell=False,
            timeout=30
        )
        stdout = proc.stdout or ""
        stderr = proc.stderr or ""
        output_text = stdout if stdout else stderr
    except Exception as e:
        output_text = f"[nslookup error] {e}"

    raw_out_path.write_text(output_text, encoding="utf-8")

    # ====== TEMPORARY / HARD-CODED CHECK (per your instruction) ======
    # For now we *assume* the nslookup output should include alias "127.0.0.1"
    # and we compare this value with the GitHub-extracted domain stored in state["domain"].
    # Later we will replace this with a real parser for "Aliases:" lines.
    expected_alias = "127.0.0.1"
    gh_domain = (state.get("domain") or "").strip()

    # We mark success only if the hardcoded alias appears in nslookup output AND
    # the GitHub-extracted domain equals the same hardcoded alias.
    alias_seen_in_output = expected_alias in output_text
    #match = alias_seen_in_output and (gh_domain == expected_alias)  me removed alias_seen_in_output
    match = gh_domain == expected_alias
    # ================================================================

    match_out_path.write_text("true" if match else "false", encoding="utf-8")

    # Update state
    state["nslookup_domain"] = domain
    state["nslookup_output_file"] = str(raw_out_path)
    state["nslookup_match_file"] = str(match_out_path)
    state["nslookup_match"] = match

    audit = state.get("audit_file")
    log_event(audit, "nslookup_check", "ok", {
        "domain": state.get("nslookup_domain"),
        "output_file": state.get("nslookup_output_file"),
        "match": state.get("nslookup_match"),
        "match_file": state.get("nslookup_match_file"),
    })
    return state
