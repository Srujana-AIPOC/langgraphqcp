from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class Settings(BaseSettings):
    github_org: str = Field(env="GITHUB_ORG")
    github_repo: str = Field(env="GITHUB_REPO")

    # Exact title prefix to match (case-insensitive), e.g., "Deploy jysup"
    workflow_title_prefix: str = Field(default="Deploy jysup", env="WORKFLOW_TITLE_PREFIX")

    oracle_user: str = Field(env="ORACLE_USER")
    oracle_password: str = Field(env="ORACLE_PASSWORD")
    oracle_port: int = Field(default=1521, env="ORACLE_PORT")
    oracle_service_name: str = Field(default="ORCLPDB1", env="ORACLE_SERVICE_NAME")
    oracle_sql: str = Field(default="SELECT * FROM dual", env="ORACLE_SQL")

    timezone: str = Field(default="Asia/Kolkata", env="TIMEZONE")
    #headful_default: bool = Field(default=False, env="HEADFUL")
    headful: bool = Field(default=False, env="HEADFUL")
    pw_user_data_dir: str = Field(default=".pw-profile", env="PW_USER_DATA_DIR")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",  # ignore unrelated env vars like APP_ENV, PSUB_PG_DSN, etc.
    )

    # add near your other Fields
    dest_url_substr: str = Field(default="dummy", env="DEST_URL_SUBSTR")


    # --- LSUP Portal UI config ---
    portal_url: str = Field(default="http://localhost:5173/", env="PORTAL_URL")
    portal_user: str = Field(default="admin", env="PORTAL_USER")
    portal_password: str = Field(default="secret123", env="PORTAL_PASSWORD")
    portal_env_filter: str = Field(default="lsup", env="PORTAL_ENV_FILTER")
    # If True, when we log in headful we save storage to output/.pw-lsup.json and reuse it in headless
    portal_save_storage: bool = Field(default=True, env="PORTAL_SAVE_STORAGE")


    # --- nslookup config ---
    nslookup_domain: str = Field(default="google.com", env="NSLOOKUP_DOMAIN")


    # --- General Oracle host (post-nslookup run) ---
    oracle_host_general: str = Field(env="ORACLE_HOST_GENERAL")


    # URL dummy-check SQL (general + original)
    dest_lookup_sql: str = Field(default="select * from int_dest_lookup", env="DEST_LOOKUP_SQL")


    # --- Maintainy (5174) PDF menu automation ---
    portal2_url: str = Field(default="http://localhost:5174/", env="PORTAL2_URL")
    portal2_parent_label: str = Field(default="Operations", env="PORTAL2_PARENT_LABEL")
    portal2_child_label: str = Field(default="Fleet Due List", env="PORTAL2_CHILD_LABEL")
    portal2_download_dir: str = Field(default="output/pdfs", env="PORTAL2_DOWNLOAD_DIR")


    # --- PDF Validation (policy-driven) ---
    pdf_policy_path: str | None = Field(default=None, env="PDF_POLICY_PATH")
    pdf_render_pages: bool = Field(default=False, env="PDF_RENDER_PAGES")     # optional evidence PNGs
    pdf_extract_tables: bool = Field(default=True, env="PDF_EXTRACT_TABLES")  # keep ON for table checks


     # Release propagation wait/poll (seconds)
    portal_release_wait_initial_sec: int = Field(default=30, env="PORTAL_RELEASE_WAIT_INITIAL_SEC")
    portal_release_wait_retries: int = Field(default=2, env="PORTAL_RELEASE_WAIT_RETRIES")
    portal_release_wait_interval_sec: int = Field(default=30, env="PORTAL_RELEASE_WAIT_INTERVAL_SEC")


    pw_slow_mo_ms: int = Field(default=0, env="PW_SLOW_MO_MS")  # how many ms to slow each action
