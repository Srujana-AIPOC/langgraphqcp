from __future__ import annotations
from ..utils.audit import log_event  # NEW

from typing import Any, Optional
from pathlib import Path
from datetime import datetime
import json
import re

from playwright.sync_api import Page

from .config import Settings
# Reuse your existing helpers from the portal node
from .check_lsup_portal import (
    _launch_portal_context,
    _login_if_needed,
    _ensure_builds_tab,
    _parse_rows_for_env,
)

def _pick_lowest_and_highest(rows: list[dict[str, Any]], env: str) -> tuple[Optional[int], Optional[int]]:
    """Return (min_build, max_build) among rows for the given env (case-insensitive)."""
    same_env = [r for r in rows if (r.get("env") or "").strip().lower() == env.lower()]
    nums = [int(r["build"]) for r in same_env if isinstance(r.get("build"), int)]
    if not nums:
        return None, None
    return min(nums), max(nums)

def _click_build_link(page: Page, build_number: int) -> None:
    """
    Click the build link for /app/builds/<build_number> and wait for SPA route.
    """
    sel = f'a[href="/app/builds/{build_number}"]'
    link = page.locator(sel)
    link.first.wait_for(state="visible", timeout=5000)
    link.first.click()
    # Wait for SPA route change and heading on details
    page.wait_for_function(
        """(bn) => window.location.pathname.endsWith(`/app/builds/${bn}`)""",
        arg=build_number,
        timeout=5000,
    )
    try:
        page.get_by_role("heading", name=re.compile(r"^Build Information$", re.I)).wait_for(timeout=3000)
    except Exception:
        pass

def _click_release_accept_alert(page: Page) -> bool:
    """
    Click the 'Release' button and accept the alert/confirm.
    Returns True if a dialog was seen and accepted.
    """
    dialog_seen = False

    def _on_dialog(dlg):
        nonlocal dialog_seen
        dialog_seen = True
        try:
            dlg.accept()
        except Exception:
            pass

    page.once("dialog", _on_dialog)

    # Primary role-based locator; fallback to text
    try:
        page.get_by_role("button", name=re.compile(r"^Release$", re.I)).click(timeout=5000)
    except Exception:
        page.get_by_text(re.compile(r"^Release$", re.I)).click()

    # Give SPA a moment to run context action (setReleased + alert)
    page.wait_for_timeout(300)
    return dialog_seen

def node_lsup_release(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    1) Login to portal, open Builds tab.
    2) Filter env (s.portal_env_filter, e.g. 'lsup').
    3) Pre-check: verify the LOWEST build is green+bold and the other build is normal.
       (Recorded as precheck_ok; does not block release.)
    4) Click the LARGEST build, go to Build Details, click 'Release' and accept the dialog.
    5) Save artifacts & update state.
    """
    headful = bool(state.get("headful", False))
    env = s.portal_env_filter

    p, ctx, page = _launch_portal_context(s, headful=headful)
    try:
        _login_if_needed(page, s)
        _ensure_builds_tab(page)

        # Before shot
        shots = Path("output/screenshots"); shots.mkdir(parents=True, exist_ok=True)
        data = Path("output/data"); data.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        before_png = shots / f"lsup_release_before_{ts}.png"
        page.screenshot(path=str(before_png), full_page=False)

        # Filter and parse rows
        rows = _parse_rows_for_env(page, env)
        lo, hi = _pick_lowest_and_highest(rows, env)

        precheck_ok = False
        precheck_detail: dict[str, Any] = {"lowest": lo, "highest": hi, "reason": ""}

        # Expectation (as requested): lowest is green+bold, other is normal
        if lo is not None and hi is not None and lo != hi:
            # find row dicts
            low_row = next((r for r in rows if r.get("env","").lower()==env.lower() and r.get("build")==lo), None)
            high_row = next((r for r in rows if r.get("env","").lower()==env.lower() and r.get("build")==hi), None)
            if low_row and high_row:
                low_green = bool(low_row.get("greenBold"))
                high_green = bool(high_row.get("greenBold"))
                precheck_ok = (low_green is True) and (high_green is False)
                if not precheck_ok:
                    precheck_detail["reason"] = f"Expected lowest={lo} green, highest={hi} normal, got low_green={low_green}, high_green={high_green}"
        else:
            precheck_detail["reason"] = "Could not determine two distinct builds for environment filter."

        # Proceed to click the LARGEST build and release it
        if hi is None:
            raise RuntimeError("No build found to release for environment filter.")

        _click_build_link(page, hi)
        alert_seen = _click_release_accept_alert(page)

        after_png = shots / f"lsup_release_after_{ts}.png"
        page.screenshot(path=str(after_png), full_page=False)

        # Report
        report = {
            "env_filter": env,
            "precheck_ok": precheck_ok,
            "precheck_detail": precheck_detail,
            "released_build": hi,
            "alert_seen": alert_seen,
            "timestamp": ts,
        }
        rep_path = data / f"lsup_release_report_{ts}.json"
        rep_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

        # Update state
        state["release_precheck_ok"] = precheck_ok
        state["release_clicked_build"] = hi
        state["release_alert_seen"] = alert_seen
        state["release_result_json"] = str(rep_path)
        state["release_ok"] = True
        state["release_before_shot"] = str(before_png)
        state["release_after_shot"] = str(after_png)

        # NEW: audit success
        audit = state.get("audit_file")
        log_event(audit, "lsup_release", "ok", {
            "env": env,
            "released_build": hi,
            "alert_seen": alert_seen,
            "report": str(rep_path),
            "before_shot": str(before_png),
            "after_shot": str(after_png),
        })

        return state

    except Exception as e:
        # Capture failure page for diagnostics
        try:
            logs = Path("output/logs"); logs.mkdir(parents=True, exist_ok=True)
            html = logs / "lsup_release_failure.html"
            html.write_text(page.content(), encoding="utf-8")
            shots = Path("output/screenshots"); shots.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            fail_png = shots / f"lsup_release_failure_{ts}.png"
            page.screenshot(path=str(fail_png), full_page=True)
        except Exception:
            pass

        state["release_ok"] = False
        state["release_error"] = str(e)
        # NEW: audit failure
        audit = state.get("audit_file")
        log_event(audit, "lsup_release", "fail", {
            "error": str(e),
            "failure_html": str(html) if 'html' in locals() else None,
            "failure_screenshot": str(fail_png) if 'fail_png' in locals() else None,
        })

        return state
    finally:
        try: ctx.close()
        except Exception: pass
        try: p.stop()
        except Exception: pass
