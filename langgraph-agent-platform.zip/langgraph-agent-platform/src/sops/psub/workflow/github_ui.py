from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from pathlib import Path
import re
from datetime import datetime, timezone

from playwright.sync_api import sync_playwright, Page, BrowserContext, TimeoutError as PWTimeout

from .config import Settings
from ..utils.files import ensure_dir
from .log_parser import extract_domain_from_text

@dataclass
class RunPick:
    title: str
    href: str  # e.g., /org/repo/actions/runs/1712345678
    run_id: str

class GitHubUI:
    def __init__(self, settings: Settings, headful: bool | None = None, slow: int = 0):
        self.s = settings
        self.headful = settings.headful if headful is None else headful
        self.slow = slow
        self.base = "https://github.com"
        self.prefix = (self.s.workflow_title_prefix or "").strip().lower()

    # ---------- lifecycle ----------
    def _launch(self):
        p = sync_playwright().start()

        user_dir = Path(self.s.pw_user_data_dir).expanduser().resolve()  # ← absolute
        print(f"[PW] headful={self.headful}  user_data_dir={user_dir}")   # debug

        ctx = p.chromium.launch_persistent_context(
            user_data_dir=str(user_dir),
            headless=not self.headful,
            slow_mo=self.slow,
        )
        ctx.set_default_timeout(60_000)
        page = ctx.new_page()
        return p, ctx, page
    
     # ---------- auth helpers ----------
    def _looks_like_login_page(self, page: Page) -> bool:
        # GitHub login forms & SSO often contain these
        if page.url.startswith(f"{self.base}/login"):
            return True
        if page.get_by_role("button", name=re.compile(r"Sign in", re.I)).count() > 0:
            return True
        if page.get_by_role("link", name=re.compile(r"Sign in", re.I)).count() > 0:
            return True
        # 404 with login panel on the right for private repos
        if page.locator("h1").first.inner_text(timeout=0).strip().startswith("404"):
            # many private 404s include sign in links
            if page.get_by_text(re.compile(r"Sign in", re.I)).count() > 0:
                return True
        return False
    
    def _looks_logged_in(self, page: Page) -> bool:
        # presence of the user avatar/menu in the header
        # GitHub uses a <summary> with aria-label like "View profile and more" or a button with avatar
        if page.locator('summary[aria-label*="View profile"]').count() > 0:
            return True
        if page.locator('summary[aria-label*="Open user"]').count() > 0:
            return True
        # navbar avatar img (fallback)
        if page.locator('img.avatar').count() > 0:
            return True
        return False
    
    def _ensure_logged_in(self, page: Page):
        """
        Ensure we are authenticated. If not, keep the window open and wait until
        the user completes login (only needed once per profile).
        """
        # Always start at repo Actions (this triggers a redirect to login if needed)
        target = f"{self.base}/{self.s.github_org}/{self.s.github_repo}/actions"
        page.goto(target, wait_until="domcontentloaded")

        if self._looks_logged_in(page) and not self._looks_like_login_page(page):
            return  # already okay

        # Not logged in: guide the user to log in, then wait until Actions is visible
        print("\n[Auth] You are not logged in to GitHub in this Playwright profile.")
        print("[Auth] Please complete login in the opened browser window (GitHub & any SSO).")
        print("[Auth] After successful login, navigate to your repo Actions page if needed:")
        print(f"[Auth]   {target}")
        print("[Auth] I will auto-detect when you are logged in and on the Actions page.\n")

        # loop up to 10 minutes; break when logged in AND on actions page
        import time
        deadline = time.time() + 600
        while time.time() < deadline:
            try:
                # If we’re on any page, are we logged in?
                if self._looks_logged_in(page):
                    # If not yet at Actions, try to go there now
                    if not page.url.startswith(target):
                        try:
                            page.goto(target, wait_until="domcontentloaded")
                        except Exception:
                            pass
                    # Confirm Actions content is present (runs list anchor)
                    if page.locator('a[href*="/runs/"]').first.count() > 0:
                        print("[Auth] Login detected and Actions page loaded. Continuing...\n")
                        return
                page.wait_for_timeout(1000)  # poll every 1s
            except Exception:
                page.wait_for_timeout(1000)

        raise RuntimeError("Login was not completed within 10 minutes. Please rerun with --headful and try again.")
    


    def _close(self, p, ctx):
        try:
            ctx.close()
        finally:
            p.stop()

    # ---------- navigation ----------
    def _goto_actions_list(self, page: Page):
        self._ensure_logged_in(page)
        # We should now be at Actions with auth; as a guard, navigate again.
        page.goto(f"{self.base}/{self.s.github_org}/{self.s.github_repo}/actions", wait_until="domcontentloaded")

    def _scrape_runs(self, page: Page) -> list[RunPick]:
        """
        Collect visible runs by their anchor tag to /runs/<id>, and the link text as the title.
        """
        links = page.locator('a[href*="/runs/"]').all()
        picks: list[RunPick] = []
        for a in links:
            try:
                href = a.get_attribute("href") or ""
                title = a.inner_text().strip()
                if "/runs/" in href and title:
                    run_id = href.split("/runs/")[-1].split("?")[0].strip("/")
                    picks.append(RunPick(title=title, href=href, run_id=run_id))
            except Exception:
                continue
        # de-dup by run_id, preserving order
        uniq, seen = [], set()
        for r in picks:
            if r.run_id not in seen:
                uniq.append(r); seen.add(r.run_id)
        return uniq

    def _filter_by_prefix(self, runs: list[RunPick]) -> list[RunPick]:
        """
        Keep only titles starting with 'Deploy jysup' (case-insensitive).
        """
        if not self.prefix:
            return runs
        keep: list[RunPick] = []
        for r in runs:
            if r.title.lower().startswith(self.prefix):
                keep.append(r)
        return keep

    def _read_run_datetime(self, page: Page) -> datetime | None:
        """
        On the run page, GitHub usually shows <relative-time datetime="...Z">.
        We'll read that exact ISO timestamp.

        Returns an aware UTC datetime if found, else None.
        """
        # try <relative-time> first
        time_el = page.locator("relative-time").first
        if time_el.count() > 0:
            dt = time_el.get_attribute("datetime")
            if dt:
                try:
                    return datetime.fromisoformat(dt.replace("Z", "+00:00")).astimezone(timezone.utc)
                except Exception:
                    pass
        # fallback: try time-ago (older markup)
        time_el2 = page.locator("time-ago").first
        if time_el2.count() > 0:
            dt = time_el2.get_attribute("datetime")
            if dt:
                try:
                    return datetime.fromisoformat(dt.replace("Z", "+00:00")).astimezone(timezone.utc)
                except Exception:
                    pass
        return None

    def _choose_latest_by_time(self, page: Page, candidates: list[RunPick]) -> Optional[RunPick]:
        """
        Open each candidate run page, read its <relative-time datetime="...">,
        pick the most recent. If no timestamps found, fall back to the first (newest visually).
        """
        if not candidates:
            return None

        best: tuple[Optional[RunPick], Optional[datetime]] = (None, None)

        for r in candidates:
            page.goto(self.base + r.href, wait_until="domcontentloaded")
            dt = self._read_run_datetime(page)
            if dt is None:
                # if we can't read time, we don't update best unless best is None
                if best[0] is None:
                    best = (r, None)
                continue
            if best[1] is None or dt > best[1]:
                best = (r, dt)

        return best[0] if best[0] else candidates[0]

    

    def _open_first_job(self, page: Page):
        """
        Robustly open the first job page from the run summary.
        GitHub sometimes renders the job link as an <a href="/jobs/...">,
        sometimes as a link by accessible name, and sometimes only as a job
        tile inside the workflow graph card.
        """
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(500)  # small settle

        # 0) make sure the Summary tab is visible (defensive)
        try:
            page.get_by_role("link", name=re.compile(r"Summary", re.I)).first.click(timeout=2000)
        except Exception:
            pass

        # 1) Fast path: direct jobs link by URL pattern
        jobs_link = page.locator('a[href*="/jobs/"]').first
        if jobs_link.count() > 0:
            jobs_link.scroll_into_view_if_needed(timeout=3000)
            jobs_link.click(timeout=10_000)
            page.wait_for_load_state("domcontentloaded")
            return

        # 2) By accessible name (common when there is a single job, e.g. "Deploy to dev")
        #    Try a generic "Deploy" first, then any link with role=link inside Jobs section
        try:
            # Try to find the first job name link in the left Jobs list
            left_jobs_section = page.get_by_text(re.compile(r"Jobs", re.I)).first
            # If found, try a link under the same container
            if left_jobs_section:
                candidate = page.get_by_role("link", name=re.compile(r"^(?!.*Re-run).*", re.I)).first
                if candidate and candidate.count() > 0:
                    candidate.scroll_into_view_if_needed(timeout=3000)
                    candidate.click(timeout=10_000)
                    page.wait_for_load_state("domcontentloaded")
                    return
        except Exception:
            pass

        # 3) Click the job tile inside the workflow card (center panel),
        #    e.g. the rounded box labeled "Deploy to dev"
        try:
            # common label is the job name; make a generic clickable node search
            job_tile = page.get_by_role("link", name=re.compile(r"deploy", re.I)).first
            if job_tile.count() == 0:
                # fall back to any element with that text and then click the nearest link/button ancestor
                job_tile = page.get_by_text(re.compile(r"deploy", re.I)).first

            if job_tile and job_tile.count() > 0:
                job_tile.scroll_into_view_if_needed(timeout=3000)
                try:
                    job_tile.click(timeout=10_000)
                except Exception:
                    # sometimes the text node isn't directly clickable; click the nearest link ancestor
                    link_ancestor = job_tile.locator('xpath=ancestor::a[1]')
                    if link_ancestor.count() > 0:
                        link_ancestor.click(timeout=10_000)
                    else:
                        button_ancestor = job_tile.locator('xpath=ancestor::button[1]')
                        if button_ancestor.count() > 0:
                            button_ancestor.click(timeout=10_000)

                page.wait_for_load_state("domcontentloaded")
                # verify we actually navigated to a job page
                if "/jobs/" in page.url:
                    return
        except Exception:
            pass

        # 4) One more generic try: any link that looks like a job inside the main area
        try:
            any_job = page.locator('main a[href*="/jobs/"]').first
            if any_job and any_job.count() > 0:
                any_job.scroll_into_view_if_needed(timeout=3000)
                any_job.click(timeout=10_000)
                page.wait_for_load_state("domcontentloaded")
                return
        except Exception:
            pass

        # 5) If we still failed, dump the DOM to help refine selectors and raise
        from pathlib import Path
        from ..utils.files import ensure_dir
        ensure_dir("output/logs")
        Path("output/logs/last_run_summary.html").write_text(page.content(), encoding="utf-8")
        raise TimeoutError(
            "Could not locate a job link/tile to open. "
            "Saved page HTML to output/logs/last_run_summary.html for inspection."
        )


    def _open_first_job_from_sidebar(self, page: Page):
        """
        On a run's Summary page, click the first job listed under the 'Jobs' sidebar.
        """
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(500)

        # Look for the jobs list under the sidebar (ul with id starting 'group-')
        jobs_list = page.locator("ul[id^='group-']")
        if jobs_list.count() == 0:
            raise TimeoutError("Jobs list not found in sidebar.")

        # Match both /job/ and /jobs/ (GitHub may vary)
        first_job_link = jobs_list.locator("a[href*='/job/'], a[href*='/jobs/']").first
        if first_job_link.count() == 0:
            ensure_dir("output/logs")
            Path("output/logs/last_jobs_sidebar.html").write_text(page.content(), encoding="utf-8")
            raise TimeoutError("No job link found inside jobs sidebar (saved DOM).")

        first_job_link.scroll_into_view_if_needed(timeout=3000)
        first_job_link.click(timeout=10_000)
        page.wait_for_load_state("domcontentloaded")

        if "/job/" not in page.url and "/jobs/" not in page.url:
            raise TimeoutError("Clicking job link did not navigate to job page.")



    def _open_raw_logs_and_get_text(self, page: Page) -> str:
        """
        Click 'View raw logs' and return the text content.
        """
        try:
            page.get_by_role("link", name=re.compile(r"View raw logs", re.I)).click()
        except PWTimeout:
            page.get_by_role("button", name=re.compile(r"View raw logs", re.I)).click()

        page.wait_for_load_state("domcontentloaded")
        pre = page.locator("pre")
        if pre.count() > 0:
            return pre.inner_text()
        return page.content()
    
    def _open_raw_logs_from_job(self, page: Page) -> str:
        """
        On the job page (/job/<id>), open the gear (summary with gear icon),
        click 'View raw logs', capture the NEW tab that opens, and return the
        plaintext logs. Auto-closes the raw log tab after scraping.
        """
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(300)

        # 1) Scope to logs header
        header = page.locator("#logs .uxr_CheckRun-header, #logs").first

        # Gear is a <summary> inside <details>, containing a gear svg
        gear = header.locator(
            "details > summary:has(svg[aria-label='Show options']), "
            "details > summary:has(svg.octicon-gear)"
        ).first
        gear.wait_for(state="attached", timeout=5000)

        # Click the gear (with fallback force-click)
        try:
            page.evaluate("(el) => el.scrollIntoView({block:'center'})", gear.element_handle())
        except Exception:
            pass
        try:
            gear.click(timeout=2000)
        except Exception:
            gear.click(timeout=4000, force=True)

        # 2) Wait for menu to appear
        menu = page.locator("details-menu[role='menu']").first
        menu.wait_for(state="visible", timeout=5000)

        # 3) Find "View raw logs" menu item
        raw_item = menu.get_by_role("menuitem", name=re.compile(r"View raw logs", re.I)).first
        if raw_item.count() == 0:
            raw_item = menu.locator("a:has-text('View raw logs'), button:has-text('View raw logs')").first

        if raw_item.count() == 0:
            ensure_dir("output/logs")
            Path("output/logs/last_job_menu.html").write_text(page.content(), encoding="utf-8")
            raise TimeoutError("Could not find 'View raw logs' in gear menu.")

        # 4) Click "View raw logs" and capture the NEW tab
        ctx = page.context
        with ctx.expect_page() as new_page_info:
            raw_item.click(timeout=4000)
        raw_page = new_page_info.value

        # 5) Work with the raw logs tab
        raw_page.wait_for_load_state("domcontentloaded")
        pre = raw_page.locator("pre")
        try:
            raw_text = pre.inner_text(timeout=30_000)
        except Exception:
            raw_text = raw_page.evaluate(
                "() => document.body ? document.body.innerText : document.documentElement.innerText"
            )

        # 6) Close the raw log tab (keep browser clean)
        try:
            raw_page.close()
        except Exception:
            pass

        return raw_text

    # ---------- public entry ----------
    def get_domain_from_latest_prefixed_run(self) -> str:
        """
        1) Go to Actions list
        2) Filter runs whose title starts with 'Deploy jysup'
        3) Among those, open each to read timestamp → choose the latest
        4) Open first job -> View raw logs -> parse domain
        """
        p, ctx, page = self._launch()
        try:
            self._goto_actions_list(page)
            all_runs = self._scrape_runs(page)
            candidates = self._filter_by_prefix(all_runs)
            if not candidates:
                raise RuntimeError(f"No workflow runs found starting with '{self.s.workflow_title_prefix}'.")

            chosen = self._choose_latest_by_time(page, candidates)
            if not chosen:
                raise RuntimeError("Could not determine the latest matching run.")

            # Ensure we're on the chosen run page
            page.goto(self.base + chosen.href, wait_until="domcontentloaded")

            # Open first job & raw logs
            #self._open_first_job(page)

            # click first job from sidebar
            self._open_first_job_from_sidebar(page)

            #raw = self._open_raw_logs_and_get_text(page)

            # open raw logs from job page
            raw = self._open_raw_logs_from_job(page)

            # Optional: save raw logs
            ensure_dir("output/logs")
            Path(f"output/logs/run_{chosen.run_id}_raw.txt").write_text(raw, encoding="utf-8")

            # Parse domain
            domain = extract_domain_from_text(raw)
            if not domain:
                raise RuntimeError("Could not find 'domain name created:' in raw logs.")
            return domain
        finally:
            self._close(p, ctx)
