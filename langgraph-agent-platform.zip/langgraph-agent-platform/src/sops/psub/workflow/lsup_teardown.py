from __future__ import annotations
from typing import Any, Optional
from pathlib import Path
from datetime import datetime
import json
import re
from ..utils.audit import log_event  # <-- NEW

from playwright.sync_api import sync_playwright, BrowserContext, Page, expect

from .config import Settings


def _launch_ctx(s: Settings, headful: bool) -> tuple[Any, BrowserContext, Page]:
    """
    Launch a Playwright context consistent with your project:
      - headful uses persistent profile (keeps login)
      - headless uses a fresh context
    """
    p = sync_playwright().start()
    if headful:
        ctx = p.chromium.launch_persistent_context(
            user_data_dir=str(Path(s.pw_user_data_dir).expanduser()),
            headless=False,
            slow_mo=4000,
        )
        ctx.set_default_timeout(60_000)
        page = ctx.new_page()
        return p, ctx, page
    else:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context()
        ctx.set_default_timeout(60_000)
        page = ctx.new_page()
        return p, ctx, page


def _goto_builds_tab(page: Page) -> None:
    """
    Click the Builds tab. Try role-based first, then text fallback.
    """
    # Primary: a tab or link named "Builds"
    try:
        page.get_by_role("tab", name=re.compile(r"^Builds$", re.I)).click(timeout=3000)
        return
    except Exception:
        pass
    try:
        page.get_by_role("link", name=re.compile(r"^Builds$", re.I)).click(timeout=3000)
        return
    except Exception:
        pass
    # Fallback: literal text
    page.get_by_text(re.compile(r"^Builds$", re.I)).click()


def _filter_environment(page: Page, env_value: str) -> None:
    """
    Type into the Environment filter input to filter rows.
    """
    # Primary: match your exact placeholder
    env_input = page.get_by_placeholder(re.compile(r"Enter\s+Environment\.\.\.", re.I))
    env_input.wait_for(state="visible", timeout=5000)
    env_input.fill("")
    env_input.type(env_value, delay=40)

    # allow the list to re-render
    page.wait_for_timeout(250)

    #optional early-out if no results
    if page.get_by_text(re.compile(r"^No results for the current filters\.$", re.I)).is_visible():
        raise RuntimeError("No rows for the current filters; cannot select a build.")



def _pick_lowest_build_and_click(page: Page) -> int:
    """
    For the div-grid list: find all build links /app/builds/<num>, pick the LOWEST <num>,
    click it, and wait until Build Details is shown (SPA route change).
    """
    # Ensure some filtered rows or a 'No results' message is visible
    # Then scan for link anchors
    link_sel = 'a[href^="/app/builds/"]'
    page.wait_for_selector(link_sel, timeout=5000)

    links = page.locator(link_sel)
    count = links.count()
    if count == 0:
        raise TimeoutError("No build links found after filtering (selector a[href^=\"/app/builds/\"]).")

    import re
    re_num = re.compile(r"^/app/builds/(\d+)$")
    candidates: list[tuple[int, Any]] = []

    for i in range(count):
        lk = links.nth(i)
        href = lk.get_attribute("href") or ""
        m = re_num.match(href)
        if not m:
            continue
        # Prefer the link text if it’s numeric, else use the href number
        txt = (lk.inner_text(timeout=1000) or "").strip()
        try:
            num = int(txt) if txt.isdigit() else int(m.group(1))
        except ValueError:
            continue
        candidates.append((num, lk))

    if not candidates:
        raise TimeoutError("Found links to /app/builds but could not parse any numeric build ids.")

    # Pick the LOWEST build number
    candidates.sort(key=lambda t: t[0])
    chosen_num, chosen_link = candidates[0]

    # SPA: clicking changes the URL and shows Build Details heading
    # Wait for either the URL to contain the chosen id or the H1 title to appear
    chosen_href = f"/app/builds/{chosen_num}"
    chosen_link.click()

    # Wait for URL change OR the Build Details H1 text
    page.wait_for_function(
        """(expected) => window.location.pathname.includes(expected)""",
        arg=chosen_href,
        timeout=5000,
    )
    # Also wait for the title just to be resilient
    try:
        page.get_by_role("heading", name=re.compile(r"^Build Information$", re.I)).wait_for(timeout=3000)
    except Exception:
        pass

    return chosen_num



def _click_teardown_with_confirm(page: Page) -> None:
    """
    On the Build Details page, click the 'Teardown' button and accept the alert/confirm.
    Your demo page uses `alert("teardown done")`, so a 'dialog' handler is needed.
    """
    # Accept the next dialog that appears (native alert/confirm)
    def _on_dialog(dlg):
        try:
            dlg.accept()
        except Exception:
            pass

    page.once("dialog", _on_dialog)

    # Click the Teardown button by role or fallback text
    try:
        page.get_by_role("button", name=re.compile(r"^Teardown$", re.I)).click(timeout=5000)
        return
    except Exception:
        pass

    page.get_by_text(re.compile(r"^Teardown$", re.I)).click()


def node_lsup_teardown(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Open LSUP portal, filter by environment, click the LOWEST build number,
    go to Build Details, click 'Teardown', accept confirm, and save artifacts.

    State writes:
      - teardown_env_filter: str
      - teardown_build_selected: int
      - teardown_ok: bool
      - teardown_result_file: str
      - teardown_screenshot_before: str
      - teardown_screenshot_after: str
      - teardown_result_json: str
    """
    headful = bool(state.get("headful", False))
    audit = state.get("audit_file")  # <-- NEW

    p, ctx, page = _launch_ctx(s, headful=headful)
    try:
        # Config from existing env keys you mentioned
        base_url = getattr(s, "portal_url", None) or getattr(s, "portal1_url", None) or "http://localhost:5173/"
        env_filter = getattr(s, "portal_env_filter", None) or getattr(s, "portal1_env_filter", None) or "lsup"

        # Visit portal
        page.goto(base_url, wait_until="domcontentloaded")


    


        # Navigate to Builds tab
        _goto_builds_tab(page)

        # Filter Environment
        _filter_environment(page, env_filter)

        # Pause briefly for filter to take effect
        page.wait_for_timeout(500)

        # Screenshot before selecting
        shots = Path("output/screenshots"); shots.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        before_png = shots / f"lsup_teardown_before_{ts}.png"
        page.screenshot(path=str(before_png), full_page=False)

        # Pick LOWEST build link, click to details; return the chosen build number
        chosen_build = _pick_lowest_build_and_click(page)

        # Now on Build Details, click Teardown (accept alert)
        _click_teardown_with_confirm(page)

        # Evidence after teardown click
        after_png = shots / f"lsup_teardown_after_{ts}.png"
        page.screenshot(path=str(after_png), full_page=False)

        # Write result artifacts
        out_dir = Path("output/data"); out_dir.mkdir(parents=True, exist_ok=True)
        txt_path = out_dir / f"lsup_teardown_{ts}.txt"
        txt_path.write_text(
            f"teardown initiated for build {chosen_build} with env '{env_filter}' at {ts}\n",
            encoding="utf-8",
        )
        json_path = out_dir / f"lsup_teardown_{ts}.json"
        json_path.write_text(
            json.dumps(
                {
                    "env_filter": env_filter,
                    "build_selected": chosen_build,
                    "action": "teardown",
                    "ok": True,
                    "timestamp": ts,
                },
                indent=2,
            ),
            encoding="utf-8",
        )

        # Update state
        state["teardown_env_filter"] = env_filter
        state["teardown_build_selected"] = chosen_build
        state["teardown_ok"] = True
        state["teardown_result_file"] = str(txt_path)
        state["teardown_screenshot_before"] = str(before_png)
        state["teardown_screenshot_after"] = str(after_png)
        state["teardown_result_json"] = str(json_path)

        # AUDIT OK  <-- NEW
        log_event(audit, "lsup_teardown", "ok", {
            "env_filter": env_filter,
            "build": chosen_build,
            "txt": str(txt_path),
            "json": str(json_path)
        })

        return state

    except Exception as e:
        # Capture failure artifacts for debugging
        logs = Path("output/logs"); logs.mkdir(parents=True, exist_ok=True)
        try:
            html_dump = logs / "lsup_teardown_failure.html"
            html_dump.write_text(page.content(), encoding="utf-8")
        except Exception:
            pass
        try:
            shots = Path("output/screenshots"); shots.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            fail_png = shots / f"lsup_teardown_failure_{ts}.png"
            page.screenshot(path=str(fail_png), full_page=True)
        except Exception:
            pass

        # Reflect failure in state (non-throwing path so the pipeline continues if you prefer)
        state["teardown_ok"] = False
        state["teardown_error"] = str(e)
        # AUDIT FAIL  <-- NEW
        log_event(audit, "lsup_teardown", "fail", {"error": str(e)})
        return state

    finally:
        try:
            ctx.close()
        except Exception:
            pass
        try:
            p.stop()
        except Exception:
            pass
