from __future__ import annotations
from ..utils.audit import log_event  # NEW

from typing import Any
from pathlib import Path
from datetime import datetime
import json
import re
import time

from .config import Settings
from .check_lsup_portal import (
    _launch_portal_context,
    _login_if_needed,
    _ensure_builds_tab,
    _parse_rows_for_env,
)

def _max_build_green(rows: list[dict[str, Any]], env: str) -> tuple[bool, int | None, dict | None]:
    same_env = [r for r in rows if (r.get("env") or "").strip().lower() == env.lower()]
    nums = [int(r["build"]) for r in same_env if isinstance(r.get("build"), int)]
    if not nums:
        return False, None, None
    mx = max(nums)
    row = next((r for r in same_env if r.get("build") == mx), None)
    return (bool(row and row.get("greenBold") is True), mx, row)

def node_wait_release_green(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Wait for the largest build for env to become green+bold after Release.
    Initial wait, then retry N times with a fixed interval.
    On success: set release_propagated=True.
    On failure: write a failure summary and set release_propagated=False.
    """
    headful = bool(state.get("headful", False))
    env = s.portal_env_filter

    # Configurable knobs with sensible defaults  retry
    initial = int(getattr(s, "portal_release_wait_initial_sec", 3)) #120
    retries = int(getattr(s, "portal_release_wait_retries", 2))
    interval = int(getattr(s, "portal_release_wait_interval_sec", 30))

    p, ctx, page = _launch_portal_context(s, headful=headful)
    summary = {
        "timestamp": datetime.now().isoformat(),
        "env_filter": env,
        "initial_wait_sec": initial,
        "retries": retries,
        "interval_sec": interval,
        "attempts": [],
        "ok": False,
    }
    try:
        # Initial wait
        page.wait_for_timeout(initial * 1000)

        shots = Path("output/screenshots"); shots.mkdir(parents=True, exist_ok=True)
        data = Path("output/data"); data.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")

        def attempt(i: int) -> bool:
            _login_if_needed(page, s)
            _ensure_builds_tab(page)
            rows = _parse_rows_for_env(page, env)

            ok, mx, row = _max_build_green(rows, env)
            # snapshot
            shot = shots / f"lsup_release_wait_attempt_{i}_{ts}.png"
            page.screenshot(path=str(shot), full_page=False)

            summary["attempts"].append({
                "index": i,
                "max_build": mx,
                "row": row,
                "ok_now": ok,
                "screenshot": str(shot),
            })
            return ok

        # First attempt after initial wait
        if attempt(0):
            summary["ok"] = True
        else:
            # More tries
            for i in range(1, retries + 1):
                page.wait_for_timeout(interval * 1000)
                if attempt(i):
                    summary["ok"] = True
                    break

        # Save summary
        rep = data / f"lsup_release_wait_summary_{ts}.json"
        rep.write_text(json.dumps(summary, indent=2), encoding="utf-8")

        state["release_propagated"] = bool(summary["ok"])
        state["release_wait_summary"] = str(rep)

        # NEW: audit ok/fail with summary
        audit = state.get("audit_file")
        log_event(audit, "wait_release_green", "ok" if summary["ok"] else "fail", {
            "summary": str(rep),
        })


        return state

    finally:
        try: ctx.close()
        except Exception: pass
        try: p.stop()
        except Exception: pass
