from __future__ import annotations
from typing import Any
from pathlib import Path
from datetime import datetime
import json

from .config import Settings
from .oracle_client import OracleClient
from ..utils.files import write_csv  # reuse your CSV helper

from ..utils.audit import log_event  # <-- NEW

# Default updates you provided (id -> url)
DEFAULT_UPDATES: list[tuple[int, str]] = [
    (1, "http://api-aircompant.cmo/abc/2"),
    (2, "http://api-aircompant.cmo/abc/dfd/4"),
    (3, "http://api-aircompant.cmo/abc/r"),
    (4, "http://api-aircompant.cmo/abc/chekc"),
    (5, "http://api-aircompant.cmo/abc/ouer"),
]

def node_update_dest_lookup(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Use ORACLE_HOST_GENERAL to run a batch of UPDATEs on int_dest_lookup, commit,
    then SELECT a snapshot and write artifacts.

    State writes:
      - dest_update_host: str
      - dest_updates_ok: bool
      - dest_updates_file: str (true/false)
      - dest_after_csv: str (snapshot CSV)
      - dest_update_summary: str (JSON summary)
      - dest_update_error: str (on failure)
    """
    host = s.oracle_host_general  # per your requirement: only this host
    ora = OracleClient(s)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("output/data"); out_dir.mkdir(parents=True, exist_ok=True)
    audit = state.get("audit_file")

    # Attempt updates inside try/except to capture artifacts on failure
    try:
        # 1) Apply updates
        ora.update_int_dest_lookup(host=host, updates=DEFAULT_UPDATES)

        # 2) Snapshot after update
        rows = ora.snapshot_int_dest_lookup(host=host)
        csv_path = out_dir / f"dest_lookup_after_update_{ts}.csv"
        write_csv(rows, csv_path)

        # 3) Verify IDs 1..5 match expected URLs
        expect = {i: u for (i, u) in DEFAULT_UPDATES}
        got = {int(r["ID"]): (r.get("URL") or "") for r in rows if "ID" in r}
        mismatches: list[dict] = []
        for i, url in expect.items():
            if got.get(i, "") != url:
                mismatches.append({"ID": i, "expected": url, "actual": got.get(i)})

        ok = len(mismatches) == 0

        # 4) Write status & summary
        status_file = out_dir / f"dest_lookup_updates_ok_{ts}.txt"
        status_file.write_text("true" if ok else "false", encoding="utf-8")

        summary = {
            "timestamp": ts,
            "host": host,
            "attempted": [{"id": i, "url": u} for (i, u) in DEFAULT_UPDATES],
            "verified": ok,
            "mismatches": mismatches,
            "snapshot_csv": str(csv_path),
        }
        summary_path = out_dir / f"dest_lookup_update_summary_{ts}.json"
        summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

        # 5) Update state
        state["dest_update_host"] = host
        state["dest_updates_ok"] = ok
        state["dest_updates_file"] = str(status_file)
        state["dest_after_csv"] = str(csv_path)
        state["dest_update_summary"] = str(summary_path)

        # AUDIT  <-- NEW
        log_event(audit, "update_dest_lookup", "ok" if ok else "fail", {
            "summary": str(summary_path),
            "mismatches": mismatches
        })

        return state

    except Exception as e:
        # Persist error to state & artifact for debugging
        state["dest_update_host"] = host
        state["dest_updates_ok"] = False
        state["dest_update_error"] = str(e)
        err_path = out_dir / f"dest_lookup_update_error_{ts}.txt"
        err_path.write_text(repr(e), encoding="utf-8")
        # AUDIT FAIL  <-- NEW
        log_event(audit, "update_dest_lookup", "fail", {"error": str(e), "error_file": str(err_path)})
        
        return state
