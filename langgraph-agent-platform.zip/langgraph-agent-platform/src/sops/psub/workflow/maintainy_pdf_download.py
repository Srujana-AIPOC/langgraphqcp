# src/workflow/maintainy_pdf_download.py
from __future__ import annotations
from typing import Any
from pathlib import Path
from datetime import datetime
import hashlib
import json
import re

from playwright.sync_api import sync_playwright, BrowserContext, Page, expect
from ..utils.audit import log_event  # <-- NEW

from .config import Settings

def _safe(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s).strip("_") or "item"

def _launch_ctx(s: Settings, headful: bool) -> tuple[Any, BrowserContext, Page]:
    p = sync_playwright().start()
    if headful:
        ctx = p.chromium.launch_persistent_context(
            user_data_dir=str(Path(s.pw_user_data_dir).expanduser()),
            headless=False,slow_mo=4000,
        )
        ctx.set_default_timeout(60_000)
        page = ctx.new_page()
        return p, ctx, page
    else:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context()
        ctx.set_default_timeout(60_000)
        page = ctx.new_page()
        return p, ctx, page

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def node_maintainy_pdf_download(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Open the 5174 portal, open the header menu, click configurable parent + child,
    and capture the PDF download. Save file + meta to output dirs and state.
    Writes audit event 'maintainy_pdf_download' ok/fail.
    """
    audit = state.get("audit_file")
    headful = bool(state.get("headful", False))
    p, ctx, page = _launch_ctx(s, headful=headful)
    try:
        try:
            # 1) Visit portal
            page.goto(s.portal2_url, wait_until="domcontentloaded")

            # 2) Open menu by header toggle
            try:
                page.get_by_role("button", name="Open menu").click(timeout=3000)
            except Exception:
                try:
                    page.get_by_role("button", name="Close menu").click(timeout=1000)
                    page.get_by_role("button", name="Open menu").click(timeout=3000)
                except Exception:
                    pass

            # 3) Root menu
            menu_root = page.get_by_role("menu", name="Main menu")
            expect(menu_root).to_be_visible(timeout=5000)

            # 4) Click parent
            parent_label = s.portal2_parent_label
            parent_btn = menu_root.get_by_role("menuitem", name=parent_label, exact=True)
            expect(parent_btn).to_be_visible(timeout=5000)
            parent_btn.click()

            # 5) In last column click child with expect_download
            columns = menu_root.locator("ul")
            col_count = columns.count()
            if col_count == 0:
                raise RuntimeError("No menu columns rendered after clicking parent.")
            last_col = columns.nth(col_count - 1)

            child_label = s.portal2_child_label
            child_btn = last_col.get_by_role("menuitem", name=child_label, exact=True)
            expect(child_btn).to_be_visible(timeout=5000)

            shots_dir = Path("output/screenshots"); shots_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            shot_path = shots_dir / f"maintainy_menu_{ts}.png"
            page.screenshot(path=str(shot_path), full_page=False)

            with page.expect_download() as dl_info:
                child_btn.click()
            download = dl_info.value

            # 6) Save PDF
            pdf_dir = Path(s.portal2_download_dir)
            pdf_dir.mkdir(parents=True, exist_ok=True)
            base = f"maintainy_{_safe(parent_label)}_{_safe(child_label)}_{ts}"
            suggested = download.suggested_filename or "file.pdf"
            ext = ".pdf" if not suggested.lower().endswith(".pdf") else ""
            save_path = pdf_dir / f"{base}{ext or ''}"
            download.save_as(str(save_path))

            # Meta JSON
            size = save_path.stat().st_size
            digest = _sha256(save_path)
            meta = {
                "portal2_url": s.portal2_url,
                "parent_label": parent_label,
                "child_label": child_label,
                "suggested_filename": suggested,
                "saved_filename": str(save_path),
                "size_bytes": size,
                "sha256": digest,
                "screenshot": str(shot_path),
                "timestamp": ts,
            }
            meta_dir = Path("output/data"); meta_dir.mkdir(parents=True, exist_ok=True)
            meta_path = meta_dir / f"maintainy_pdf_meta_{ts}.json"
            meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

            # Update state
            state["maintainy_pdf_path"] = str(save_path)
            state["maintainy_pdf_meta"] = meta
            state["maintainy_pdf_screenshot"] = str(shot_path)

            # AUDIT OK
            log_event(audit, "maintainy_pdf_download", "ok", {
                "pdf_path": str(save_path),
                "meta_json": str(meta_path)
            })
            return state

        except Exception as e:
            # AUDIT FAIL
            log_event(audit, "maintainy_pdf_download", "fail", {"error": str(e)})
            # leave state without maintainy_pdf_path so the graph gate will END
            return state

    finally:
        try: ctx.close()
        except Exception: pass
        try: p.stop()
        except Exception: pass
