#before audit 


from __future__ import annotations
from typing import Any, Dict, List, Tuple
from pathlib import Path
from datetime import datetime
import json
import math
import re
import hashlib

from .config import Settings
from ..utils.pdf_utils import (
    open_pdf, page_size_pts, rel_to_bbox, words_in_bbox, lines_from_words,
    extract_tables_in_region, count_lines_in_region, render_pages_to_png,
)

A4_W, A4_H = 595.276, 841.889  # pts

def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def _is_pdf_magic(path: Path) -> bool:
    with open(path, "rb") as f:
        return f.read(5) == b"%PDF-"

def _pct_diff(a: float, b: float) -> float:
    if b == 0:
        return 0.0 if a == 0 else 100.0
    return abs(a - b) / b * 100.0

def _safe_get(d: dict, path: str, default=None):
    cur = d
    for k in path.split("."):
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur

def node_validate_pdf_report(state: Dict[str, Any], s: Settings) -> Dict[str, Any]:
    """
    Validate the candidate PDF (from maintainy_pdf_download) against a policy JSON.

    Inputs (state): maintainy_pdf_path
    Settings: pdf_policy_path (JSON policy), pdf_render_pages, pdf_extract_tables

    Outputs (state):
      - pdf_validation_ok: bool
      - pdf_validation_report: str  (JSON path)
      - pdf_page_shots: list[str]   (optional)
    """
    cand_path = state.get("maintainy_pdf_path")
    if not cand_path:
        raise RuntimeError("Missing 'maintainy_pdf_path' in state (PDF to validate).")
    cand = Path(cand_path)
    if not cand.exists():
        raise RuntimeError(f"Candidate PDF not found: {cand}")

    policy_path = s.pdf_policy_path
    if not policy_path:
        raise RuntimeError("PDF_POLICY_PATH not set. Provide a policy JSON path in .env.")
    policy = json.loads(Path(policy_path).read_text(encoding="utf-8"))

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_data = Path("output/data"); out_data.mkdir(parents=True, exist_ok=True)
    out_reports = Path("output/reports"); out_reports.mkdir(parents=True, exist_ok=True)
    out_shots = Path("output/screenshots"); out_shots.mkdir(parents=True, exist_ok=True)

    # Candidate file meta
    meta = {
        "path": str(cand),
        "size_bytes": cand.stat().st_size,
        "sha256": _sha256(cand),
        "is_pdf_magic": _is_pdf_magic(cand),
    }

    # Optional evidence images
    page_screens = []
    if s.pdf_render_pages:
        page_screens = render_pages_to_png(cand, out_shots, dpi=150)
    
    # Open PDF
    pdf = open_pdf(cand)
    pages = list(pdf.pages)
    meta["pages"] = len(pages)

    # ---- Checks according to policy ----
    weights: Dict[str, int] = _safe_get(policy, "scoring.weights", {}) or {}
    pass_threshold: int = int(_safe_get(policy, "scoring.pass_threshold", 100) or 100)

    # We compute a normalized score: only sum weights of evaluated checks.
    score_total = 0
    score_earned = 0
    details: Dict[str, Any] = {}
    failures: List[str] = []
    not_eval: List[str] = []

    # 1) Page checks
    if _safe_get(policy, "page.enabled", False):
        want_size = _safe_get(policy, "page.size", "A4")
        margin_tol = float(_safe_get(policy, "page.margin_tolerance_pct", 2.0))
        # Implement only A4 for now
        if want_size.upper() == "A4" and pages:
            pw, ph = page_size_pts(pages[0])
            w_ok = _pct_diff(pw, A4_W) <= margin_tol
            h_ok = _pct_diff(ph, A4_H) <= margin_tol
            page_ok = bool(w_ok and h_ok)
            details["page_ok"] = {"page0_w": pw, "page0_h": ph, "tol_pct": margin_tol, "ok": page_ok}
            if "page_ok" in weights:
                score_total += int(weights["page_ok"])
                if page_ok:
                    score_earned += int(weights["page_ok"])
                elif _safe_get(policy, "page.required", False):
                    failures.append("Page size not within tolerance for A4.")
        else:
            not_eval.append("page_ok")
    else:
        not_eval.append("page_ok")

    # 2) Header band and Printed By
    header_enabled = _safe_get(policy, "header.enabled", False)
    if header_enabled and pages:
        band_rel = _safe_get(policy, "header.band_region_rel", [0,0,1,0.15])
        band_bbox = rel_to_bbox(pages[0], tuple(band_rel))
        words = words_in_bbox(pages[0], band_bbox)
        lines = lines_from_words(words)
        printed_cfg = _safe_get(policy, "header.printed_by", {}) or {}
        pb_enabled = printed_cfg.get("enabled", False)
        header_present = len(lines) > 0
        details["header_present"] = {"ok": header_present}
        if "header_present" in weights:
            score_total += int(weights["header_present"])
            if header_present:
                score_earned += int(weights["header_present"])
            elif _safe_get(policy, "header.required", False):
                failures.append("Header band has no text.")

        if pb_enabled:
            text_regex = printed_cfg.get("text_regex", r"Printed\s*By\s*:")
            re_pb = re.compile(text_regex, re.IGNORECASE)
            pb_line = next((ln for ln in lines if re_pb.search(ln["text"])), None)
            pb_present = pb_line is not None
            # "value required": ensure something after colon on that line
            value_required = bool(printed_cfg.get("value_required", True))
            has_value = False
            if pb_present and value_required:
                m = re.search(r":\s*(\S.+)$", pb_line["text"])
                has_value = m is not None
            # alignment check
            align = printed_cfg.get("check_alignment", "").lower()
            aligned_right = False
            if pb_present and align == "right":
                x0, y0, x1, y1 = band_bbox
                width = x1 - x0
                aligned_right = (pb_line["x1"] >= (x0 + 0.8 * width))  # right-most 20%

            pb_ok = pb_present and (not value_required or has_value) and (align != "right" or aligned_right)
            details["printed_by_present_and_right"] = {
                "present": pb_present, "has_value": has_value,
                "aligned_right": aligned_right, "ok": pb_ok
            }
            if "printed_by_present_and_right" in weights:
                score_total += int(weights["printed_by_present_and_right"])
                if pb_ok:
                    score_earned += int(weights["printed_by_present_and_right"])
                elif printed_cfg.get("required", True):
                    failures.append("Printed By not present/value/alignment failed.")
        else:
            not_eval.append("printed_by_present_and_right")
    else:
        not_eval.append("header_present")
        not_eval.append("printed_by_present_and_right")

    # 3) Table checks (geometry & rows)
    table_enabled = _safe_get(policy, "table.enabled", False)
    table_ok = False
    rows_count = 0
    if table_enabled and pages:
        region_rel = tuple(_safe_get(policy, "table.region_hint_rel", [0.0, 0.15, 1.0, 0.85]))
        bbox = rel_to_bbox(pages[0], region_rel)
        rows = extract_tables_in_region(pages[0], bbox) if s.pdf_extract_tables else []
        rows_count = sum(1 for r in rows if any(c.strip() for c in r))
        exp_cols = int(_safe_get(policy, "table.expected_columns", 0) or 0)
        min_rows = int(_safe_get(policy, "table.expected_min_rows", 0) or 0)
        max_rows = int(_safe_get(policy, "table.expected_max_rows", 10**9) or 10**9)
        header_idx = int(_safe_get(policy, "table.header_row_index", 0) or 0)
        header_span_all = bool(_safe_get(policy, "table.header_span_all_columns", False))

        has_table = rows_count > 0
        cols_ok = True
        if has_table and exp_cols:
            # naive: use length of header row
            hdr = rows[header_idx] if (0 <= header_idx < len(rows)) else None
            if hdr:
                # drop entirely empty cells at tail
                while hdr and hdr[-1] == "":
                    hdr = hdr[:-1]
                cols_ok = (len(hdr) == exp_cols)

        rows_ok = (rows_count >= min_rows and rows_count <= max_rows)

        # Gridlines: approximate by counting lines in region
        require_grid = bool(_safe_get(policy, "table.require_gridlines", False))
        grid_ok = True
        if require_grid:
            grid_ok = (count_lines_in_region(pages[0], bbox) >= 4)

        table_ok = has_table and cols_ok and rows_ok and grid_ok
        details["table_geometry_ok"] = {
            "has_table": has_table, "rows_count": rows_count, "exp_cols": exp_cols,
            "cols_ok": cols_ok, "rows_ok": rows_ok, "grid_ok": grid_ok, "ok": table_ok
        }
        if "table_geometry_ok" in weights:
            score_total += int(weights["table_geometry_ok"])
            if table_ok:
                score_earned += int(weights["table_geometry_ok"])
            elif _safe_get(policy, "table.required", True):
                failures.append("Table geometry/rows/gridlines failed.")
    else:
        not_eval.append("table_geometry_ok")

    # 4) Labels (basic presence; cell coordinates check deferred)
    labels_enabled = _safe_get(policy, "labels.enabled", False)
    labels_ok = True
    if labels_enabled and pages:
        # Quick text extraction for page 1
        words = pages[0].extract_words(use_text_flow=True)
        page_text = " ".join(w["text"] for w in words)
        req_items = _safe_get(policy, "labels.required_items", []) or []
        missing = []
        for it in req_items:
            txt = it.get("text", "")
            ci = bool(it.get("case_insensitive", False))
            if not txt:
                continue
            if ci:
                found = (txt.lower() in page_text.lower())
            else:
                found = (txt in page_text)
            if not found:
                missing.append(txt)
        labels_ok = (len(missing) == 0)
        details["required_labels_found_in_cells"] = {
            "ok": labels_ok, "missing_texts": missing
        }
        if "required_labels_found_in_cells" in weights:
            score_total += int(weights["required_labels_found_in_cells"])
            if labels_ok:
                score_earned += int(weights["required_labels_found_in_cells"])
            elif _safe_get(policy, "labels.required", True):
                failures.append(f"Required labels missing: {missing}")
    else:
        not_eval.append("required_labels_found_in_cells")

    # 5) No text over gridlines (deferred; geometry-intensive)
    if _safe_get(policy, "no_text_on_lines.enabled", False):
        # Not implemented in v1; mark not evaluated to avoid unfair scoring
        not_eval.append("no_text_over_gridlines")
    else:
        not_eval.append("no_text_over_gridlines")

    # ---- Score normalization ----
    # Only include evaluated weighted checks in denominator
    evaluated_weights_sum = sum(
        w for k, w in weights.items() if k not in not_eval
    )
    earned = score_earned
    total = evaluated_weights_sum if evaluated_weights_sum else 100
    pct = int(round(earned * 100.0 / total))
    ok = (pct >= pass_threshold) and (len(failures) == 0)

    # Save report JSON
    report = {
        "timestamp": datetime.now().isoformat(),
        "candidate": meta,
        "policy_path": policy_path,
        "details": details,
        "not_evaluated": not_eval,
        "scoring": {
            "weights_used_sum": total,
            "score_earned": earned,
            "percent": pct,
            "threshold": pass_threshold
        },
        "result": {
            "ok": ok,
            "failures": failures
        }
    }
    rep_path = out_data / f"pdf_validation_report_{ts}.json"
    rep_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

    # Update state
    state["pdf_validation_ok"] = ok
    state["pdf_validation_report"] = str(rep_path)
    if page_screens:
        state["pdf_page_shots"] = page_screens
    return state
