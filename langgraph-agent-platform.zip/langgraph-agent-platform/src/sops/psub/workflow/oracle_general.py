from __future__ import annotations
from ..utils.audit import log_event  # NEW

from typing import Any
from pathlib import Path
from datetime import datetime

from .config import Settings
from .oracle_client import OracleClient

def node_oracle_general(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    if not s.oracle_host_general:
        raise RuntimeError("ORACLE_HOST_GENERAL is not set in environment.")

    ora = OracleClient(s)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_csv = Path("output/data") / f"query_general_{ts}.csv"

    try:
        res = ora.run_query_to_csv(host=s.oracle_host_general, sql=s.oracle_sql, out_path=out_csv)
        state["oracle2_csv_path"] = str(res.out_csv)
        if getattr(res, "rows", None) is not None:
            state["oracle2_rows"] = res.rows
        state["oracle2_ok"] = True  # NEW

        # NEW: audit success
        audit = state.get("audit_file")
        log_event(audit, "oracle_general", "ok", {
            "csv": str(out_csv),
            "rows": len(res.rows) if getattr(res, "rows", None) else 0,
        })
        return state

    except Exception as e:
        state["oracle2_ok"] = False  # NEW
        # NEW: audit failure
        audit = state.get("audit_file")
        log_event(audit, "oracle_general", "fail", {"error": str(e)})
        return state

