from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import oracledb

from .config import Settings
from ..utils.files import write_csv

# Optional DBOps injection (set by SOP wrapper)
_DBOPS_CTX = None  # tuple[DBOpsService, str /*sop_id*/, str /*target_db*/] | None


def set_dbops_context(dbops, sop_id: str, target_db: str):
    global _DBOPS_CTX
    _DBOPS_CTX = (dbops, sop_id, target_db)


def clear_dbops_context():
    global _DBOPS_CTX
    _DBOPS_CTX = None

@dataclass
class OracleResult:
    rows: list[dict]
    out_csv: Path

class OracleClient:
    def __init__(self, settings: Settings):
        self.s = settings

    def _dsn(self, host: str) -> str:
        # host:port/service_name
        return f"{host}:{self.s.oracle_port}/{self.s.oracle_service_name}"

    def run_query_to_csv(self, host: str, sql: str, out_path: str | Path) -> OracleResult:
        rows: list[dict]
        sql_clean = (sql or "").strip()
        if sql_clean.endswith(";"):
            sql_clean = sql_clean[:-1].rstrip()
        if _DBOPS_CTX:
            dbops, sop_id, target_db = _DBOPS_CTX
            import asyncio

            def _run():
                loop = asyncio.new_event_loop()
                try:
                    asyncio.set_event_loop(loop)
                    return loop.run_until_complete(dbops.select_sql(target_db=target_db, sop_id=sop_id, sql=sql_clean, params={}, host=host))
                finally:
                    loop.close()

            result = _run()
            rows = result.get("rows", [])
        else:
            rows = []
            with oracledb.connect(user=self.s.oracle_user,
                                  password=self.s.oracle_password,
                                  dsn=self._dsn(host)) as conn:
                with conn.cursor() as cur:
                    cur.execute(sql_clean)
                    cols = [d[0] for d in cur.description]
                    for r in cur:
                        rows.append({cols[i]: r[i] for i in range(len(cols))})
        out_csv = write_csv(rows, out_path)
        return OracleResult(rows=rows, out_csv=out_csv)
    
    def fetch_all(self, host: str, sql: str) -> list[dict]:
        """
        Run a SELECT and return rows as a list of dicts (column -> value).
        SQL must NOT end with ';'.
        """
        # sanitize SQL like run_query_to_csv does
        sql_clean = (sql or "").strip()
        if sql_clean.endswith(";"):
            sql_clean = sql_clean[:-1].rstrip()

        if _DBOPS_CTX:
            dbops, sop_id, target_db = _DBOPS_CTX
            # DBOps is async; since workflow nodes are sync, run in thread and wait.
            import asyncio

            def _run():
                loop = asyncio.new_event_loop()
                try:
                    asyncio.set_event_loop(loop)
                    return loop.run_until_complete(dbops.select_sql(target_db=target_db, sop_id=sop_id, sql=sql_clean, params={}, host=host))
                finally:
                    loop.close()

            result = _run()
            return result.get("rows", [])
        else:
            rows: list[dict] = []
            with oracledb.connect(
                user=self.s.oracle_user,
                password=self.s.oracle_password,
                dsn=self._dsn(host),
            ) as conn:
                with conn.cursor() as cur:
                    cur.execute(sql_clean)
                    cols = [d[0] for d in cur.description]
                    for r in cur:
                        rows.append({cols[i]: r[i] for i in range(len(cols))})
            return rows
    

    # === NEW: specific helpers for int_dest_lookup updates/snapshot ===

    def update_int_dest_lookup(self, host: str, updates: list[tuple[int, str]]) -> None:
        """
        Apply parameterized updates to int_dest_lookup: (id, url) pairs.
        Commit on success; raise on error (caller can handle).
        """
        sql = "UPDATE int_dest_lookup SET URL = :url WHERE ID = :id"
        if _DBOPS_CTX:
            dbops, sop_id, target_db = _DBOPS_CTX
            import asyncio

            def _run():
                loop = asyncio.new_event_loop()
                try:
                    asyncio.set_event_loop(loop)
                    params = [{"id": _id, "url": _url} for _id, _url in updates]
                    return loop.run_until_complete(dbops.execute_many(target_db=target_db, sop_id=sop_id, sql=sql, seq_of_params=params, host=host))
                finally:
                    loop.close()

            _run()
        else:
            with oracledb.connect(
                user=self.s.oracle_user,
                password=self.s.oracle_password,
                dsn=self._dsn(host),
            ) as conn:
                with conn.cursor() as cur:
                    for _id, _url in updates:
                        cur.execute(sql, {"id": _id, "url": _url})
                conn.commit()

    def snapshot_int_dest_lookup(self, host: str) -> list[dict]:
        """
        Return a canonical snapshot (ordered by ID).
        """
        return self.fetch_all(
            host=host,
            sql="SELECT ID, ROOT_NAME, SUBSCRIPTION_ID, URL FROM int_dest_lookup ORDER BY ID",
        )
