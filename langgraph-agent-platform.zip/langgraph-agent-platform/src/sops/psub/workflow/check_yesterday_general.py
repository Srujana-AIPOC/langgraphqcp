from __future__ import annotations

from ..utils.audit import log_event  # NEW

from typing import Any
from pathlib import Path
from datetime import datetime
import csv

from .config import Settings
from .check_yesterday import check_rows_for_yesterday

def _rows_from_csv(path: str | Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with open(path, "r", encoding="utf-8", newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append(row)
    return rows

def node_check_yesterday_general(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Check the rows from the SECOND Oracle query (general host).
    Writes: output/data/check_yesterday_general_*.txt with 'true'/'false'
    Updates state: check2_result_file, yesterday2_found
    """
    rows = state.get("oracle2_rows")
    if rows is None:
        csv_path = state.get("oracle2_csv_path")
        if not csv_path:
            raise RuntimeError("No oracle2_rows or oracle2_csv_path in state for node_check_yesterday_general.")
        rows = _rows_from_csv(csv_path)

    found = check_rows_for_yesterday(rows, s.timezone)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("output/data"); out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"check_yesterday_general_{ts}.txt"
    out_path.write_text("true" if found else "false", encoding="utf-8")

    state["check2_result_file"] = str(out_path)
    state["yesterday2_found"] = bool(found)

    # NEW: audit ok/fail
    audit = state.get("audit_file")
    log_event(audit, "check_yesterday_general", "ok" if found else "fail", {
        "result_file": str(out_path),
        "yesterday_found": bool(found),
    })

    return state
