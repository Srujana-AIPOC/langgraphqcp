# src/workflow/check_dest_lookup.py
from __future__ import annotations
from ..utils.audit import log_event

from typing import Any
from pathlib import Path
from datetime import datetime
import csv

from .config import Settings
from .oracle_client import OracleClient

SQL_DEST_LOOKUP = "select * from int_dest_lookup"

def node_check_dest_lookup(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Query int_dest_lookup and verify every non-null URL contains s.dest_url_substr (case-insensitive).
    Writes:
      - output/data/dest_urls_all_dummy_YYYYMMDD_HHMMSS.txt  (true|false)
      - output/data/dest_url_violations_YYYYMMDD_HHMMSS.csv  (only if violations)
    Updates state:
      - dest_urls_all_dummy: bool
      - dest_check_file: str
      - dest_violations_csv: str (optional)
    """

    print("[dest] starting node_check_dest_lookup")
    host = state.get("domain")
    if not host:
        raise RuntimeError("Missing 'domain' in state for dest lookup check.")

    ora = OracleClient(s)
    rows = ora.fetch_all(host=host, sql=SQL_DEST_LOOKUP)

    needle = (s.dest_url_substr or "dummy").lower()
    violations: list[dict[str, Any]] = []

    for r in rows:
        url = r.get("URL")
        if url is None:
            violations.append(r)
            continue
        if needle not in str(url).lower():
            violations.append(r)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("output/data")
    out_dir.mkdir(parents=True, exist_ok=True)

    # true/false file
    all_ok = len(violations) == 0
    check_file = out_dir / f"dest_urls_all_dummy_{ts}.txt"
    check_file.write_text("true" if all_ok else "false", encoding="utf-8")

    state["dest_urls_all_dummy"] = all_ok
    state["dest_check_file"] = str(check_file)



    # optional violations CSV
    viol_csv_path = None
    if not all_ok:
        viol_csv = out_dir / f"dest_url_violations_{ts}.csv"
        # pick a stable column order; include the 4 columns you shared if present
        fieldnames = ["ID", "ROOT_NAME", "SUBSCRIPTION_ID", "URL"]
        # include any extra columns present too (flexible)
        extras = [k for k in (rows[0].keys() if rows else []) if k not in fieldnames]
        header = fieldnames + extras
        with open(viol_csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=header)
            w.writeheader()
            for r in violations:
                w.writerow(r)
        state["dest_violations_csv"] = str(viol_csv)
        viol_csv_path = str(viol_csv)

    # NEW: audit event
    audit = state.get("audit_file")
    log_event(
        audit, "check_dest_lookup",
        "ok" if all_ok else "fail",
        {"check_file": str(check_file), "violations_csv": viol_csv_path}
    )

    return state
