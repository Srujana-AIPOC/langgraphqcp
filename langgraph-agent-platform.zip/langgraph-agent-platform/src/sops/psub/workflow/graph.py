# src/workflow/graph.py
from __future__ import annotations
from typing import TypedDict, Any
from datetime import datetime
from pathlib import Path

from langgraph.graph import StateGraph, END

from .config import Settings
from .github_ui import GitHubUI
from .oracle_client import OracleClient
from .check_yesterday import node_check_yesterday
from .check_dest_lookup import node_check_dest_lookup
from .check_lsup_portal import node_check_lsup_portal
# Async preview modules removed; production uses subprocess + sync nodes
from .nslookup_check import node_nslookup_check
from .oracle_general import node_oracle_general
from .check_yesterday_general import node_check_yesterday_general
from .check_dest_lookup_general import node_check_dest_lookup_general
from .maintainy_pdf_download import node_maintainy_pdf_download
from .validate_pdf_report import node_validate_pdf_report
from .lsup_teardown import node_lsup_teardown
from .update_dest_lookup import node_update_dest_lookup
from .lsup_release import node_lsup_release
from .wait_release_green import node_wait_release_green

# NEW: audit helper
from ..utils.audit import log_event

class FlowState(TypedDict, total=False):
    headful: bool
    audit_file: str  # NEW: audit path

    oracle_ok: bool
    oracle_error: str

    domain: str
    oracle_csv_path: str
    oracle_rows: list[dict[str, Any]]
    check_result_file: str
    yesterday_found: bool

    dest_urls_all_dummy: bool
    dest_check_file: str
    dest_violations_csv: str

    portal_builds_ok: bool
    portal_builds_txt: str
    portal_builds_report: str
    portal_screenshot: str

    nslookup_domain: str
    nslookup_output_file: str
    nslookup_match_file: str
    nslookup_match: bool

    oracle2_csv_path: str
    oracle2_rows: list[dict[str, Any]]
    check2_result_file: str
    yesterday2_found: bool

    dest2_urls_all_dummy: bool
    dest2_check_file: str
    dest2_violations_csv: str

    maintainy_pdf_path: str
    maintainy_pdf_meta: dict[str, Any]
    maintainy_pdf_screenshot: str

    pdf_validation_ok: bool
    pdf_validation_report: str
    pdf_page_shots: list[str]

    teardown_env_filter: str
    teardown_build_selected: int
    teardown_ok: bool
    teardown_result_file: str
    teardown_screenshot_before: str
    teardown_screenshot_after: str
    teardown_result_json: str

    dest_update_host: str
    dest_updates_ok: bool
    dest_updates_file: str
    dest_after_csv: str
    dest_update_summary: str
    dest_update_error: str

    release_precheck_ok: bool
    release_clicked_build: int
    release_alert_seen: bool
    release_result_json: str
    release_ok: bool
    release_before_shot: str
    release_after_shot: str
    release_propagated: bool
    release_wait_summary: str

def node_github_extract_domain(state: FlowState, s: Settings, slow: int) -> FlowState:
    """
    CHANGED: catch failures and log to audit instead of raising.
    """
    audit = state.get("audit_file")
    gh = GitHubUI(s, headful=state.get("headful"), slow=slow)
    try:
        domain = gh.get_domain_from_latest_prefixed_run()
        state["domain"] = domain
        log_event(audit, "github_domain", "ok", {"domain": domain})
    except Exception as e:
        state["domain"] = None  # gate will END
        log_event(audit, "github_domain", "fail", {"error": str(e)})
    return state


# Async preview removed; keeping only production sync graph.

def node_oracle_query(state: FlowState, s: Settings) -> FlowState:
    # NEW: audit + robust failure handling
    from ..utils.audit import log_event  # local import to avoid cycles
    audit = state.get("audit_file")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("output/data"); out_dir.mkdir(parents=True, exist_ok=True)

    try:
        ora = OracleClient(s)
        out_csv = out_dir / f"query_{ts}.csv"
        res = ora.run_query_to_csv(host=state["domain"], sql=s.oracle_sql, out_path=out_csv)

        state["oracle_csv_path"] = str(res.out_csv)
        rows = getattr(res, "rows", None)
        if rows is not None:
            state["oracle_rows"] = rows

        # NEW: mark success + audit
        state["oracle_ok"] = True
        log_event(audit, "oracle", "ok", {
            "csv": str(out_csv),
            "rows": len(rows or [])
        })
        return state

    except Exception as e:
        # NEW: mark failure, write error artifact, audit
        err_path = out_dir / f"oracle_error_{ts}.txt"
        err_path.write_text(repr(e), encoding="utf-8")

        state["oracle_ok"] = False
        state["oracle_error"] = str(e)
        log_event(audit, "oracle", "fail", {
            "error": str(e),
            "error_file": str(err_path)
        })
        return state


def build_graph(settings: Settings, slow: int = 0):
    g = StateGraph(FlowState)

    # Nodes
    g.add_node("github_domain",          lambda st: node_github_extract_domain(st, settings, slow))
    g.add_node("oracle",                 lambda st: node_oracle_query(st, settings))
    g.add_node("check_yesterday",        lambda st: node_check_yesterday(st, settings))
    g.add_node("check_dest_lookup",      lambda st: node_check_dest_lookup(st, settings))
    g.add_node("lsup_release",           lambda st: node_lsup_release(st, settings))
    g.add_node("wait_release_green",     lambda st: node_wait_release_green(st, settings))
    g.add_node("check_lsup_portal",      lambda st: node_check_lsup_portal(st, settings))
    g.add_node("nslookup_check",         lambda st: node_nslookup_check(st, settings))
    g.add_node("oracle_general",         lambda st: node_oracle_general(st, settings))
    g.add_node("check_yesterday_general",lambda st: node_check_yesterday_general(st, settings))
    g.add_node("check_dest_lookup_general", lambda st: node_check_dest_lookup_general(st, settings))
    g.add_node("maintainy_pdf_download", lambda st: node_maintainy_pdf_download(st, settings))
    g.add_node("validate_pdf_report",    lambda st: node_validate_pdf_report(st, settings))
    g.add_node("lsup_teardown",          lambda st: node_lsup_teardown(st, settings))
    g.add_node("update_dest_lookup",     lambda st: node_update_dest_lookup(st, settings))

    # Entry
    g.set_entry_point("github_domain")

    # Gate 1: domain extracted?
    def _route_after_github(st: FlowState) -> str:
        return "oracle" if st.get("domain") else END
    g.add_conditional_edges(
        "github_domain",
        _route_after_github,
        {"oracle": "oracle", END: END},
    )

    # Oracle → Yesterday
    #check connection established succefuly 
    # Gate 1: domain extracted?
    def _route_after_dns_extraction(st: FlowState) -> str:
        return "check_yesterday" if st.get("oracle_ok") else END
    g.add_conditional_edges(
        "oracle",
        _route_after_dns_extraction,
        {"check_yesterday": "check_yesterday", END: END},
    )
    #g.add_edge("oracle", "check_yesterday")

    # Gate 2: yesterday present?
    def _route_after_yday(st: FlowState) -> str:
        return "check_dest_lookup" if st.get("yesterday_found") else END
    g.add_conditional_edges(
        "check_yesterday",
        _route_after_yday,
        {"check_dest_lookup": "check_dest_lookup", END: END},
    )

    # Gate 3: dummy URLs (host#1) all OK?
    def _route_after_dest(st: FlowState) -> str:
        return "lsup_release" if st.get("dest_urls_all_dummy") else END
    g.add_conditional_edges(
        "check_dest_lookup",
        _route_after_dest,
        {"lsup_release": "lsup_release", END: END},
    )

    # Release → wait propagation--------------------------------------
    g.add_edge("lsup_release", "wait_release_green")

    # Gate 4: propagation seen?
    def _route_after_wait(st: FlowState) -> str:
        return "check_lsup_portal" if st.get("release_propagated") else END
    g.add_conditional_edges(
        "wait_release_green",
        _route_after_wait,
        {"check_lsup_portal": "check_lsup_portal", END: END},
    )

    # Gate 5: portal shows max build is green+bold?////////////////duplicate edge  g.add_edge("check_lsup_portal", "nslookup_check")
    def _route_after_portal(st: FlowState) -> str:
        return "nslookup_check" if st.get("portal_builds_ok") else END
    g.add_conditional_edges(
        "check_lsup_portal",
        _route_after_portal,
        {"nslookup_check": "nslookup_check", END: END},
    )
    
    # Gate 6: oracle_general succeeded?
    def _route_after_oracle2(st: FlowState) -> str:
        return "check_yesterday_general" if st.get("oracle2_ok") else END
    g.add_conditional_edges(
        "oracle_general",
        _route_after_oracle2,
        {"check_yesterday_general": "check_yesterday_general", END: END},
    )

    # Gate 7: yesterday present on general host?
    def _route_after_yday2(st: FlowState) -> str:
        return "check_dest_lookup_general" if st.get("yesterday2_found") else END
    g.add_conditional_edges(
        "check_yesterday_general",
        _route_after_yday2,
        {"check_dest_lookup_general": "check_dest_lookup_general", END: END},
    )

    # Gate 8: dummy URLs (host#2) all OK?
    def _route_after_dest2(st: FlowState) -> str:
        return "maintainy_pdf_download" if st.get("dest2_urls_all_dummy") else END
    g.add_conditional_edges(
        "check_dest_lookup_general",
        _route_after_dest2,
        {"maintainy_pdf_download": "maintainy_pdf_download", END: END},
    )

    # NEW Gate A: run validator only if file exists
    def _route_after_download(st: FlowState) -> str:
        p = st.get("maintainy_pdf_path")
        try:
            return "validate_pdf_report" if (p and Path(p).exists()) else END
        except Exception:
            return END
    g.add_conditional_edges("maintainy_pdf_download", _route_after_download, {
        "validate_pdf_report": "validate_pdf_report",
        END: END
    })

    # NEW Gate B: proceed to teardown only on validation ok
    def _route_after_pdf(st: FlowState) -> str:
        return "lsup_teardown" if st.get("pdf_validation_ok") else END
    g.add_conditional_edges("validate_pdf_report", _route_after_pdf, {
        "lsup_teardown": "lsup_teardown",
        END: END
    })

   



    # Remainder of the pipeline
    #g.add_edge("check_lsup_portal", "nslookup_check")
    g.add_edge("nslookup_check", "oracle_general")
    g.add_edge("oracle_general", "check_yesterday_general")
    g.add_edge("check_yesterday_general", "check_dest_lookup_general")
    g.add_edge("check_dest_lookup_general", "maintainy_pdf_download")
    g.add_edge("maintainy_pdf_download", "validate_pdf_report")
    #g.add_edge("validate_pdf_report", "lsup_teardown")


    g.add_edge("lsup_teardown", "update_dest_lookup")
    g.add_edge("update_dest_lookup", END)

    return g.compile()


# Phase 2: minimal async graph that runs only the GitHub domain extraction
def build_graph_async(settings: Settings, slow: int = 0):
    # Async preview removed
    raise NotImplementedError("Async path removed; use subprocess pipeline")


async def run_pipeline_async(headful: bool | None = None, slow: int = 0) -> FlowState:
    # Async preview removed
    raise NotImplementedError("Async path removed; use subprocess pipeline")
