from __future__ import annotations
from typing import Any, Iterable
from ..utils.audit import log_event

# src/workflow/check_yesterday.py

from typing import Any
from pathlib import Path
from datetime import datetime, timedelta
import csv

from .config import Settings

#new block during reusabilty of code
def _rows_from_csv(path: str | Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with open(path, "r", encoding="utf-8", newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append(row)
    return rows

def check_rows_for_yesterday(rows: Iterable[dict[str, Any]], tz_name: str) -> bool:
    """
    Return True if any CREATION_DT in `rows` equals yesterday's date in the given timezone.
    Expects either a datetime object or a string parseable by fromisoformat/strftime('%Y-%m-%d %H:%M:%S').
    """
    # Compute yesterday in desired timezone (we compare by date only)
    # We only have tz name in settings, so use naive local calc; for most DB timestamps this is sufficient.
    today = datetime.now()
    yday = (today - timedelta(days=1)).date()

    for row in rows:
        v = row.get("CREATION_DT")
        if v is None:
            continue
        dt: datetime | None = None
        if isinstance(v, datetime):
            dt = v
        else:
            s = str(v).strip()
            # Try common formats
            for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d-%b-%Y %H:%M:%S"):
                try:
                    dt = datetime.strptime(s, fmt)
                    break
                except Exception:
                    continue
            if dt is None:
                try:
                    dt = datetime.fromisoformat(s)
                except Exception:
                    dt = None
        if dt and dt.date() == yday:
            return True
    return False
#end new block during reusabilty of code

def _parse_dt(value: str) -> datetime:
    """
    Try a couple of common formats. Your CSV currently looks like 'YYYY-MM-DD HH:MM:SS'.
    """
    try:
        return datetime.fromisoformat(value)
    except Exception:
        return datetime.strptime(value, "%Y-%m-%d %H:%M:%S")

def node_check_yesterday(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Existing node: checks the rows from the FIRST Oracle query (github-domain host).
    Writes: output/data/check_yesterday_*.txt with 'true'/'false'
    """
    rows = state.get("oracle_rows")
    if rows is None:
        csv_path = state.get("oracle_csv_path")
        if not csv_path:
            raise RuntimeError("No oracle_rows or oracle_csv_path in state for node_check_yesterday.")
        rows = _rows_from_csv(csv_path)

    found = check_rows_for_yesterday(rows, s.timezone)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("output/data"); out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"check_yesterday_{ts}.txt"
    out_path.write_text("true" if found else "false", encoding="utf-8")

    state["check_result_file"] = str(out_path)
    state["yesterday_found"] = bool(found)

     # NEW: audit event
    audit = state.get("audit_file")
    log_event(
        audit, "check_yesterday",
        "ok" if found else "fail",
        {"result_file": str(out_path), "yesterday_found": bool(found)}
    )

    return state
