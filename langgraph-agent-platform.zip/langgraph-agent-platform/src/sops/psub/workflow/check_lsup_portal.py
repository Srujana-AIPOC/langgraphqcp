# src/workflow/check_lsup_portal.py
from __future__ import annotations
from ..utils.audit import log_event  # NEW

from typing import Any
from pathlib import Path
from datetime import datetime
import re  # <-- added

from playwright.sync_api import sync_playwright, BrowserContext, Page, expect

from .config import Settings

def _launch_portal_context(s: Settings, headful: bool) -> tuple[Any, BrowserContext, Page]:
    """
    Headful: use persistent profile so user can interact and we can save storage for later.
    Headless: prefer storage file if present for instant login; if not, raise a clear error.
    """
    p = sync_playwright().start()
    storage_file = Path("output/.pw-lsup.json")

    if not headful and storage_file.exists():
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(storage_state=str(storage_file))
        ctx.set_default_timeout(60_000)
        return p, ctx, ctx.new_page()

    # Headful (or first bootstrap)
    user_dir = Path(s.pw_user_data_dir).expanduser().resolve()  # reuse the same profile
    ctx = p.chromium.launch_persistent_context(
        user_data_dir=str(user_dir),
        headless=not headful,
        slow_mo=4000,
    )
    ctx.set_default_timeout(60_000)
    return p, ctx, ctx.new_page()

def _login_if_needed(page: Page, s: Settings):
    """
    Navigate to the portal root and wait for either:
      - dashboard (/app) UI (header/filter), or
      - login form (two inputs + 'Sign in' button)
    If login form is present, perform login. Otherwise assume we're in /app.
    """
    page.goto(s.portal_url, wait_until="domcontentloaded")

    # Helper probes
    def _dashboard_ready() -> bool:
        try:
            # Either the Builds header text or the Environment filter is visible
            if page.locator('text="Active / Released Builds"').first.is_visible(timeout=500):
                return True
            if page.get_by_placeholder("Enter Environment...").is_visible(timeout=500):
                return True
        except Exception:
            pass
        return "/app" in page.url

    def _login_form_ready() -> bool:
        try:
            # Two inputs and a "Sign in" button
            if page.locator("form input").count() >= 2 and \
               page.get_by_role("button", name="Sign in").is_visible(timeout=500):
                return True
        except Exception:
            pass
        return False

    # Wait up to ~6s polling for either state
    deadline = page.context._loop.time() + 6.0
    while page.context._loop.time() < deadline:
        if _dashboard_ready():
            return
        if _login_form_ready():
            break
        page.wait_for_timeout(250)

    # If we didn’t detect the dashboard, try logging in if the form is present
    if _login_form_ready():
        inputs = page.locator("form input")
        inputs.nth(0).fill(s.portal_user)
        inputs.nth(1).fill(s.portal_password)
        page.get_by_role("button", name="Sign in").click()

        # Wait for SPA route to settle on /app and a dashboard marker
        page.wait_for_url("**/app", timeout=30_000)
        try:
            page.get_by_placeholder("Enter Environment...").wait_for(timeout=5000)
        except Exception:
            page.locator('text="Active / Released Builds"').first.wait_for(timeout=5000)

        # Save storage for headless reuse if enabled
        if s.portal_save_storage:
            storage_file = Path("output/.pw-lsup.json")
            storage_file.parent.mkdir(parents=True, exist_ok=True)
            page.context.storage_state(path=str(storage_file))
        return

    # Neither dashboard nor login form – capture for diagnostics
    page.screenshot(path="output/screenshots/portal_login_detect_failed.png")
    html_path = Path("output/logs/portal_login_detect_failed.html")
    html_path.parent.mkdir(parents=True, exist_ok=True)
    html_path.write_text(page.content(), encoding="utf-8")
    raise RuntimeError(
        "Portal did not show dashboard or login form after navigation. "
        "Saved screenshot and HTML to output/screenshots/ and output/logs/."
    )

def _ensure_builds_tab(page: Page):
    """
    Dashboard defaults to 'Builds' tab, but we click it if needed and wait for table/filter.
    """
    # If you ever add other default tabs, this ensures correctness
    try:
        page.get_by_role("button", name="Builds").click(timeout=2000)
    except Exception:
        pass  # already active

    # Wait for either header or the Environment filter input
    # Placeholder from BuildsTable: "Enter Environment..."
    try:
        page.get_by_placeholder("Enter Environment...").wait_for(timeout=5000)
    except Exception:
        # Fallback: header text
        expect(page.get_by_text("Active / Released Builds")).to_be_visible(timeout=5000)

def _parse_rows_for_env(page: Page, env_filter: str) -> list[dict[str, Any]]:
    """
    After filtering, read all rows from the builds list and return:
      [{'env': 'LSUP', 'build': 2501, 'greenBold': True, 'classes': '...'}, ...]
    NOTE: Build number is a <Link>, so we read classes from the <a>, not the parent cell.
    """
    # Type in filter (placeholder is exact)
    env_input = page.get_by_placeholder("Enter Environment...")
    env_input.fill("")             # clear
    env_input.fill(env_filter)     # e.g., 'lsup'
    page.wait_for_timeout(500)     # let filtering settle (simple debounce)

    # Rows are rendered as: div.divide-y > div.grid.grid-cols-12.bg-white
    rows = page.locator("div.divide-y div.grid.grid-cols-12.bg-white")

    result = []
    count = rows.count()
    for i in range(count):
        row = rows.nth(i)

        # ENV = 1st column, BUILD NUMBER = 3rd column
        env_cell = row.locator(":scope > div.col-span-3").nth(0)
        build_cell = row.locator(":scope > div.col-span-3").nth(2)

        # Build number is a <Link> with className based on 'released' (green+bold)
        build_link = build_cell.locator('a[href^="/app/builds/"]').first

        env_text = (env_cell.inner_text(timeout=1000) or "").strip()

        build_num: int | None = None
        classes = ""

        if build_link.count() > 0:
            txt = (build_link.inner_text(timeout=1000) or "").strip()
            # robust: parse from text; if not numeric, parse href /app/builds/<num>
            if txt.isdigit():
                build_num = int(txt)
            else:
                href = build_link.get_attribute("href") or ""
                m = re.match(r"^/app/builds/(\d+)$", href)
                if m:
                    build_num = int(m.group(1))

            classes = build_link.get_attribute("class") or ""
        else:
            # Fallback: if no link for some reason, read the cell text
            cell_txt = (build_cell.inner_text(timeout=1000) or "").strip()
            digits = "".join(ch for ch in cell_txt if ch.isdigit())
            build_num = int(digits) if digits else None
            classes = build_cell.get_attribute("class") or ""

        is_green_bold = ("text-green-700" in classes) and ("font-semibold" in classes)

        result.append({
            "env": env_text,
            "build": build_num,
            "greenBold": is_green_bold,
            "classes": classes,
        })

    return result

def node_check_lsup_portal(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    1) Login (or reuse storage) to portal
    2) Go to Builds
    3) Filter Environment by s.portal_env_filter (default 'lsup')
    4) Find max build for ENV=LSUP and assert that row is green+bold
    5) Write artifacts and update state
    """
    p, ctx, page = _launch_portal_context(s, headful=state.get("headful", False))
    try:
        _login_if_needed(page, s)
        _ensure_builds_tab(page)

        rows = _parse_rows_for_env(page, s.portal_env_filter)
        # keep only LSUP (case-insensitive), though UI is already filtered
        filtered = [r for r in rows if (r["env"] or "").strip().lower() == s.portal_env_filter.lower()]

        # Compute max build
        builds = [r["build"] for r in filtered if isinstance(r["build"], int)]
        max_build = max(builds) if builds else None

        ok = False
        checked_row: dict[str, Any] | None = None
        if max_build is not None:
            for r in filtered:
                if r["build"] == max_build:
                    checked_row = r
                    ok = bool(r["greenBold"])
                    break

        # Artifacts
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_dir = Path("output/data"); out_dir.mkdir(parents=True, exist_ok=True)
        shots_dir = Path("output/screenshots"); shots_dir.mkdir(parents=True, exist_ok=True)

        txt_path = out_dir / f"lsup_portal_builds_ok_{ts}.txt"
        txt_path.write_text("true" if ok else "false", encoding="utf-8")

        # JSON report
        import json
        report = {
            "env_filter": s.portal_env_filter,
            "max_build": max_build,
            "checked_row": checked_row,
            "rows_after_filter": rows,
            "ok": ok,
        }
        json_path = out_dir / f"lsup_portal_builds_report_{ts}.json"
        json_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

        # Screenshot for evidence
        shot_path = shots_dir / f"lsup_builds_{ts}.png"
        page.screenshot(path=str(shot_path), full_page=False)

        # Update pipeline state
        state["portal_builds_ok"] = ok
        state["portal_builds_txt"] = str(txt_path)
        state["portal_builds_report"] = str(json_path)
        state["portal_screenshot"] = str(shot_path)

        # NEW: audit portal max-build state
        audit = state.get("audit_file")
        log_event(audit, "check_lsup_portal", "ok" if ok else "fail", {
            "env_filter": s.portal_env_filter,
            "max_build": max_build,
            "txt_path": str(txt_path),
            "report_json": str(json_path),
            "screenshot": str(shot_path),
        })


        return state
    finally:
        try:
            ctx.close()
        except Exception:
            pass
        try:
            p.stop()
        except Exception:
            pass
