# src/workflow/check_dest_lookup_general.py
from __future__ import annotations
from ..utils.audit import log_event  # NEW

from typing import Any
from pathlib import Path
from datetime import datetime
import csv

from .config import Settings
from .oracle_client import OracleClient

def node_check_dest_lookup_general(state: dict[str, Any], s: Settings) -> dict[str, Any]:
    """
    Re-run the 'URL must contain <substr>' check against the *general* Oracle host.
    Uses s.dest_url_substr (default 'dummy') and s.dest_lookup_sql (default 'select * from int_dest_lookup').

    Artifacts:
      - output/data/dest_urls_all_dummy_general_{ts}.txt  -> 'true' | 'false'
      - output/data/dest_url_violations_general_{ts}.csv  (only if violations)

    State additions:
      - dest2_urls_all_dummy: bool
      - dest2_check_file: str
      - dest2_violations_csv: str (present only when false)
    """
    if not s.oracle_host_general:
        raise RuntimeError("ORACLE_HOST_GENERAL is not set in environment.")

    ora = OracleClient(s)
    rows = ora.fetch_all(host=s.oracle_host_general, sql=s.dest_lookup_sql)

    needle = (s.dest_url_substr or "dummy").lower()
    violations: list[dict[str, Any]] = []

    for r in rows:
        url = r.get("URL")
        if url is None or needle not in str(url).lower():
            violations.append(r)

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_dir = Path("output/data"); out_dir.mkdir(parents=True, exist_ok=True)

    # true/false file
    all_ok = len(violations) == 0
    check_file = out_dir / f"dest_urls_all_dummy_general_{ts}.txt"
    check_file.write_text("true" if all_ok else "false", encoding="utf-8")

    state["dest2_urls_all_dummy"] = all_ok
    state["dest2_check_file"] = str(check_file)

    if not all_ok:
        viol_csv = out_dir / f"dest_url_violations_general_{ts}.csv"
        # keep the main 4 columns if present; include any extras too
        fieldnames = ["ID", "ROOT_NAME", "SUBSCRIPTION_ID", "URL"]
        extras = [k for k in (rows[0].keys() if rows else []) if k not in fieldnames]
        header = fieldnames + extras

        with open(viol_csv, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=header)
            w.writeheader()
            for r in violations:
                w.writerow(r)

        state["dest2_violations_csv"] = str(viol_csv)

    # NEW: audit ok/fail for general-host dummy URL check
    audit = state.get("audit_file")
    log_event(audit, "check_dest_lookup_general", "ok" if all_ok else "fail", {
        "check_file": str(check_file),
        "violations_csv": state.get("dest2_violations_csv"),
    })


    return state
