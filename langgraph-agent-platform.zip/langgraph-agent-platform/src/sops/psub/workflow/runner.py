from __future__ import annotations

from .config import Settings
from .graph import build_graph, FlowState

from ..utils.audit import start_audit, finalize

#def run_pipeline(headful: bool | None = None, slow: int = 0) -> FlowState:
#    s = Settings()
#    graph = build_graph(s, slow=slow)
#    init: FlowState = {"headful": s.headful if headful is None else headful}
#    return graph.invoke(init)


def run_pipeline(headful: bool | None = None, slow: int = 0) -> FlowState:
    s = Settings()
    graph = build_graph(s, slow)
    audit_path = start_audit()
    try:
        init: FlowState = {
            "headful": s.headful if headful is None else headful,
            "audit_file": str(audit_path),
        }
        return graph.invoke(init)
    finally:
        finalize(audit_path)
