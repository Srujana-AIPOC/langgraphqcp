from __future__ import annotations
import asyncio
from dataclasses import dataclass
from typing import Optional

try:
    from playwright.async_api import async_playwright, Browser, BrowserContext, Page
except Exception:  # pragma: no cover
    # Allow import of this module even if Playwright is not installed at runtime
    async_playwright = None  # type: ignore
    Browser = object  # type: ignore
    BrowserContext = object  # type: ignore
    Page = object  # type: ignore


@dataclass
class _TraceConfig:
    mode: str = "off"  # off | on_error | always


class PlaywrightManager:
    

    def __init__(self) -> None:
        self._plw = None
        self._browser: Optional[Browser] = None
        self._sem: Optional[asyncio.Semaphore] = None
        self._trace = _TraceConfig()
        self._engine = "chromium"
        self._headful_default = False
        self._slow_mo = 0

    @classmethod
    async def create(
        cls,
        engine: str = "chromium",
        headful_default: bool = False,
        slow_mo: int = 0,
        max_contexts: int = 4,
        trace: str = "off",
    ) -> "PlaywrightManager":
        self = cls()
        self._engine = engine
        self._headful_default = bool(headful_default)
        self._slow_mo = int(slow_mo)
        self._sem = asyncio.Semaphore(int(max_contexts) if max_contexts and max_contexts > 0 else 1)
        self._trace = _TraceConfig(mode=str(trace or "off").lower())

        if async_playwright is None:
            raise RuntimeError("Playwright is not available; ensure 'playwright' is installed")

        self._plw = await async_playwright().start()
        if self._engine == "chromium":
            self._browser = await self._plw.chromium.launch(
                headless=not self._headful_default, slow_mo=self._slow_mo
            )
        elif self._engine == "firefox":
            self._browser = await self._plw.firefox.launch(
                headless=not self._headful_default, slow_mo=self._slow_mo
            )
        elif self._engine == "webkit":
            self._browser = await self._plw.webkit.launch(
                headless=not self._headful_default, slow_mo=self._slow_mo
            )
        else:
            await self.shutdown()
            raise ValueError(f"Unsupported Playwright engine: {self._engine}")

        return self

    async def acquire_context(
        self,
        *,
        headful: bool | None = None,  # currently not applied per context
        storage_state: str | dict | None = None,
    ) -> BrowserContext:
        if not self._browser or not self._sem:
            raise RuntimeError("PlaywrightManager not initialized")
        await self._sem.acquire()
        ctx = await self._browser.new_context(storage_state=storage_state)
        # Tracing policy can be wired here in later phases
        return ctx

    async def release_context(self, ctx: BrowserContext) -> None:
        try:
            # Stop tracing here if enabled (deferred to later phases)
            await ctx.close()
        finally:
            if self._sem:
                self._sem.release()

    async def new_page(self, ctx: BrowserContext) -> Page:
        return await ctx.new_page()

    async def shutdown(self) -> None:
        try:
            if self._browser:
                await self._browser.close()
        finally:
            self._browser = None
            if self._plw:
                await self._plw.stop()
            self._plw = None

