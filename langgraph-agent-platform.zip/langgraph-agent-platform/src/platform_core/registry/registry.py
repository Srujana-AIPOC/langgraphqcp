from typing import Callable, Dict, List, Tuple

_builders: Dict[str, Callable[[], object]] = {}

def register_sop(sop_id: str, builder: Callable[[], object]) -> None:
    _builders[sop_id] = builder

def get_sop(sop_id: str) -> object:
    try:
        return _builders[sop_id]()
    except KeyError:
        raise KeyError(f"SOP not registered: {sop_id}")

def list_sops() -> List[str]:
    """Return the list of registered SOP IDs (sorted)."""
    return sorted(_builders.keys())

def list_sops_with_classes() -> List[Tuple[str, str]]:
    """Return (sop_id, class_name) pairs. Best-effort: instantiates builders."""
    out: List[Tuple[str, str]] = []
    for sop_id, builder in _builders.items():
        cls_name = "<unknown>"
        try:
            inst = builder()
            cls_name = inst.__class__.__name__
        except Exception:
            pass
        out.append((sop_id, cls_name))
    return sorted(out, key=lambda x: x[0])
