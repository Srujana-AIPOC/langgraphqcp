"""
Checkpointer
------------

Purpose:
- Central place to persist execution checkpoints (per run) so a SOP can be
  resumed, audited, or replayed later. This is the persistence counterpart to
  structured logs/metrics and complements observability.

Intended usage in this repo:
- The supervisor/SOPs call the checkpointer at key milestones to store a
  compact snapshot of state for a `run_id` (and later, optionally `sop_id`,
  `tenant`, `node_id`, etc.).
- Storage backend is Postgres as configured in `configs/base.toml` under
  `[checkpointer]` with DSN supplied via the `CHECKPOINTER_DSN` environment
  variable (see `.env.example`).

Design notes:
- Keep payloads small and redact sensitive fields before saving.
- Primary operations are: save (append/update a checkpoint) and, in the future,
  load (fetch last checkpoint), list (history), and prune (retention policy).
- Implementation is intentionally minimal now; wire up actual persistence when
  integrating E2E flows and tests.
"""

from typing import Any, Dict


class Checkpointer:
    """Simple checkpoint persistence facade.

    Objective:
    - Provide a minimal interface (`save`) to persist run checkpoints so that
      executions can be resumed or audited without coupling callers to a
      specific database library.

    Parameters:
    - dsn: Optional database DSN for the backing store (Postgres).
      If not supplied here, callers can inject one later or this class can be
      extended to read from config on initialization.
    """

    def __init__(self, dsn: str | None = None) -> None:
        self.dsn = dsn

    def save(self, run_id: str, state: Dict[str, Any]) -> None:
        """Persist a checkpoint for a given run.

        Args:
            run_id: Correlation identifier for the execution.
            state: JSON-serializable snapshot to persist (redacted/compact).

        Notes:
            - TODO: Implement durable persistence (Postgres table) keyed by
              `run_id` and a monotonic sequence or timestamp.
            - Consider lightweight schema: (run_id, ts, sop_id, node_id, state).
        """
        # TODO: implement persistence to Postgres
        pass
