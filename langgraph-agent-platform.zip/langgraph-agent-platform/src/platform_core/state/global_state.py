from pydantic import BaseModel

class GlobalState(BaseModel):
    run_id: str
    tenant: str | None = None
    sop_id: str | None = None
    feature_flags: dict = {}
