from typing import Dict, Any
from .policies import route_task

def choose_sop(task: Dict[str, Any]) -> str:
    task_type = task.get("task_type")
    sop = route_task(task_type)
    if not sop:
        raise ValueError(f"No SOP found for task_type={task_type!r}")
    return sop
