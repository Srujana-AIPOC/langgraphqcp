from typing import Optional

def route_task(task_type: str) -> Optional[str]:
    # Deterministic rule-based mapping
    if task_type == "test":
        return "test-sop"
    if task_type == "psub_flow":
        return "psub-workflow"
    if task_type == "user_onboarding":
        return "user-onboarding"
    return None
