from typing import Any, Dict, List
from sqlalchemy.ext.asyncio import AsyncEngine
from sqlalchemy import text

async def run_select(engine: AsyncEngine, sql: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
    async with engine.connect() as conn:
        result = await conn.execute(text(sql), params)
        rows = [dict(r._mapping) for r in result.fetchall()]
        return rows
