from __future__ import annotations
from typing import Any, Dict, List, Sequence
import asyncio


def _select_sync(pool, sql: str, params: Dict[str, Any] | None) -> List[Dict[str, Any]]:
    params = params or {}
    rows: List[Dict[str, Any]] = []
    conn = pool.acquire()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [d[0] for d in cur.description]
            for r in cur:
                rows.append({cols[i]: r[i] for i in range(len(cols))})
    finally:
        conn.close()
    return rows


async def run_select(pool, sql: str, params: Dict[str, Any] | None) -> List[Dict[str, Any]]:
    return await asyncio.to_thread(_select_sync, pool, sql, params)


def _execute_many_sync(pool, sql: str, seq_of_params: Sequence[Dict[str, Any]]) -> int:
    conn = pool.acquire()
    try:
        with conn.cursor() as cur:
            cur.executemany(sql, seq_of_params)
        conn.commit()
    finally:
        conn.close()
    # oracledb doesn't return total rowcount reliably per batch; best-effort length
    return len(seq_of_params)


async def run_execute_many(pool, sql: str, seq_of_params: Sequence[Dict[str, Any]]) -> int:
    return await asyncio.to_thread(_execute_many_sync, pool, sql, seq_of_params)
