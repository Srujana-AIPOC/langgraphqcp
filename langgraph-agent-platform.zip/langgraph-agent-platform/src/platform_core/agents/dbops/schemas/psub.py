from pydantic import BaseModel
from typing import Optional

class PsubRow(BaseModel):
    id: int
    key: str
    value: Optional[str] = None
