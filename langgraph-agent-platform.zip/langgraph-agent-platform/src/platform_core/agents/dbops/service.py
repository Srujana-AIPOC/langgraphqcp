import os
from typing import Any, Dict, List
from .policies.acl import check_acl
from .pooling.postgres import build_engine as build_pg_engine
from .adapters.postgres import run_select as pg_run_select
from .pooling.oracle import build_pool as build_ora_pool
from .adapters.oracle import run_select as ora_run_select, run_execute_many as ora_run_execute_many

class DBOpsService:
    def __init__(self, connections_cfg: Dict[str, Any]) -> None:
        self.connections_cfg = connections_cfg
        self._engines: Dict[str, Any] = {}

    def _get_engine(self, target_db: str):
        db = self.connections_cfg[target_db]
        driver = db.get("driver", "postgres")
        if driver == "postgres":
            dsn = os.getenv(db.get("dsn_env", ""))
            if not dsn:
                raise RuntimeError(f"Missing DSN env var for {target_db}")
            key = f"pg:{target_db}:{dsn}"
            if key not in self._engines:
                self._engines[key] = build_pg_engine(
                    dsn,
                    pool_min=int(db.get("pool_min", 1)),
                    pool_max=int(db.get("pool_max", 5)),
                )
            return self._engines[key]
        else:
            raise RuntimeError(f"_get_engine only supports fixed-DSN DBs (got driver={driver})")

    def _get_oracle_pool_for_host(self, target_db: str, host: str):
        db = self.connections_cfg[target_db]
        if db.get("driver") != "oracle":
            raise RuntimeError(f"Target DB {target_db} is not oracle")
        user_env = db.get("user_env")
        pwd_env = db.get("password_env")
        port = int(db.get("port", 1521))
        service_name = db.get("service_name") or os.getenv(db.get("service_name_env", "")) or "ORCLPDB1"
        if not user_env or not pwd_env:
            raise RuntimeError(f"Oracle config for {target_db} missing user_env/password_env")
        user = os.getenv(user_env, "")
        password = os.getenv(pwd_env, "")
        if not user or not password:
            raise RuntimeError(f"Oracle credentials env vars not set for {target_db}")
        dsn = f"{host}:{port}/{service_name}"
        key = f"ora:{target_db}:{dsn}:{user}"
        if key not in self._engines:
            self._engines[key] = build_ora_pool(
                user=user,
                password=password,
                dsn=dsn,
                pool_min=int(db.get("pool_min", 1)),
                pool_max=int(db.get("pool_max", 5)),
            )
        return self._engines[key]

    async def select_template(self, *, target_db: str, sop_id: str, template_path: str, params: Dict[str, Any]) -> Dict[str, Any]:
        check_acl(self.connections_cfg, target_db, sop_id, "select")
        db = self.connections_cfg[target_db]
        driver = db.get("driver", "postgres")
        # Load SQL template from disk
        with open(template_path, "r", encoding="utf-8") as f:
            sql = f.read()
        if driver == "postgres":
            engine = self._get_engine(target_db)
            rows = await pg_run_select(engine, sql, params)
        elif driver == "oracle":
            host = params.pop("_host", None)
            if not host:
                raise RuntimeError("Oracle select_template requires '_host' in params")
            pool = self._get_oracle_pool_for_host(target_db, host)
            rows = await ora_run_select(pool, sql, params)
        else:
            raise RuntimeError(f"Unsupported driver: {driver}")
        return {"rows": rows, "row_count": len(rows)}

    async def select_sql(self, *, target_db: str, sop_id: str, sql: str, params: Dict[str, Any] | None = None, host: str | None = None) -> Dict[str, Any]:
        params = params or {}
        check_acl(self.connections_cfg, target_db, sop_id, "select")
        db = self.connections_cfg[target_db]
        driver = db.get("driver", "postgres")
        if driver == "postgres":
            engine = self._get_engine(target_db)
            rows = await pg_run_select(engine, sql, params)
        elif driver == "oracle":
            if not host:
                raise RuntimeError("Oracle select_sql requires host argument")
            pool = self._get_oracle_pool_for_host(target_db, host)
            rows = await ora_run_select(pool, sql, params)
        else:
            raise RuntimeError(f"Unsupported driver: {driver}")
        return {"rows": rows, "row_count": len(rows)}

    async def execute_many(self, *, target_db: str, sop_id: str, sql: str, seq_of_params: List[Dict[str, Any]], host: str | None = None) -> Dict[str, Any]:
        check_acl(self.connections_cfg, target_db, sop_id, "update")
        db = self.connections_cfg[target_db]
        driver = db.get("driver", "postgres")
        if driver == "oracle":
            if not host:
                raise RuntimeError("Oracle execute_many requires host argument")
            pool = self._get_oracle_pool_for_host(target_db, host)
            affected = await ora_run_execute_many(pool, sql, seq_of_params)
            return {"affected": affected}
        else:
            raise RuntimeError(f"execute_many not implemented for driver: {driver}")
