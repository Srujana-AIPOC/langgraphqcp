from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

def build_engine(dsn: str, pool_min: int = 1, pool_max: int = 5) -> AsyncEngine:
    return create_async_engine(
        dsn,
        pool_size=pool_min,
        max_overflow=max(0, pool_max - pool_min),
        pool_pre_ping=True,
    )
