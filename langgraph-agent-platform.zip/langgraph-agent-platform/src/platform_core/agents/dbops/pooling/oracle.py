from __future__ import annotations
import oracledb


def build_pool(*, user: str, password: str, dsn: str, pool_min: int = 1, pool_max: int = 5):
    # Create a synchronous SessionPool; DB ops will run in a thread.
    # increment=1 keeps pool growth predictable.
    # Note: some oracledb versions/drivers do not accept 'encoding' here.
    pool = oracledb.create_pool(
        user=user,
        password=password,
        dsn=dsn,
        min=pool_min,
        max=pool_max,
        increment=1,
    )
    return pool
