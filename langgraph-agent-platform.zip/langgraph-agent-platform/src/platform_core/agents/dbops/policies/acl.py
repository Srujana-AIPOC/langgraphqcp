from typing import Dict, Any

def check_acl(connections_cfg: Dict[str, Any], target_db: str, sop_id: str, op: str) -> None:
    db = connections_cfg.get(target_db)
    if not db:
        raise PermissionError(f"Unknown database: {target_db}")
    acl = db.get("acl", {})
    allowed_sops = set(acl.get("allowed_sops", []))
    allowed_ops = set(acl.get("allowed_operations", []))
    if sop_id not in allowed_sops:
        raise PermissionError(f"SOP {sop_id!r} not allowed for DB {target_db!r}")
    if op not in allowed_ops:
        raise PermissionError(f"Operation {op!r} not allowed for DB {target_db!r}")
