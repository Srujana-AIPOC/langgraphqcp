-- Approved template: get_psub_rows_by_key
SELECT id, key, value
FROM psub_table
WHERE key = :key
LIMIT 1000;
