def init_otel() -> None:
    # Placeholder: wire OpenTelemetry exporters, traces, and metrics here.
    pass
