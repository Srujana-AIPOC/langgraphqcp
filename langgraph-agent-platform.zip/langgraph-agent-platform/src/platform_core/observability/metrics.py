from __future__ import annotations
from typing import Any

from prometheus_client import Gauge

# Gauges (default registry)
PROC_CPU = Gauge("lgp_process_cpu_percent", "Uvicorn process CPU percent")
PROC_RSS = Gauge("lgp_process_rss_bytes", "Uvicorn process RSS bytes")
PROC_THREADS = Gauge("lgp_process_threads", "Uvicorn process thread count")
PROC_UPTIME = Gauge("lgp_process_uptime_seconds", "Uvicorn process uptime seconds")

SYS_MEM_TOTAL = Gauge("lgp_system_mem_total_bytes", "Host total memory bytes")
SYS_MEM_USED = Gauge("lgp_system_mem_used_bytes", "Host used memory bytes")
SYS_MEM_PCT = Gauge("lgp_system_mem_percent", "Host memory percent used")
SYS_CPU_PCT = Gauge("lgp_system_cpu_percent", "Host CPU percent")

AUDITS_RECENT = Gauge("lgp_audits_recent_count", "Recent audit files counted")

PW_ENABLED = Gauge("lgp_playwright_manager_enabled", "Playwright manager enabled (1/0)")
PW_MAX_CONTEXTS = Gauge("lgp_playwright_max_contexts", "Playwright manager max contexts (best effort)")


def _set_if_present(g: Gauge, value: Any) -> None:
    try:
        if value is None:
            return
        # Accept ints/floats/str that can be cast
        if isinstance(value, (int, float)):
            g.set(value)
        else:
            g.set(float(value))
    except Exception:
        pass


def update_metrics(snapshot: dict) -> None:
    """Update Prometheus gauges from a status snapshot returned by collect_status()."""
    proc = snapshot.get("process", {})
    sysm = snapshot.get("system", {})
    pw = snapshot.get("playwright", {})
    audits = snapshot.get("audits", [])

    _set_if_present(PROC_CPU, proc.get("cpu_percent"))
    _set_if_present(PROC_RSS, proc.get("rss_bytes"))
    _set_if_present(PROC_THREADS, proc.get("num_threads"))
    _set_if_present(PROC_UPTIME, proc.get("uptime_sec"))

    _set_if_present(SYS_MEM_TOTAL, sysm.get("total_mem_bytes"))
    _set_if_present(SYS_MEM_USED, sysm.get("used_mem_bytes"))
    _set_if_present(SYS_MEM_PCT, sysm.get("mem_percent"))
    _set_if_present(SYS_CPU_PCT, sysm.get("cpu_percent"))

    _set_if_present(AUDITS_RECENT, len(audits))

    _set_if_present(PW_ENABLED, 1 if pw.get("enabled") else 0)
    # We don't expose semaphore internals; record max_contexts if present in manager
    # (best-effort: status collector doesn't return it explicitly yet)
    # Keep as 0 by default
    # PW_MAX_CONTEXTS remains unset unless surfaced later

