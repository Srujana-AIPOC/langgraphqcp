from __future__ import annotations
import os
import sys
import json
import time
from pathlib import Path
from typing import Any, Dict, List

_START_MONO = time.monotonic()


def _try_import_psutil():
    try:
        import psutil  # type: ignore
        return psutil
    except Exception:
        return None


def get_process_metrics() -> Dict[str, Any]:
    psutil = _try_import_psutil()
    proc: Dict[str, Any] = {
        "pid": os.getpid(),
        "python": sys.version.split(" ")[0],
        "executable": sys.executable,
        "uptime_sec": round(time.monotonic() - _START_MONO, 2),
    }
    if psutil is not None:
        p = psutil.Process(os.getpid())
        with p.oneshot():
            mem = p.memory_info()
            # Use a small interval to produce a real sample even on first call
            cpu_pct = 0.0
            try:
                cpu_pct = p.cpu_percent(interval=0.1)
            except Exception:
                cpu_pct = 0.0
            proc.update(
                {
                    "rss_bytes": int(mem.rss),
                    "vms_bytes": int(mem.vms),
                    "cpu_percent": cpu_pct,
                    "num_threads": p.num_threads(),
                    "create_time": getattr(p, "create_time", lambda: 0)(),
                }
            )
    return proc


def get_system_metrics() -> Dict[str, Any]:
    psutil = _try_import_psutil()
    sysm: Dict[str, Any] = {}
    if psutil is not None:
        vm = psutil.virtual_memory()
        sysm.update(
            {
                "total_mem_bytes": int(vm.total),
                "used_mem_bytes": int(vm.used),
                "free_mem_bytes": int(getattr(vm, "available", 0)),
                "mem_percent": float(vm.percent),
            }
        )
        try:
            load1, load5, load15 = psutil.getloadavg()  # type: ignore[attr-defined]
            sysm.update({"load1": load1, "load5": load5, "load15": load15})
        except Exception:
            pass
        try:
            sysm["cpu_percent"] = psutil.cpu_percent(interval=0.1)
        except Exception:
            pass
    return sysm


def get_playwright_metrics(app_state: Any) -> Dict[str, Any]:
    out: Dict[str, Any] = {"enabled": False}
    mgr = getattr(app_state, "pw_manager", None)
    if mgr is None:
        return out
    # Minimal snapshot without tight coupling
    out["enabled"] = True
    out["engine"] = getattr(mgr, "_engine", "chromium")
    out["headful_default"] = getattr(mgr, "_headful_default", False)
    out["slow_mo"] = getattr(mgr, "_slow_mo", 0)
    # semaphore capacity (best-effort)
    sem = getattr(mgr, "_sem", None)
    if sem is not None:
        # asyncio.Semaphore doesn't expose a direct size; show repr
        out["semaphore"] = repr(sem)
    return out


def get_recent_audits(limit: int = 10) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    base = Path("output/data")
    if not base.exists():
        return out
    files = sorted(base.glob("run_audit_*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    for p in files[:limit]:
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
            out.append({
                "file": str(p),
                "run_id": raw.get("run_id"),
                "started_at": raw.get("started_at"),
                "ended_at": raw.get("ended_at"),
                "events_len": len(raw.get("events", [])),
                "last_event": (raw.get("events", []) or [{}])[-1],
            })
        except Exception:
            continue
    return out


def collect_status(app_state: Any) -> Dict[str, Any]:
    return {
        "env": {
            "APP_ENV": os.getenv("APP_ENV", "dev"),
            "cwd": os.getcwd(),
        },
        "process": get_process_metrics(),
        "system": get_system_metrics(),
        "playwright": get_playwright_metrics(app_state),
        "audits": get_recent_audits(10),
    }
