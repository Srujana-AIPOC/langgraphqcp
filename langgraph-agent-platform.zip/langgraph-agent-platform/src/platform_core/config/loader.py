from __future__ import annotations
import os, tomllib
from pathlib import Path
from typing import Any, Dict

def _read_toml(path: Path) -> Dict[str, Any]:
    """
    Reads a TOML file from the given path and returns its contents as a dictionary.
    If the file does not exist, returns an empty dictionary.
    """
    if not path.exists():
        return {}
    with path.open("rb") as f:
        return tomllib.load(f)

def load_config(env: str | None = None) -> Dict[str, Any]:
    """
    Loads configuration settings based on the specified environment ('dev' or 'prod').
    Merges base, environment-specific, features, and connections TOML files into a single dictionary.
    If no environment is specified, defaults to 'dev' or uses the 'APP_ENV' environment variable.
    """
    base = Path("configs/base.toml")
    dev = Path("configs/dev.toml")
    prod = Path("configs/prod.toml")
    features = Path("configs/features.toml")
    connections = Path("configs/connections.toml")

    env = env or os.getenv("APP_ENV", "dev")
    cfg = {}
    cfg.update(_read_toml(base))
    if env == "dev":
        cfg.update(_read_toml(dev))
    elif env == "prod":
        cfg.update(_read_toml(prod))
    cfg["features"] = _read_toml(features).get("features", {})
    cfg["connections"] = _read_toml(connections).get("databases", {})
    return cfg
