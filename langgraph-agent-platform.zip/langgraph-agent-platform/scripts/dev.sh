#!/usr/bin/env bash
set -euo pipefail
uvicorn apis.http.app:app --reload
