from platform_core.supervisor.router import choose_sop
import pytest

def test_choose_sop_psub():
    assert choose_sop({"task_type": "psub"}) == "test-sop"

def test_choose_sop_unknown():
    with pytest.raises(ValueError):
        choose_sop({"task_type": "unknown"})
