# LangGraph Platform - Setup Guide & README (Rule-First, LLM-Ready)

This repository hosts a single LangGraph platform that runs multiple SOPs (agents) in one place. It centralizes DB operations via a shared DBOps agent, keeps per-SOP state, and starts rule-based while being LLM-ready behind feature flags.

> Run today in fully deterministic rule mode. Later, flip feature flags to enable hybrid (rules + LLM) decision making without refactors.

## 1) Architecture Overview
- Supervisor (Router): decides which SOP subgraph to run; rule-based now; optional LLM ranking later.
- SOP Subgraphs: one per SOP (e.g., TestSOP, PsubWorkflowSOP). SOPs do not talk to DBs directly.
- Shared DBOps Agent: performs all DB work (Postgres, Oracle, etc.) with pools, ACLs, budgets, typed outputs, and auditing. All SOPs call DBOps.
- State & Persistence: global/session + per-SOP state. Checkpointer persists node checkpoints and audit data.
- Observability: structured logs, metrics, and traces correlated by run_id, sop_id, tenant.



## 4) Repo Structure (src layout)

Key paths:
- `src/platform_core/` – framework, supervisor, registry, DBOps, logging.
- `src/sops/test_sop/` – example Postgres SOP.
- `src/sops/psub/` – workflow SOP (Playwright UI + Oracle via DBOps).
- `configs/` – base/dev/prod, features, connections.
- `apis/http/app.py` – FastAPI entry to trigger runs.

## 5) Config Files (TOML)
- `configs/base.toml` defaults; `dev.toml`/`prod.toml` overrides.
- `configs/features.toml` feature flags (rule vs hybrid).
- `configs/connections.toml` logical DBs, pools, ACLs, budgets (secrets via env).

## 6) Quick Start (Rule Mode)
1. `python -m venv .venv && source .venv/bin/activate` (Windows: `.\.venv\Scripts\activate`)
2. `pip install -e .[dev]`
3. `cp .env.example .env` and fill DSNs/creds.
4. `uvicorn apis.http.app:app --reload`
5. Open registry UI: `http://localhost:8000/sops/ui` (see available agents).
6. POST to `/runs` with `{"task_type": "psub", "payload": {"key": "demo"}}`.

7.python -m playwright install chromium



## 8) Testing
- Unit: nodes, reducers, router rules.
- Contract: DBOps templates against seeded DB (Testcontainers).
- Integration: Supervisor + SOP + DBOps.
- E2E: API to result with checkpoints.



---

## 10) Request Flow (HTTP -> SOP -> DBOps)

This sequence diagram reflects the current codebase. It shows app startup (config, logging, SOP registration), request routing via Supervisor, and two execution paths: TestSOP (Postgres) and PsubWorkflowSOP (UI + Oracle through DBOps).

```mermaid
sequenceDiagram
autonumber
actor Client
participant HTTP as FastAPI App (apis/http/app.py)
participant Config as Config Loader
participant Log as Logging
participant Registry as Registry (registry/registry.py)
participant Router as Supervisor Router (supervisor/router.py)
participant Policies as Routing Policies (supervisor/policies.py)
participant SOP as SOP Instance
participant DBOps as DBOpsService (agents/dbops/service.py)
participant ACL as ACL Policy
participant Pool as Pool/Engine
participant Adapter as DB Adapter
participant DB as Database

rect rgb(245,245,245)
note over HTTP: App startup (module import)
HTTP->>Config: load_config(APP_ENV)
HTTP->>Log: setup_logging(level)
HTTP->>Registry: register_sop("test-sop", TestSOP)
HTTP->>Registry: register_sop("psub-workflow", PsubWorkflowSOP)
end

Client->>HTTP: POST /runs {task_type, payload}
HTTP->>Router: choose_sop(task)
Router->>Policies: route_task(task_type)
Policies-->>Router: sop_id ("test-sop" or "psub-workflow")
Router-->>HTTP: sop_id
HTTP->>Registry: get_sop(sop_id)
Registry-->>HTTP: SOP instance

alt task_type = "psub" -> sop_id "test-sop"
  HTTP->>SOP: run(payload)
  Note over SOP: sops/test_sop/graph.py
  SOP->>DBOps: select_template(psub_pg, sop_id="test-sop", template_path, params)
  DBOps->>ACL: check_acl(connections, "psub_pg", "test-sop", "select")
  ACL-->>DBOps: ok
  DBOps->>Pool: build_engine (postgres)
  Pool-->>DBOps: AsyncEngine
  DBOps->>Adapter: run_select(engine, sql, params)
  Adapter->>DB: execute query
  DB-->>Adapter: rows
  Adapter-->>DBOps: rows
  DBOps-->>SOP: {rows, row_count}
  SOP-->>HTTP: result {rows}
  HTTP-->>Client: 200 JSON {run_id, sop_id, result}
else task_type = "psub_flow" -> sop_id "psub-workflow"
  HTTP->>SOP: run(payload)
  Note over SOP: sops/psub/psubsop.py (injects DBOps into OracleClient)
  SOP->>SOP: run_pipeline (thread)
  Note over SOP: sops/psub/workflow/graph.py
  SOP->>DBOps: select_sql(sql, host, sop_id="psub-workflow")
  DBOps->>ACL: check_acl(connections, "psub_oracle", "psub-workflow", "select")
  ACL-->>DBOps: ok
  DBOps->>Pool: create_pool (oracle per host)
  Pool-->>DBOps: SessionPool
  DBOps->>Adapter: run_select(pool, sql, params)
  Adapter->>DB: execute query
  DB-->>Adapter: rows
  Adapter-->>DBOps: rows
  DBOps-->>SOP: {rows, row_count}
  SOP-->>HTTP: result {state}
  HTTP-->>Client: 200 JSON {run_id, sop_id, result}
end
```

Explanation
- App startup: `apis/http/app.py` loads config, sets logging, and registers SOP builders for `test-sop` and `psub-workflow`.
- Routing: `supervisor/policies.py` maps `task_type` to `sop_id` ("psub" -> "test-sop", "psub_flow" -> "psub-workflow"); `supervisor/router.py` returns the chosen id.
- Registry: `registry/registry.py` instantiates the requested SOP.
- TestSOP path: `sops/test_sop/graph.py` calls `DBOpsService.select_template` against Postgres. DBOps enforces ACLs, builds/reuses an async engine, runs via the Postgres adapter, and returns rows.
- PsubWorkflow path: `sops/psub/psubsop.py` injects DBOps into the workflow’s `OracleClient`. The workflow (`sops/psub/workflow/graph.py`) runs Playwright to derive the Oracle host, then `OracleClient` issues `select_sql`/`execute_many` via DBOps. DBOps resolves an Oracle pool per host and runs via the Oracle adapter.
- Response: The SOP returns a result dict; the HTTP handler wraps it with `run_id` and `sop_id`.



## 12) Runtime SOP Registry (UI and JSON)

At startup the app registers SOP builders in a runtime registry. You can inspect the available agents at runtime via:

- GET `/sops` (JSON)
  - Returns a list of registered SOPs and their class names, e.g.
    - `{ "count": 2, "sops": [{"sop_id": "test-sop", "class": "TestSOP"}, {"sop_id": "psub-workflow", "class": "PsubWorkflowSOP"}] }`
  - Backed by `platform_core/registry/registry.py:list_sops_with_classes` (best‑effort instantiates builders; failures show class as `<unknown>`).

- GET `/sops/ui` (HTML)
  - A simple dashboard showing each registered agent with:
    - SOP ID, class name, status, known task types (e.g., `psub` -> `test-sop`, `psub_flow` -> `psub-workflow`)
    - A copyable curl example for quick testing
  - Implemented in `apis/http/routes/sops.py` and mounted in `apis/http/app.py`.

Notes
- These endpoints reflect in‑memory registration during app startup.
- In production, consider restricting access since they reveal available capabilities.

