# from typing import Optional
# from playwright.sync_api import Browser, BrowserContext, Page

# class FlowState(dict):
#     """
#     A simple dict-based state container to store browser objects and other info.
#     """
#     browser: Optional[Browser]
#     context: Optional[BrowserContext]
#     page: Optional[Page]
#     error: Optional[str]
