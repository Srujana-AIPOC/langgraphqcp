# from enum import Enum, auto

# class QCPState(Enum):
#     START = auto()
#     OPEN_PAGE = auto()
#     WAIT_PLATFORM = auto()
#     MAINTAIN_TOGGLE = auto()
#     JASPER_TOGGLE = auto()
#     CREATE_RELEASE = auto()
#     WAIT_FORM = auto()
#     END = auto()

# EDGES = {
#     "start": "open_page",
#     "open_page": "wait_platform",
#     "wait_platform": "maintain_toggle",
#     "maintain_toggle": "jasper_toggle",
#     "jasper_toggle": "create_release",
#     "create_release": "wait_form",
#     "wait_form": "end",
#     "end": None,
# }
