from playwright.sync_api import sync_playwright, Browser, BrowserContext, Page
from typing import Optional

def node_start(state: dict) -> dict:
    playwright = sync_playwright().start()
    browser = playwright.chromium.launch(headless=False, slow_mo=500)
    context = browser.new_context()
    state['playwright'] = playwright  
    state['browser'] = browser
    state['context'] = context
    state['page'] = None
    return state

def node_open_page(state: dict) -> dict:
    context: Optional[BrowserContext] = state.get('context')
    if context is None:
        state['error'] = "No browser context"
        return state
    page = context.new_page()
    page.goto("http://127.0.0.1:5500/qcp.html")
    state['page'] = page
    return state

def node_wait_platform(state: dict) -> dict:
    page = state.get('page')
    if page is None:
        state['error'] = "No page for wait_platform"
        return state
    locator = page.get_by_text("Santas Cloud Platform")
    locator.wait_for()
    return state

def node_maintain_toggle(state: dict) -> dict:
    page = state.get('page')
    if page is None:
        state['error'] = "No page for maintain_toggle"
        return state
    maintain_toggle_locator = page.locator("#maintainToggle")
    maintain_toggle_locator.click()
    maintain_apps_locator = page.locator("#maintainApps")
    maintain_apps_locator.wait_for(state="visible")
    return state

def node_jasper_toggle(state: dict) -> dict:
    page = state.get('page')
    if page is None:
        state['error'] = "No page for jasper_toggle"
        return state
    jasper_toggle_locator = page.locator("#jasperToggle")
    jasper_toggle_locator.click()
    jasper_apps_locator = page.locator("#jasperApps")
    jasper_apps_locator.wait_for(state="visible")
    return state

def node_create_release(state: dict) -> dict:
    page = state.get('page')
    if page is None:
        state['error'] = "No page for create_release"
        return state
    create_release_locator = page.locator('#jasperApps >> text=Create Release Package')
    create_release_locator.click()
    return state

def node_wait_form(state: dict) -> dict:
    page = state.get('page')
    if page is None:
        state['error'] = "No page for wait_form"
        return state
    form_page_locator = page.locator("#formPage")
    form_page_locator.wait_for(state="visible")
    dashboard_locator = page.locator("#dashboard")
    dashboard_locator.wait_for(state="hidden")
    print("Form page opened. You can fill the details manually.")
    page.wait_for_timeout(300000)  # 5 minutes wait
    return state

def node_end(state: dict) -> dict:
    page = state.get('page')
    browser = state.get('browser')
    playwright = state.get('playwright')
    if page:
        page.close()
    if browser:
        browser.close()
    if playwright:
        playwright.stop()
    return state
