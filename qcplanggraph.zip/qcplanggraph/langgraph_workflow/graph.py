from typing import TypedDict, Any, Optional, List, Dict
from langgraph.graph import StateGraph, END
from .nodes import (  # your node implementations remain the same
    node_start, node_open_page, node_wait_platform, node_maintain_toggle,
    node_jasper_toggle, node_create_release, node_wait_form, node_end
)


# Define a strongly typed state schema for the graph using TypedDict
class FlowState(TypedDict, total=False):
    playwright: Any
    browser: Any
    context: Any
    page: Optional[Any]

    error: Optional[str]


def build_graph() -> StateGraph[FlowState]:
    # Use FlowState TypedDict as the state schema for better typing and validation
    g = StateGraph(FlowState)

    # Add nodes with their names and associated handler functions
    g.add_node("start", node_start)
    g.add_node("open_page", node_open_page)
    g.add_node("wait_platform", node_wait_platform)
    g.add_node("maintain_toggle", node_maintain_toggle)
    g.add_node("jasper_toggle", node_jasper_toggle)
    g.add_node("create_release", node_create_release)
    g.add_node("wait_form", node_wait_form)
    g.add_node("end", node_end)

    # Set the entry point of the graph
    g.set_entry_point("start")

    # Define edges for sequential execution
    g.add_edge("start", "open_page")
    g.add_edge("open_page", "wait_platform")
    g.add_edge("wait_platform", "maintain_toggle")
    g.add_edge("maintain_toggle", "jasper_toggle")
    g.add_edge("jasper_toggle", "create_release")
    g.add_edge("create_release", "wait_form")
    g.add_edge("wait_form", "end")
    g.add_edge("end", END)

    return g.compile()


def run_workflow():
    graph = build_graph()
    initial_state: FlowState = {}

    final_state = graph.invoke(initial_state)

    if final_state.get('error'):
        print("Workflow ended with error:", final_state['error'])
    else:
        print("Workflow completed successfully")


if __name__ == "__main__":
    run_workflow()
