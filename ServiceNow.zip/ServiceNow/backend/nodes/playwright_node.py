import asyncio
import sys
import logging
from playwright.async_api import async_playwright, Error as PlaywrightError
from backend.states.workflow_state import WorkflowState
from backend.nodes.agent_node import match_record

# Setup logging
logging.basicConfig(level=logging.INFO)


if sys.platform.startswith("win"):
    try:
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
        logging.info("Set Windows ProactorEventLoopPolicy for asyncio")
    except Exception as e:
        logging.warning(f"Failed to set ProactorEventLoopPolicy: {e}")

async def fill_dashboard(state: WorkflowState, config_item: str, short_description: str) -> WorkflowState:
    """
    Open the local dashboard page and auto-fill fields
    based on the matched record in WorkflowState.
    """

    # Ensure filledFields exists
    if not hasattr(state, "filledFields"):
        state.filledFields = []

    # Find the matched record first
    state = match_record(state, config_item, short_description)
    record = getattr(state, "matched_record", None)
    if not record:
        state.errors.append("No record to fill dashboard.")
        return state

    # URL of your local dashboard page
    url = "http://127.0.0.1:5500/servicenow/dashboard.html"

    # Map record keys -> dashboard field IDs 
    field_mapping = {
        "Configuration Item": "changeConfigItem",
        "Short Description": "shortDesc",
        "Change Owner Group": "changeCoordinator",
        "Requester": "changeRequester",
        "Site Code": "changeSiteCoder",
        "Contact Number": "contactNumber",
        "Type": "changeType",
        "Service": "changeService",
        "Category": "changeCategory",
        "Nature of Change": "natureOfChange",
        "Affected Airline": "affectedAirline",
        "Coordinator Group": "changeCoordGroup",
        "Change Coordinator": "changeAssignedTo",
        "Change Owner": "changeSupportGroup",
        "Technical Review Approval": "techReviewApproval",
        "Change Description": "changeDescription",
        "Change Initiated From": "changeInitiatedFrom",
        "Reason for Change/ Additional Commentary": "reasonForChange",
        "Environment": "environment",
        "Has the change has been peer reviewed?": "peerReviewed",
        "Please provide name and contact details of who is responsible for technically signing off the peer-review. All relevant testing documentation should be attached to this change record": "peerReviewerContact",
        "Is there an impact associated with the planned Rollback/Backout": "rollbackImpact",
        "Please provide justified reason": "",  # No matching id in HTML
        "Is there an impact associated with the planned implementation": "implementationImpact",
        "Did the previous attempt cause an incident?": "previousIncident",
        "The potential impact if the change is unsuccessful": "potentialImpact",
        "Implementation Plan": "implementationPlan",
        "Verification Plan": "verificationPlan",
        "Rollback Plan": "rollbackPlan",
        "Rollback Duration": "rollbackDuration",
        "Manage Approvals": "",  
    }

    try:
        logging.info("Starting Playwright automation...")
        async with async_playwright() as p:
            logging.info("Launching Chromium browser...")
            browser = await p.chromium.launch(headless=False)
            page = await browser.new_page()
            await page.goto(url)
            logging.info(f"Navigated to {url}")

            await page.wait_for_selector("#changeConfigItem")
            logging.info("Selector #changeConfigItem found.")

            for key, value in record.items():
                # Normalize dropdown values for specific fields
                if key == "Type" and isinstance(value, str):
                    value = value.capitalize() 
                if key == "Nature of Change" and isinstance(value, str):
                    mapping = {
                        "business as usual (bau)": "BAU",
                        "bau": "BAU",
                        "fix": "Fix",
                        "enhancement": "Enhancement",
                    }
                    value_lower = value.lower()
                    value = mapping.get(value_lower, value)

                if key == "Change Initiated From" and isinstance(value, str):
                    mapping = {
                        "other/problem": "OtherProblem",
                        "other problem": "OtherProblem",
                        "other": "Other",
                        "incident": "Incident",
                        "request": "Request",
                    }
                    value_lower = value.lower()
                    value = mapping.get(value_lower, value)

                field_id = field_mapping.get(key)
                if not field_id:
                    logging.warning(f"No field mapping for key: {key}")
                    continue

                selector = f"#{field_id}"
                element = await page.query_selector(selector)
                if element:
                    tag_type = await element.evaluate("el => el.tagName.toLowerCase()")
                    if tag_type in ("input", "textarea"):
                        await page.fill(selector, value)
                        logging.info(f"Filled {selector} with value: {value}")
                    elif tag_type == "select":
                        if value:
                            options = await page.eval_on_selector_all(f"{selector} option", "options => options.map(option => option.value)")
                            if value in options:
                                await page.select_option(selector, value=value)
                                logging.info(f"Selected option for {selector}: {value}")
                            else:
                                logging.warning(f"Value '{value}' not found in options for {selector}, skipping")
                        else:
                            logging.warning(f"Empty value for select option {selector}, skipping selection")
                    else:
                        error_msg = f"Unsupported element type for {selector}"
                        logging.warning(error_msg)
                        state.errors.append(error_msg)
                else:
                    logging.warning(f"Element {selector} not found on page")

            # Safe wait for manual interaction or inspection
            try:
                await page.wait_for_timeout(300000)  
            except PlaywrightError:
                logging.warning("Browser or page closed before timeout.")

            # await browser.close()
            logging.info("Browser is still open; close manually to end the session.")

        state.filledFields.extend(list(record.keys()))
        state.filledFields.append("dashboard_filled")

    except Exception as e:
        state.errors.append(f"Playwright error: {e}")
        import traceback
        print(traceback.format_exc())

    return state
