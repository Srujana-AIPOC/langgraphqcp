import os
import json
from backend.states.workflow_state import WorkflowState

# Base path for records.json
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RECORDS_PATH = os.path.join(BASE_DIR, "records.json")

# Load records once into memory
if os.path.exists(RECORDS_PATH):
    with open(RECORDS_PATH, "r") as f:
        records = json.load(f)
else:
    records = []


def get_short_descriptions(state: WorkflowState, config_item: str) -> WorkflowState:
    state.record["configItem"] = config_item.strip()
    short_descs = [
        r["Short Description"]
        for r in records
        if r["Configuration Item"].lower() == config_item.lower()
    ]
    state.short_descriptions = short_descs

    return state


def match_record(
    state: WorkflowState, config_item: str, short_description: str
) -> WorkflowState:
    matched = next(
        (
            r
            for r in records
            if r["Configuration Item"].lower() == config_item.lower()
            and r["Short Description"].lower() == short_description.lower()
        ),
        None,
    )
    if matched:
        state.matched_record = matched
    else:
        state.errors.append("No matching record found.")

    return state


def get_dashboard_fields(state: WorkflowState) -> list:
    # Return the list of dashboard fields that will be filled
    if hasattr(state, "matched_record") and state.matched_record:
        return list(state.matched_record.keys())
    return []
