class WorkflowState:
    def __init__(self):
        # Holds selected config item and related details
        self.record = {}

        # Holds list of short descriptions after config item parse
        self.short_descriptions = []

        # Holds the final matched record from records.json
        self.matched_record = None

        # Collects any errors during workflow
        self.errors = []

        # Tracks which fields/pages were auto-filled (e.g., dashboard)
        self.filledFields = []

    def __repr__(self):
        return (
            f"<WorkflowState "
            f"record={self.record} "
            f"short_descriptions={self.short_descriptions} "
            f"matched_record={self.matched_record} "
            f"errors={self.errors} "
            f"filledFields={self.filledFields}>"
        )
