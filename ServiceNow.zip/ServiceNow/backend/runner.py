from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

from backend.nodes.agent_node import get_short_descriptions, match_record, get_dashboard_fields
from backend.nodes.playwright_node import fill_dashboard
from backend.states.workflow_state import WorkflowState

import os

# Initialize FastAPI app
app = FastAPI()

# Enable CORS for all origins 
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],  
    allow_headers=["*"],  
)

# Mount static files from the 'servicenow' directory under the /servicenow route
parent_dir = os.path.dirname(os.path.abspath(__file__))
app.mount(
    "/servicenow",
    StaticFiles(directory=os.path.join(parent_dir, "../servicenow")),
    name="servicenow",
)


# API Endpoints


@app.post("/get_short_descriptions")
async def get_short_descriptions_api(request: Request):
    """
    Endpoint to get a list of short descriptions based on the provided config item.
    """
    data = await request.json()
    config_item = data.get("configItem", "")

    # Initialize workflow state
    state = WorkflowState()

    # Populate state with short descriptions
    state = get_short_descriptions(state, config_item)

    # Return the short descriptions
    return JSONResponse(content={
        "status": "success",
        "shortDescriptions": state.short_descriptions
    })


@app.post("/submit_selection")
async def submit_selection_api(request: Request):
    """
    Endpoint to handle form submission with config item and selected short description.
    Fills dashboard fields based on the selection.
    """
    data = await request.json()
    config_item = data.get("configItem", "")
    short_description = data.get("shortDescription", "")

    # Initialize workflow state
    state = WorkflowState()

    # Fill dashboard fields using Playwright automation
    state = await fill_dashboard(state, config_item, short_description)

    fields = getattr(state, "filledFields", [])

    return JSONResponse(content={
        "status": "success",
        "fieldsBeingFilled": fields,
        "errors": state.errors
    })


@app.get("/")
async def homepage():
    """
    Serves the main dashboard HTML page.
    """
    dashboard_path = os.path.join(parent_dir, "../servicenow/dashboard.html")
    return FileResponse(dashboard_path)



